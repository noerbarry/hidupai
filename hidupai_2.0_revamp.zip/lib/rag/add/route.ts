// 📁 /app/api/rag/add/route.ts
import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { email, newMemory } = await req.json()
  if (!email || !newMemory) return NextResponse.json({ error: 'Data tidak lengkap' }, { status: 400 })

  const embeddingRes = await fetch('https://api.openai.com/v1/embeddings', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'text-embedding-3-small',
      input: newMemory
    })
  })

  const embedding = (await embeddingRes.json())?.data?.[0]?.embedding
  if (!embedding) return NextResponse.json({ error: 'Gagal embedding' }, { status: 500 })

  const supabase = createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const { error } = await supabase
    .from('user_memories')
    .insert({ email, content: newMemory, embedding })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ success: true })
}


