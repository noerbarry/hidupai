// 📁 /lib/rag/queryMemory.ts
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

type MemoryMatch = {
  id: number
  content: string
  similarity: number
}

async function getQueryEmbedding(query: string): Promise<number[]> {
  const response = await fetch('https://api.openai.com/v1/embeddings', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'text-embedding-3-small',
      input: query
    })
  })

  const json = await response.json()
  if (!response.ok || !json?.data?.[0]?.embedding) {
    console.error('❌ Gagal mendapatkan embedding dari OpenAI:', json)
    throw new Error('Gagal mendapatkan embedding dari OpenAI')
  }

  return json.data[0].embedding
}

export async function queryMemory(
  email: string,
  query: string,
  matchThreshold = 0.78,
  matchCount = 5
): Promise<string[]> {
  try {
    const embedding = await getQueryEmbedding(query)

    const { data, error } = await supabase.rpc(
      'match_long_term_memories',
      {
        query_embedding: embedding,
        match_threshold: matchThreshold,
        match_count: matchCount,
        user_email: email
      }
    )

    if (error) {
      console.error('❌ Supabase RPC error:', error)
      return []
    }

    const results = data as MemoryMatch[]

    return results
      .map((item) => item?.content)
      .filter((content): content is string => typeof content === 'string' && content.trim().length > 0)
  } catch (err) {
    console.error('❌ queryMemory failed:', err)
    return []
  }
}
