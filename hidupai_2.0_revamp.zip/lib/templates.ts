// lib/templates.ts

export const defaultPlannerTemplate = `
📆 AI Weekly Habit Planner

Senin:
• Mulai hari dengan afirmasi positif
• 15 menit olahraga ringan
• Fokus kerja selama 2 jam (deep work)

Selasa:
• Evaluasi progres tugas utama
• Journaling 5 menit
• Tidur lebih awal (target jam 22.00)

Rabu:
• Tinjau kembali tujuan mingguan
• Satu aktivitas untuk kesejahteraan mental
• Check-in: Apakah kamu masih on track?

Kamis:
• Revisi rencana jika perlu
• 30 menit belajar topik baru
• Tulis 1 insight hari ini

Jumat:
• Self-review minggu ini
• Buat ringkasan mingguan
• Luangkan waktu untuk refleksi

Sabtu:
• Bebas dari tekanan
• Jalan santai atau aktivitas menyenangkan
• Jangan lupa journaling!

Minggu:
• Susun rencana minggu depan
• Siapkan kebutuhan penting (mental & logistik)
• Recharge dengan hal-hal positif 🌱
`
