// File: components/Navbar.tsx
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname, useRouter } from 'next/navigation'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClientComponentClient()

  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  // 🔐 Cek session
  useEffect(() => {
    const checkSession = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      setIsLoggedIn(!!session?.user)
    }
    checkSession()
  }, [supabase])

  // 🔄 Tutup menu kalau ganti halaman
  useEffect(() => {
    setMenuOpen(false)
  }, [pathname])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setIsLoggedIn(false)
    router.push('/login')
  }

  // Sembunyikan navbar di halaman login/auth
  if (pathname.startsWith('/login') || pathname.startsWith('/auth')) {
    return null
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
        {/* LOGO */}
        <Link href="/" className="flex items-center">
          <Image
            src="/images/logo-hidupai.png"
            alt="HidupAI"
            width={160}
            height={160}
            className="w-28 sm:w-32 h-auto"
            priority
          />
        </Link>

        {/* NAV DESKTOP */}
        <nav className="hidden md:flex gap-5 text-sm text-gray-700">
          <Link href="/" className="hover:text-blue-600">
            Beranda
          </Link>
          <Link href="/pricing" className="hover:text-blue-600">
            Harga
          </Link>
          <Link href="/about" className="hover:text-blue-600">
            Tentang
          </Link>
          <Link href="/faq" className="hover:text-blue-600">
            FAQ
          </Link>
          <Link href="/contact" className="hover:text-blue-600">
            Kontak
          </Link>
          <Link href="/terms-and-conditions" className="hover:text-blue-600">
            Term
          </Link>
          <Link href="/disclaimer" className="hover:text-blue-600">
            Disclaimer
          </Link>
        </nav>

        {/* AUTH DESKTOP */}
        <div className="hidden md:flex items-center gap-2">
          {isLoggedIn ? (
            <>
              <Link href="/dashboard">
                <Button size="sm" variant="outline">
                  🚀 Dashboard
                </Button>
              </Link>
              <Button size="sm" onClick={handleLogout}>
                Keluar
              </Button>
            </>
          ) : (
            <Link href="/login">
              <Button size="sm">✨ Masuk / Daftar</Button>
            </Link>
          )}
        </div>

        {/* HAMBURGER MOBILE */}
        <button
          type="button"
          aria-label="Buka menu navigasi"
          className="md:hidden inline-flex items-center justify-center rounded-md p-2 text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-white"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          {/* Ikon hamburger (SVG) */}
          <svg
            className="h-5 w-5"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              d="M4 7h16M4 12h16M4 17h16"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
            />
          </svg>
        </button>
      </div>

      {/* MENU MOBILE DROPDOWN */}
      {menuOpen && (
        <div className="md:hidden px-4 pb-3 pt-2 space-y-2 text-sm text-gray-700 bg-white border-t border-gray-200 shadow-lg">
          <Link href="/" className="block hover:text-blue-600">
            Beranda
          </Link>
          <Link href="/pricing" className="block hover:text-blue-600">
            Harga
          </Link>
          <Link href="/about" className="block hover:text-blue-600">
            Tentang
          </Link>
          <Link href="/faq" className="block hover:text-blue-600">
            FAQ
          </Link>
          <Link href="/contact" className="block hover:text-blue-600">
            Kontak
          </Link>
          <Link
            href="/terms-and-conditions"
            className="block hover:text-blue-600"
          >
            Term
          </Link>
          <Link href="/disclaimer" className="block hover:text-blue-600">
            Disclaimer
          </Link>

          <div className="pt-2 border-t border-gray-100 space-y-2">
            {isLoggedIn ? (
              <>
                <Link href="/dashboard">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    🚀 Dashboard
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={handleLogout}
                >
                  Keluar
                </Button>
              </>
            ) : (
              <Link href="/login">
                <Button
                  variant="default"
                  size="sm"
                  className="w-full"
                >
                  ✨ Masuk / Daftar
                </Button>
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  )
}
