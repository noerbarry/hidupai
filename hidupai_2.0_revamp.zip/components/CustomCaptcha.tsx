'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

interface CustomCaptchaProps {
  onVerify: (text: string) => void
}

export default function CustomCaptcha({ onVerify }: CustomCaptchaProps) {
  const [refreshKey, setRefreshKey] = useState(Date.now())
  const [userInput, setUserInput] = useState('')

  const handleRefresh = () => {
    setRefreshKey(Date.now())
    setUserInput('')
    onVerify('')
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setUserInput(value)
    onVerify(value)
  }

  return (
    <div className="flex flex-col sm:flex-row items-center gap-3 w-full">
      <div className="flex items-center gap-3">
        <Image
          src={`/api/custom-captcha?${refreshKey}`}
          alt="CAPTCHA"
          width={150}
          height={50}
          className="border rounded-md h-12 shadow-sm"
          onClick={handleRefresh}
          unoptimized
        />
        <Button type="button" variant="outline" onClick={handleRefresh} title="Muat ulang captcha">
          🔄
        </Button>
      </div>
      <input
        type="text"
        value={userInput}
        onChange={handleChange}
        placeholder="Ketik CAPTCHA"
        className="w-full sm:w-auto border rounded-md px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
        required
      />
    </div>
  )
}
