'use client';

import { usePathname } from 'next/navigation';
import NavbarWrapper from '@/components/NavbarWrapper';
import Footer from '@/components/Footer';

const HIDE_LAYOUT_ROUTES = ['/onboarding'];

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const hideLayout = HIDE_LAYOUT_ROUTES.some((p) =>
    pathname.startsWith(p)
  );

  return (
    <div className="min-h-screen flex flex-col">
      {!hideLayout && <NavbarWrapper />}

      <main
        className={
          hideLayout
            ? 'flex-1'
            : 'flex-1 pt-6 sm:pt-8 md:pt-10'
        }
      >
        {children}
      </main>

      {!hideLayout && <Footer />}
    </div>
  );
}
