'use client'

import { useEffect, useState } from 'react'

interface Friend {
  name: string
  email: string
  created_at: string
  isPremium: boolean
}

export default function ReferralFriends() {
  const [friends, setFriends] = useState<Friend[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchFriends = async () => {
      try {
        const res = await fetch('/api/referral/friends')
        const data = await res.json()
        setFriends(data.friends || [])
      } catch (error) {
        console.error('Failed to fetch referral friends', error)
      } finally {
        setLoading(false)
      }
    }

    fetchFriends()
  }, [])

  return (
    <div className="mt-6 p-4 border rounded-xl shadow-sm bg-white dark:bg-slate-800">
      <h2 className="text-lg font-bold mb-3">👥 Teman yang Join dari Linkmu</h2>

      {loading ? (
        <p className="text-sm text-gray-500 dark:text-gray-400">Loading data...</p>
      ) : friends.length === 0 ? (
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Belum ada yang join lewat referral kamu 😢
        </p>
      ) : (
        <ul className="space-y-3">
          {friends.map((friend, idx) => (
            <li
              key={idx}
              className="flex justify-between items-start border-b pb-2 last:border-none"
            >
              <div>
                <div className="font-medium text-sm text-slate-900 dark:text-white">{friend.name || 'Tidak diketahui'}</div>
                <div className="text-xs text-gray-500">{friend.email}</div>
                <div className="text-xs text-gray-400">
                  Bergabung: {new Date(friend.created_at).toLocaleDateString('id-ID')}
                </div>
              </div>
              <div
                className={`text-xs px-2 py-1 rounded font-medium ${
                  friend.isPremium
                    ? 'bg-green-100 text-green-700'
                    : 'bg-yellow-100 text-yellow-700'
                }`}
              >
                {friend.isPremium ? 'Premium' : 'Belum Upgrade'}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
