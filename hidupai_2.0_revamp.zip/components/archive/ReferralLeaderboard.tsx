'use client'

import { useEffect, useState } from 'react'

interface LeaderboardUser {
  name: string
  referral_points: number
  badge: string
}

export default function ReferralLeaderboard() {
  const [users, setUsers] = useState<LeaderboardUser[]>([])

  useEffect(() => {
    fetch('/api/referral/leaderboard')
      .then(res => res.json())
      .then(data => {
        if (data.success) setUsers(data.leaderboard || [])
      })
  }, [])

  return (
    <div className="mt-6 p-4 border rounded-xl shadow-sm bg-white dark:bg-slate-800">
      <h2 className="text-lg font-bold mb-3">🏆 Referral Leaderboard</h2>
      {users.length === 0 ? (
        <p className="text-sm text-gray-500">Belum ada yang masuk leaderboard.</p>
      ) : (
        <ol className="space-y-2 list-decimal list-inside text-sm">
          {users.map((u, i) => (
            <li key={i} className="flex justify-between items-center">
              <span>
                {u.name || 'Anonim'} — <span className="text-gray-500 italic">{u.badge}</span>
              </span>
              <span className="text-indigo-600 font-semibold">
                {u.referral_points} poin
              </span>
            </li>
          ))}
        </ol>
      )}
    </div>
  )
}
