import Link from 'next/link'
import Image from 'next/image'

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 pt-8 pb-10 text-center text-gray-500">
      {/* Logo */}
      <div className="mb-4">
        <Image
          src="/images/logo-hidupai.png"
          alt="Logo HidupAI"
          width={60}
          height={60}
          className="mx-auto"
        />
      </div>

      {/* Navigation */}
      <nav className="flex flex-wrap justify-center gap-x-4 gap-y-2 text-sm font-light mb-4">
        <Link href="/" className="hover:text-blue-600">Beranda</Link>
        <Link href="/pricing" className="hover:text-blue-600">Harga</Link>
        <Link href="/about" className="hover:text-blue-600">Tentang</Link>
        <Link href="/faq" className="hover:text-blue-600">FAQ</Link>
        <Link href="/contact" className="hover:text-blue-600">Contact</Link>
        <Link href="/terms-and-conditions" className="hover:text-blue-600">
          Term &amp; Conditions
        </Link>
        <Link href="/disclaimer" className="hover:text-blue-600">Disclaimer</Link>
      </nav>

      {/* Brand Line */}
      <p className="text-xs text-gray-400 mt-2">
        HidupAI™ — Powered by{' '}
        <Link
          href="https://pabar.id"
          target="_blank"
          className="font-semibold text-gray-700 hover:text-blue-600"
        >
          PABAR 🇮🇩
        </Link>
      </p>

      <p className="text-xs text-gray-400">
        Dibangun dengan cinta ❤️, kesadaran 🌿, dan secangkir kopi ☕
      </p>

      {/* Second Line */}
      <p className="text-xs mt-2">
        <Link href="/pricing" className="underline hover:text-blue-500">
          Lihat Premium
        </Link>{' '}
        ·{' '}
        <Link href="/terms-and-conditions" className="underline hover:text-blue-500">
          Kebijakan Privasi
        </Link>{' '}
        ·{' '}
        <Link href="/about" className="underline hover:text-blue-500">
          Tentang
        </Link>
      </p>
    </footer>
  )
}
