// File: components/WhyHidupAI.tsx

export default function WhyHidupAI() {
    const points = [
      '🤖 AI yang paham kamu secara personal',
      '🎯 Fokus ke tujuan hidup, bukan sekadar tanya-jawab',
      '🔒 Aman, tanpa harus berbagi seluruh riwayat percakapan',
      '☕ Dibangun dari Indonesia, dengan cinta & kopi'
    ]
  
    return (
      <section className="max-w-4xl mx-auto text-center mb-12 space-y-4">
        <h2 className="text-2xl font-semibold text-gray-800">Kenapa HidupAI?</h2>
        <ul className="space-y-2 text-gray-600 text-sm">
          {points.map((point, idx) => (
            <li key={idx} className="flex justify-center items-center gap-2">
              <span>{point}</span>
            </li>
          ))}
        </ul>
      </section>
    )
  }
  