#!/bin/bash

echo "📦 Mengarsipkan semua file dan folder referral ke legacy/referral..."

mkdir -p legacy/referral
mkdir -p components/archive
mkdir -p app/api/archive/referral

# 🔁 Pindahkan file dan folder UI (halaman)
mv app/referral/legacy.tsx legacy/referral/app-referral-legacy.tsx 2>/dev/null
mv app/referral/page.tsx legacy/referral/app-referral-page.tsx 2>/dev/null
mv app/referral/leaderboard/page.tsx legacy/referral/app-leaderboard-page.tsx 2>/dev/null

# 🔁 Pindahkan folder /refer
mv app/refer legacy/referral/app-refer 2>/dev/null

# 🔁 Pindahkan API referral
mv app/api/referral legacy/referral/api-referral 2>/dev/null

# 🔁 Pindahkan komponen referral
mv components/ReferralShare.tsx legacy/referral/ReferralShare.tsx 2>/dev/null
mv components/ReferralFriends.tsx legacy/referral/ReferralFriends.tsx 2>/dev/null
mv components/ReferralLeaderboard.tsx legacy/referral/ReferralLeaderboard.tsx 2>/dev/null

# 📝 Tambahkan README
cat <<EOF > legacy/referral/README.md
# Arsip Fitur Referral HidupAI

Semua file UI & API referral dipindahkan ke folder ini pada $(date +%d-%m-%Y).
EOF

echo "✅ Semua file referral telah diarsipkan ke folder legacy/referral/"

