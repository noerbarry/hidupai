/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Send, Mic, User, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

type MessageType = { role: 'user' | 'assistant'; content: string };

export default function OnboardingPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClientComponentClient(), []);

  // refs
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // state: profil & chat
  const [name, setName] = useState<string>('');
  const [goal, setGoal] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [isPremium, setIsPremium] = useState<boolean>(false);
  const [usageToday, setUsageToday] = useState<number>(0);

  // state: upgrade
  const [upgrading, setUpgrading] = useState<boolean>(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState<boolean>(false);
  const [upgradeError, setUpgradeError] = useState<boolean>(false);
  const [lastAmount, setLastAmount] = useState<number | null>(null);

  // state: voice
  const [listening, setListening] = useState<boolean>(false);
  const showUpgradeCTA = !isPremium && messages.length === 0;

  // state: habit logging
  const [habitText, setHabitText] = useState<string>('');
  const [habitSaving, setHabitSaving] = useState<boolean>(false);

  // quick habit suggestions
  const quickHabits = [
    'Olahraga pagi',
    'Jurnal 5 menit',
    'Baca 10 menit',
    'Meditasi pendek',
  ];

  // dynamically loaded component
  const LifeRankCard = useMemo(
    () => dynamic(() => import('@/components/LifeRankCard'), { ssr: false }),
    []
  );

  // typing indicator
  const TypingDots = () => (
    <div className="flex items-center gap-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="w-2 h-2 bg-[#2563EB] rounded-full animate-bounce"
          style={{ animationDelay: `${i * 0.2}s` }}
        />
      ))}
    </div>
  );

  /* ============================
   *  VOICE INPUT
   * ==========================*/
  const initVoice = useCallback(() => {
    if (typeof window === 'undefined') return;
    const RecClass = (window as any).webkitSpeechRecognition;
    if (typeof RecClass !== 'function') return;

    const rec = new RecClass();
    rec.lang = 'id-ID';
    rec.interimResults = false;
    rec.onresult = (e: any) => {
      setInput(e.results[0][0].transcript);
      inputRef.current?.focus();
    };
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
  }, []);

  const toggleListening = useCallback(() => {
    const rec = recognitionRef.current;
    if (!rec) return;
    if (listening) rec.stop();
    else rec.start();
    setListening((v) => !v);
  }, [listening]);

  /* ============================
   *  LOAD PROFILE + USAGE
   * ==========================*/
  useEffect(() => {
    initVoice();
    let isMounted = true;
    const ctl = new AbortController();

    async function loadProfile() {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();

        if (!session?.access_token) {
          router.push('/login');
          return;
        }

        // profil
        const res = await fetch('/api/check-user', {
          signal: ctl.signal,
          headers: { Authorization: `Bearer ${session.access_token}` },
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          router.push('/register');
          return;
        }

        if (isMounted) {
          setEmail(data.email);
          setName(data.name);
          setGoal(data.goal);
          setIsPremium(data.is_premium);
        }

        // usage (free)
        if (!data.is_premium && isMounted) {
          const uRes = await fetch('/api/usage', {
            signal: ctl.signal,
            headers: { Authorization: `Bearer ${session.access_token}` },
          });
          const uData = await uRes.json();
          if (uRes.ok) {
            // aman kalau API lama/punya field success
            setUsageToday(uData.usage_today ?? 0);
          }
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.error(err);
          toast.error('Gagal memuat profil');
        }
      }
    }

    loadProfile();
    return () => {
      isMounted = false;
      ctl.abort();
    };
  }, [initVoice, supabase, router]);

  // auto scroll on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  /* ============================
   *  CHAT HANDLER
   * ==========================*/
  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text) return;

    if (!isPremium && usageToday >= 5) {
      setUpgradeError(false);
      setUpgradeModalOpen(true);
      return;
    }

    const userMsg: MessageType = { role: 'user', content: text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No session');

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          name,
          goal,
          email,
        }),
      });

      const d = await res.json();
      if (!res.ok || d.error) {
        throw new Error(d.error || 'Chat error');
      }

      setMessages((m) => [
        ...m,
        { role: 'assistant', content: d.message as string },
      ]);
      setUsageToday((u) => u + 1);
    } catch (err: any) {
      console.error(err);
      toast.error('Gagal mengirim pesan');
    } finally {
      setLoading(false);
    }
  }, [input, isPremium, usageToday, messages, name, goal, email, supabase]);

  /* ============================
   *  MIDTRANS UPGRADE
   * ==========================*/
  const handleUpgrade = useCallback(
    async (amount: number) => {
      setUpgradeError(false);
      setLastAmount(amount);
      setUpgrading(true);
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();
        if (!session?.access_token) throw new Error('No session');

        const res = await fetch('/api/snap-token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            email,
            amount,
            plan_type: amount === 15000 ? 'trial' : 'pro',
          }),
        });

        const d = await res.json();
        if (!res.ok || d.error) {
          throw new Error(d.error || 'Snap token error');
        }

        const snap = (window as any).snap;
        if (d.token && typeof snap?.pay === 'function') {
          snap.pay(d.token, {
            onSuccess: () => {
              toast.success('✅ Pembayaran berhasil');
              router.refresh();
            },
            onPending: () => toast('⏳ Menunggu konfirmasi'),
            onError: () => {
              setUpgradeError(true);
              toast.error('❌ Pembayaran gagal');
            },
            onClose: () => {
              setUpgradeError(true);
              toast.error('❌ Transaksi dibatalkan');
            },
          });
        } else {
          throw new Error('Midtrans Snap tidak tersedia');
        }
      } catch (err: any) {
        console.error('[Upgrade Error]', err);
        setUpgradeError(true);
        toast.error('⚠️ Gagal memproses pembayaran');
      } finally {
        setUpgrading(false);
      }
    },
    [email, supabase, router]
  );

  /* ============================
   *  HABIT LOGGING (REST + SERVICE KEY)
   * ==========================*/
  const handleLogHabit = useCallback(async () => {
    const text = habitText.trim();
    if (!text || !email) return;

    try {
      setHabitSaving(true);

      const res = await fetch('/api/habit/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: text, // di backend dipetakan ke habit_name
          email,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Gagal mencatat kebiasaan');
      }

      toast.success('✅ Kebiasaan hari ini tercatat');
      setHabitText('');
    } catch (err: any) {
      console.error('[Habit Log Error]', err);
      toast.error(err?.message || '⚠️ Gagal mencatat kebiasaan');
    } finally {
      setHabitSaving(false);
    }
  }, [habitText, email]);

  /* ============================
   *  LOGOUT
   * ==========================*/
  const handleLogout = useCallback(async () => {
    await supabase.auth.signOut();
    router.push('/login');
  }, [supabase, router]);

  /* ============================
   *  RENDER
   * ==========================*/
  return (
    <main className="min-h-screen bg-[#F5F7FA] text-[#1F2937]">
      {/* HEADER DALAM APP (di bawah navbar global) */}
      <header className="sticky top-0 z-30 border-b border-gray-200 bg-white/95 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="rounded-full bg-[#1A73E8]/10 w-9 h-9 flex items-center justify-center">
              <User className="w-5 h-5 text-[#1A73E8]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-semibold">
                Hai, {name || 'teman'} 👋
              </h2>
              <p className="text-xs sm:text-sm text-gray-500">
                Tujuanmu saat ini:{' '}
                <span className="font-medium text-[#1A73E8]">
                  {goal || 'belum diatur'}
                </span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs sm:text-sm">
            <button
              onClick={() => router.push('/dashboard')}
              className="hidden sm:inline-flex items-center gap-1 text-[#1A73E8] hover:underline"
            >
              📊 Dashboard
            </button>
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-full bg-[#111827] text-white text-xs sm:text-sm hover:bg-black/80 transition"
            >
              Keluar
            </button>
          </div>
        </div>
      </header>

      {/* CONTENT */}
      <section className="max-w-4xl mx-auto px-4 pt-4 pb-[calc(env(safe-area-inset-bottom)+160px)] space-y-4">
        {/* PROGRESS + INFO */}
        {!isPremium && (
          <div className="mb-2 bg-white rounded-2xl shadow-sm border border-gray-200 px-4 py-3">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs font-medium text-gray-600">
                Langkah pendampingan hari ini
              </p>
              <p className="text-xs text-gray-500">
                💬 {usageToday}/5 chat gratis hari ini
              </p>
            </div>
            <Progress value={(usageToday / 5) * 100} />
          </div>
        )}

        {/* PREMIUM HIGHLIGHT UNTUK USER PREMIUM */}
        {isPremium && (
          <div className="flex flex-col gap-3 mb-3">
            <div className="inline-flex items-center gap-2 self-start bg-gradient-to-r from-[#1A73E8] to-[#2563EB] text-white px-3 py-1 rounded-full text-xs font-semibold shadow-sm">
              <span>Premium aktif</span> 🚀
            </div>
            <div className="bg-white border border-blue-100 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
              <LifeRankCard email={email} isPremium={isPremium} />
              <div className="bg-[#FFF7E5] border border-[#FBBF24]/40 text-[#92400E] px-4 py-3 rounded-xl text-xs sm:text-sm">
                <h3 className="font-semibold mb-1">
                  🔮 Sudah coba{' '}
                  <button
                    onClick={() => router.push('/life-arena')}
                    className="underline text-[#1A73E8]"
                  >
                    Life Arena Pro
                  </button>
                  ?
                </h3>
                <p>
                  Simulasikan keputusan besar hidupmu dengan AI yang memahami
                  emosi dan tujuanmu.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* UPGRADE CTA SAAT BELUM ADA CHAT */}
        {showUpgradeCTA && (
          <div className="mb-4 max-w-xl mx-auto">
            <div className="mb-3 text-center space-y-1">
              <h3 className="text-sm sm:text-base font-semibold text-[#0E3A7B]">
                Pilih cara HidupAI mendampingimu
              </h3>
              <p className="text-xs sm:text-sm text-gray-600">
                Kamu bisa mulai dengan trial singkat atau langsung ke Premium.
                Versi gratis tetap bisa dipakai kapan saja.
              </p>
            </div>
            <div className="p-4 sm:p-5 bg-white rounded-2xl shadow border border-gray-200 space-y-3">
              <Button
                onClick={() => setUpgradeModalOpen(true)}
                disabled={upgrading}
                className="w-full mb-2 bg-[#1A73E8] hover:bg-[#1558B8] text-white rounded-xl flex items-center justify-center gap-2 py-3 text-sm"
              >
                <Mic className="w-5 h-5" /> Trial 7 Hari — Rp15.000
              </Button>
              <Button
                variant="outline"
                onClick={() => setUpgradeModalOpen(true)}
                disabled={upgrading}
                className="w-full border-2 border-[#1A73E8] text-[#1A73E8] hover:bg-[#E8F1FF] rounded-xl flex items-center justify-center gap-2 py-3 text-sm"
              >
                <Send className="w-5 h-5" /> Premium — Rp79.000
              </Button>
              <p className="text-[11px] text-gray-500 text-center">
                Atau lanjut dulu dengan{' '}
                <span className="font-semibold text-[#1A73E8]">
                  versi gratis (5 chat/hari)
                </span>{' '}
                dan coba rasakan ritme refleksinya.
              </p>
            </div>
          </div>
        )}

        {/* CHAT MESSAGES */}
        <div
          className="overflow-y-auto bg-white rounded-2xl shadow-sm border border-gray-200 px-3 sm:px-4 py-4"
          style={{
            maxHeight: showUpgradeCTA
              ? 'calc(100vh - 270px - 200px)'
              : 'calc(100vh - 220px - 200px)',
          }}
        >
          {messages.length === 0 && !loading ? (
            <div className="text-center text-sm text-gray-500 py-10">
              <div className="text-3xl mb-2">🌱</div>
              <p className="text-base font-medium text-[#0F172A]">
                Aku siap mendengar ceritamu, {name || 'teman'}.
              </p>
              <p className="mt-2 text-xs sm:text-sm text-gray-500 max-w-sm mx-auto leading-relaxed">
                Tulis apa pun yang sedang kamu rasakan, pikirkan, atau alami
                hari ini. Kita akan memetakannya pelan-pelan, tanpa menghakimi.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  } text-sm`}
                >
                  <div
                    className={`max-w-[72%] px-5 py-3 rounded-3xl shadow-sm border ${
                      msg.role === 'user'
                        ? 'bg-[#E3F2FF] text-[#0B3B82] border-[#BFDBFE]'
                        : 'bg-[#FFF7E5] text-[#7C2D12] border-[#FCD34D]'
                    }`}
                    style={{ lineHeight: 1.55 }}
                  >
                    {msg.content}
                    {msg.role === 'assistant' && (
                      <div className="text-[10px] text-gray-400 mt-1 italic">
                        HidupAI
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex items-center gap-2 text-sm text-gray-500 px-2 py-1">
                  <TypingDots /> <span>HidupAI sedang berpikir…</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* AJAKAN KECIL */}
        <div className="pt-2 text-center text-xs sm:text-sm text-gray-500 flex items-center justify-center gap-2">
          <span className="text-green-500">🌱</span>
          <span>
            Cerita kecil hari ini akan jadi jejak penting dalam perjalananmu
            bersama HidupAI.
          </span>
        </div>

        {/* 📝 CATAT KEBIASAAN HARI INI */}
        <div className="mt-3 max-w-xl mx-auto">
          <div className="bg-white border border-gray-200 rounded-2xl shadow-sm px-4 py-3 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-semibold text-[#111827]">
                📝 Catat Kebiasaan Hari Ini
              </p>
              <p className="text-[11px] text-gray-400">
                Masuk ke grafik di Dashboard
              </p>
            </div>

            <p className="text-xs text-gray-500">
              Tulis <span className="font-medium">satu hal kecil</span> yang
              kamu lakukan hari ini yang mendukung tujuanmu. Cukup 1 kalimat
              singkat.
            </p>

            {/* QUICK PICK */}
            <div className="flex flex-wrap gap-2 mt-1">
              {quickHabits.map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => setHabitText(h)}
                  className="px-3 py-1 rounded-full border text-[11px] sm:text-xs
                             border-gray-200 bg-gray-50 hover:bg-gray-100
                             text-gray-700 transition"
                >
                  {h}
                </button>
              ))}
            </div>

            {!email && (
              <p className="text-[11px] text-amber-600 mt-1">
                ⏳ Menyiapkan sesi kamu... kebiasaan bisa dicatat setelah profil
                selesai dimuat.
              </p>
            )}

            <div className="flex flex-col sm:flex-row gap-2 mt-2">
              <Input
                value={habitText}
                onChange={(e) => setHabitText(e.target.value)}
                onKeyDown={(e) =>
                  e.key === 'Enter' &&
                  !habitSaving &&
                  !!habitText.trim() &&
                  !!email &&
                  handleLogHabit()
                }
                placeholder="Contoh: Olahraga pagi 10 menit"
                disabled={habitSaving || !email}
                className="flex-1 text-sm"
              />
              <Button
                onClick={handleLogHabit}
                disabled={habitSaving || !habitText.trim() || !email}
                className="sm:w-28 rounded-xl text-sm"
              >
                {habitSaving ? 'Menyimpan…' : 'Tandai hari ini'}
              </Button>
            </div>

            <p className="text-[11px] text-gray-400">
              Konsisten isi 1x per hari supaya pola kebiasaanmu terbaca jelas di
              laporan mingguan.
            </p>
          </div>
        </div>
      </section>

      {/* INPUT BAR */}
      <div className="fixed inset-x-0 bottom-0 bg-white/95 backdrop-blur-xl px-4 py-4 shadow-inner z-40 pb-[calc(env(safe-area-inset-bottom)+4px)]">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <button
            aria-label={listening ? 'Hentikan input suara' : 'Mulai input suara'}
            onClick={toggleListening}
            disabled={loading || upgrading}
            className={`p-3 rounded-full transition ${
              listening ? 'bg-[#1A73E8]/20' : 'hover:bg-gray-100'
            }`}
          >
            <Mic className="w-5 h-5 text-[#1A73E8]" />
          </button>
          <Input
            ref={inputRef}
            value={input}
            placeholder="Ceritakan apa yang kamu rasakan atau pikirkan..."
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={loading || upgrading}
            className="flex-1 bg-[#F9FAFB] border-gray-300 rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#1A73E8]"
          />
          <Button
            onClick={handleSend}
            disabled={loading || upgrading || (!isPremium && usageToday >= 5)}
            className={`px-6 flex items-center gap-2 rounded-2xl text-sm transition shadow-sm ${
              !isPremium && usageToday >= 5
                ? 'bg-gray-400 cursor-not-allowed text-gray-100'
                : 'bg-gradient-to-r from-[#1A73E8] to-[#1558B8] hover:opacity-95 text-white'
            }`}
          >
            <Send className="w-4 h-4" />
            {!isPremium && usageToday >= 5 ? 'Upgrade untuk lanjut' : 'Kirim'}
          </Button>
        </div>
      </div>

      {/* UPGRADE MODAL */}
      {upgradeModalOpen && (
        <>
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
          <div className="fixed inset-x-0 bottom-0 z-50 max-h-[52vh] bg-white rounded-t-2xl p-6 space-y-4 shadow-2xl">
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-2" />
            {upgradeError && lastAmount && (
              <div className="bg-red-50 text-red-800 px-4 py-2 rounded-md mb-2 text-sm flex items-center gap-2">
                <XCircle className="w-4 h-4" />
                <span>Transaksi dibatalkan.</span>
                <button
                  onClick={() => handleUpgrade(lastAmount)}
                  className="underline text-red-700"
                >
                  Coba lagi
                </button>
              </div>
            )}
            <h2 className="text-base sm:text-lg font-semibold text-[#0F172A]">
              Pilih paket pendampingan
            </h2>
            <p className="text-xs sm:text-sm text-gray-600">
              Kuota chat gratismu hari ini sudah habis. Pilih paket agar
              pendampingan bisa lanjut tanpa terputus.
            </p>
            <div className="space-y-3 mt-2">
              <Button
                onClick={() => handleUpgrade(15000)}
                disabled={upgrading}
                className="w-full bg-[#1A73E8] hover:bg-[#1558B8] text-white rounded-2xl flex items-center justify-center gap-2 py-3 text-sm"
              >
                <Mic className="w-5 h-5" /> Coba 7 Hari Penuh — Rp15.000
              </Button>
              <Button
                variant="outline"
                onClick={() => handleUpgrade(79000)}
                disabled={upgrading}
                className="w-full border-2 border-[#1A73E8] text-[#1A73E8] hover:bg-[#E8F1FF] rounded-2xl flex items-center justify-center gap-2 py-3 text-sm"
              >
                <Send className="w-5 h-5" /> Pendampingan Penuh — Rp79.000/bulan
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  setUpgradeError(false);
                  setUpgradeModalOpen(false);
                }}
                className="w-full text-center text-gray-500 text-sm"
              >
                Batal
              </Button>
            </div>
          </div>
        </>
      )}
    </main>
  );
}
