'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@supabase/supabase-js'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Line, Pie } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js'

ChartJS.register(LineElement, PointElement, CategoryScale, LinearScale, Tooltip, Legend, ArcElement)

interface User {
  id: string
  email: string
  name: string
  goal: string
  plan_type?: string
  premium_until?: string
  last_question?: string
  last_response?: string
  created_at: string
}

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

const ADMIN_SECRET = process.env.NEXT_PUBLIC_ADMIN_SECRET!

function isUserPremium(user: User): boolean {
  if (!user.plan_type || !user.premium_until) return false
  const today = new Date().toISOString().split('T')[0]
  return ['premium', 'pro', 'trial'].includes(user.plan_type) && user.premium_until >= today
}

function downloadCSV(users: User[]) {
  const headers = ['Email', 'Nama', 'Goal', 'Plan', 'Premium Until', 'Created At']
  const rows = users.map((u) => [
    u.email,
    u.name || '-',
    u.goal || '-',
    u.plan_type || '-',
    u.premium_until || '-',
    u.created_at
  ])
  const csvContent = [headers, ...rows]
    .map((e) => e.map((cell) => `"${cell}"`).join(','))
    .join('\n')
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.setAttribute('download', 'hidupai_users.csv')
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [accessGranted, setAccessGranted] = useState(false)
  const [inputPassword, setInputPassword] = useState('')
  const [filterRange, setFilterRange] = useState('30')
  const pathname = usePathname()

  useEffect(() => {
    const stored = sessionStorage.getItem('admin-pass')
    if (stored === ADMIN_SECRET) {
      setAccessGranted(true)
    }
  }, [])

  const handleUnlock = () => {
    if (inputPassword === ADMIN_SECRET) {
      sessionStorage.setItem('admin-pass', inputPassword)
      setAccessGranted(true)
    } else {
      alert('Kode rahasia salah')
    }
  }

  useEffect(() => {
    const getUsers = async () => {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: true })

      if (!error) setUsers(data || [])
      setLoading(false)
    }

    if (accessGranted) getUsers()
  }, [accessGranted])

  const filtered = users.filter(
    (u) =>
      u.name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase())
  )

  const totalUsers = users.length
  const totalPremium = users.filter((u) => isUserPremium(u)).length
  const totalFree = totalUsers - totalPremium

  const now = new Date()
  const filterDays = parseInt(filterRange)
  const filteredByDate = users.filter((u) => {
    const date = new Date(u.created_at)
    return date >= new Date(now.getTime() - filterDays * 24 * 60 * 60 * 1000)
  })

  const chartData = (() => {
    const growthMap: Record<string, number> = {}
    filteredByDate.forEach((u) => {
      const date = new Date(u.created_at).toISOString().split('T')[0]
      growthMap[date] = (growthMap[date] || 0) + 1
    })
    const sortedDates = Object.keys(growthMap).sort()
    let cumulative = 0
    const labels = sortedDates
    const data = sortedDates.map((date) => {
      cumulative += growthMap[date]
      return cumulative
    })
    return {
      labels,
      datasets: [
        {
          label: 'Total Pengguna',
          data,
          fill: true,
          tension: 0.4,
          borderColor: '#2563eb',
          backgroundColor: 'rgba(37, 99, 235, 0.1)',
          pointBackgroundColor: '#2563eb'
        }
      ]
    }
  })()

  const goalBreakdown = (() => {
    const goalMap: Record<string, number> = {}
    users.forEach((u) => {
      const goal = u.goal?.toLowerCase().trim() || 'lainnya'
      goalMap[goal] = (goalMap[goal] || 0) + 1
    })
    const labels = Object.keys(goalMap)
    const data = labels.map((l) => goalMap[l])
    return {
      labels,
      datasets: [
        {
          label: 'Tujuan Hidup',
          data,
          backgroundColor: [
            '#60a5fa',
            '#4ade80',
            '#facc15',
            '#f87171',
            '#a78bfa',
            '#f472b6',
            '#fb923c',
            '#38bdf8',
            '#e879f9'
          ]
        }
      ]
    }
  })()

  if (!accessGranted) {
    return (
      <main className="max-w-sm mx-auto mt-40 text-center space-y-4">
        <h1 className="text-xl font-bold">🔐 Akses Terbatas</h1>
        <p className="text-sm text-gray-500">Masukkan kode rahasia admin</p>
        <Input
          type="password"
          value={inputPassword}
          onChange={(e) => setInputPassword(e.target.value)}
          placeholder="Kode Admin"
        />
        <Button onClick={handleUnlock}>Masuk</Button>
      </main>
    )
  }

  return (
    <main className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">📊 Dashboard Admin — HidupAI</h1>

      <div className="flex gap-2 mb-6">
        <Link href="/admin">
          <Button variant={pathname === '/admin' ? 'default' : 'outline'}>👥 Pengguna</Button>
        </Link>
        <Link href="/admin/orders">
          <Button variant={pathname === '/admin/orders' ? 'default' : 'outline'}>💳 Transaksi</Button>
        </Link>
        <Button onClick={() => downloadCSV(users)} variant="outline">⬇️ Export CSV</Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl text-center">
          <p className="text-sm text-blue-600">Total Pengguna</p>
          <p className="text-2xl font-bold text-blue-800">{totalUsers}</p>
        </div>
        <div className="bg-green-50 border border-green-200 p-4 rounded-xl text-center">
          <p className="text-sm text-green-600">Pengguna Premium</p>
          <p className="text-2xl font-bold text-green-800">{totalPremium}</p>
        </div>
        <div className="bg-gray-50 border border-gray-200 p-4 rounded-xl text-center">
          <p className="text-sm text-gray-600">Pengguna Free</p>
          <p className="text-2xl font-bold text-gray-800">{totalFree}</p>
        </div>
      </div>

      <div className="mb-10">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-lg font-semibold">📈 Grafik Pertumbuhan Pengguna</h2>
          <select
            value={filterRange}
            onChange={(e) => setFilterRange(e.target.value)}
            className="text-sm border rounded px-2 py-1 bg-white"
          >
            <option value="7">7 Hari</option>
            <option value="30">30 Hari</option>
            <option value="90">90 Hari</option>
            <option value="180">180 Hari</option>
            <option value="365">1 Tahun</option>
          </select>
        </div>
        <div className="bg-white border rounded-xl p-4">
          <Line data={chartData} />
        </div>
      </div>

      <div className="mb-10">
        <h2 className="text-lg font-semibold mb-2">🥅 Breakdown Goal Pengguna</h2>
        <div className="bg-white border rounded-xl p-4">
          <Pie data={goalBreakdown} />
        </div>
      </div>

      <Input
        placeholder="Cari berdasarkan nama atau email..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-6"
      />

      {loading ? (
        <p>Memuat data pengguna...</p>
      ) : filtered.length === 0 ? (
        <p className="text-center text-gray-500">Tidak ada pengguna ditemukan.</p>
      ) : (
        <div className="grid gap-4">
          {filtered.map((user) => (
            <Card key={user.id} className="border rounded-xl">
              <CardContent className="p-4 space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold">
                      {user.name || 'Tanpa Nama'} ({user.email})
                    </p>
                    <p className="text-sm text-gray-500">🎯 {user.goal || '—'}</p>
                  </div>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      isUserPremium(user)
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {isUserPremium(user) ? 'Premium' : 'Free'}
                  </span>
                </div>

                {user.last_question && (
                  <div className="text-sm text-yellow-900 bg-yellow-50 p-3 rounded">
                    <p className="mb-1 font-medium">💡 Terakhir ditanyakan:</p>
                    <p className="italic">{user.last_question}</p>
                    <p className="mt-2 text-[13px] text-yellow-700">
                      🧠 {user.last_response || '—'}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </main>
  )
}