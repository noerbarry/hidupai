// File: app/faq/page.tsx
'use client';

import Image from 'next/image';
import Link from 'next/link';

export default function FAQPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-blue-50/60 to-blue-100/40 pt-28 pb-16">
      <div className="max-w-4xl mx-auto px-6 text-gray-800 space-y-12">
        {/* ====== HEADER / HERO FAQ ====== */}
        <header className="space-y-6">
          {/* Breadcrumb + Chip */}
          <div className="flex items-center justify-between gap-3 text-xs sm:text-sm">
            <Link
              href="/"
              className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
            >
              ← Kembali ke Beranda
            </Link>

            <span className="inline-flex items-center rounded-full bg-blue-50 border border-blue-100 px-3 py-1 font-medium text-blue-700">
              FAQ HidupAI
            </span>
          </div>

          {/* Logo + Intro */}
          <div className="flex flex-col items-center text-center">
            <Image
              src="/images/logo-hidupai.png"
              alt="Logo HidupAI"
              width={110}
              height={110}
              className="mb-3 drop-shadow-sm"
            />
            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 leading-tight">
              Pertanyaan yang Sering Diajukan
            </h1>
            <p className="mt-3 text-sm sm:text-base text-gray-600 max-w-2xl mx-auto">
              Di sini kamu bisa menemukan jawaban singkat tentang cara kerja HidupAI,
              perbedaan paket, keamanan data, dan bagaimana AI ini mendampingi
              perjalanan hidupmu sehari-hari.
            </p>
          </div>
        </header>

        {/* ====== SECTION 1: TENTANG HIDUPAI ====== */}
        <section className="space-y-4">
          <h2 className="text-lg sm:text-xl font-semibold text-slate-900">
            1. Tentang HidupAI
          </h2>

          {/* Q1 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              1.1 Apa itu HidupAI?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              HidupAI adalah platform refleksi diri berbasis{' '}
              <strong>Agentic AI</strong> yang mendampingi kamu dalam menetapkan
              tujuan, mengelola emosi, membangun kebiasaan, dan mengecek arah hidup
              secara berkala. Tidak seperti chatbot biasa, HidupAI:
            </p>
            <ul className="mt-2 text-sm text-gray-700 space-y-1 list-disc list-inside">
              <li>Menyimpan konteks perjalanan hidupmu (memori jangka panjang).</li>
              <li>
                Memberikan refleksi mingguan otomatis (Weekly Coaching) untuk
                pengguna Premium.
              </li>
              <li>
                Membaca pola kebiasaan dan memberi insight perkembangan dari
                aktivitas yang kamu catat setiap hari.
              </li>
              <li>
                Menggunakan modul refleksi seperti <strong>Life Arena</strong> dan
                jurnal reflektif yang terhubung ke dashboard.
              </li>
            </ul>
          </div>

          {/* Q2 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              1.2 Apakah HidupAI pengganti psikolog atau psikiater?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Tidak. HidupAI adalah{' '}
              <strong>pendamping refleksi dan pengelola tujuan</strong>, bukan
              layanan kesehatan mental profesional. Untuk kondisi yang bersifat
              klinis atau darurat, kamu tetap perlu berkonsultasi dengan psikolog,
              psikiater, atau tenaga profesional terkait.
            </p>
          </div>

          {/* Q3 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              1.3 Apa itu &quot;memori jangka panjang&quot; di HidupAI?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Memori jangka panjang adalah cara HidupAI menyimpan hal-hal penting
              tentang hidupmu: tujuan, nilai, pola kebiasaan, dan topik yang sering
              kamu ceritakan. Melalui <strong>Memory Panel</strong>, kamu bisa
              melihat dan mengatur memori ini sehingga AI makin akurat dalam
              mendampingi kamu.
            </p>
          </div>
        </section>

        {/* ====== SECTION 2: AKUN, LOGIN, & HARGA ====== */}
        <section className="space-y-4">
          <h2 className="text-lg sm:text-xl font-semibold text-slate-900">
            2. Akun, Login, dan Harga
          </h2>

          {/* Q4 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              2.1 Apakah HidupAI gratis digunakan?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Ya. HidupAI menyediakan <strong>versi gratis</strong> dengan kuota{' '}
              <strong>5 percakapan per hari</strong>. Ini cukup untuk kamu mulai
              eksplorasi, menulis refleksi, dan merasakan ritme pendampingan AI.
            </p>
          </div>

          {/* Q5 – Paket Gratis vs Premium */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              2.2 Apa perbedaan paket Gratis dan Premium?
            </h3>

            <div className="mt-3 grid gap-4 md:grid-cols-2 text-sm">
              {/* Paket Gratis */}
              <div className="rounded-xl border border-gray-200 bg-gray-50 p-4">
                <p className="text-xs font-semibold text-gray-700 mb-1">
                  Paket Gratis
                </p>
                <ul className="text-gray-700 space-y-1 list-disc list-inside">
                  <li>5 chat per hari dengan HidupAI.</li>
                  <li>
                    Refleksi harian dasar lewat layar onboarding &amp; percakapan
                    utama.
                  </li>
                  <li>
                    Tombol <strong>📝 Catat Kebiasaan Hari Ini</strong> untuk
                    menandai satu kebiasaan penting per hari.
                  </li>
                  <li>
                    Akses dasar ke <strong>LifeRank</strong> &amp;{' '}
                    <strong>Memory Panel</strong>.
                  </li>
                </ul>
              </div>

              {/* Paket Premium */}
              <div className="rounded-xl border border-blue-200 bg-blue-50 p-4">
                <p className="text-xs font-semibold text-blue-800 mb-1">
                  Paket Premium
                </p>
                <ul className="text-blue-900 space-y-1 list-disc list-inside">
                  <li>Chat jauh lebih leluasa (tanpa batas harian, fair-use).</li>
                  <li>
                    <strong>Weekly Coaching</strong> otomatis: refleksi mingguan
                    yang dirangkum oleh AI.
                  </li>
                  <li>
                    <strong>Life Arena Pro</strong> di dashboard untuk simulasi
                    keputusan hidup.
                  </li>
                  <li>
                    Grafik dan <strong>insight kebiasaan mingguan</strong> dari
                    data kebiasaan yang kamu catat setiap hari.
                  </li>
                  <li>
                    <strong>Export PDF</strong> ringkasan mingguan &amp;{' '}
                    <strong>AI Weekly Planner</strong>.
                  </li>
                  <li>
                    Kirim planner langsung ke <strong>Notion</strong> lewat
                    integrasi yang sudah disiapkan.
                  </li>
                  <li>Prioritas dalam pengembangan &amp; uji coba fitur baru.</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Q6 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              2.3 Apakah saya perlu login untuk menggunakan HidupAI?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Ya. Login diperlukan agar HidupAI bisa:
            </p>
            <ul className="mt-1 text-sm text-gray-700 space-y-1 list-disc list-inside">
              <li>Menyimpan progres dan kebiasaan harianmu.</li>
              <li>Mengenali tujuan dan pola pikirmu dari waktu ke waktu.</li>
              <li>Memberi refleksi dan insight yang konsisten &amp; personal.</li>
            </ul>
          </div>

          {/* Q7 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              2.4 Bagaimana cara upgrade ke Premium?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Ada dua cara:
            </p>
            <ul className="mt-1 text-sm text-gray-700 space-y-1 list-disc list-inside">
              <li>
                Masuk ke aplikasi, lalu klik tombol{' '}
                <strong>&quot;Upgrade ke Premium&quot;</strong> di dashboard /
                onboarding.
              </li>
              <li>
                Atau buka halaman{' '}
                <Link href="/pricing" className="text-blue-600 underline">
                  Harga
                </Link>{' '}
                dan pilih paket yang ingin kamu gunakan.
              </li>
            </ul>
            <p className="mt-2 text-xs text-gray-500">
              Pembayaran diproses melalui penyedia pembayaran online yang aman.
              Setelah pembayaran berhasil, status akunmu akan otomatis berubah
              menjadi Premium.
            </p>
          </div>

          {/* Q8 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              2.5 Apakah tersedia aplikasi Android / iOS?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Saat ini HidupAI tersedia sebagai <strong>aplikasi web</strong> yang
              bisa diakses lewat browser di HP maupun laptop. Tampilan sudah
              dioptimalkan agar ringan dan responsif di layar mobile.
            </p>
          </div>
        </section>

        {/* ====== SECTION 3: FITUR REFLEKTIF & DASHBOARD ====== */}
        <section className="space-y-4">
          <h2 className="text-lg sm:text-xl font-semibold text-slate-900">
            3. Fitur Reflektif &amp; Dashboard
          </h2>

          {/* Q9 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              3.1 Fitur apa saja yang ada di dashboard HidupAI?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Dashboard HidupAI dirancang sebagai &quot;ruang kendali&quot; refleksi
              hidupmu. Beberapa fitur yang tersedia:
            </p>
            <ul className="mt-2 text-sm text-gray-700 space-y-1 list-disc list-inside">
              <li>
                <strong>LifeRank</strong> — gambaran singkat perjalanan dan badge
                perkembanganmu.
              </li>
              <li>
                <strong>Memory Panel</strong> — melihat dan mengatur memori jangka
                panjang HidupAI tentang kamu.
              </li>
              <li>
                <strong>Agentic Settings</strong> — mengatur mode pendampingan dan
                fokus tujuan mingguan.
              </li>
              <li>
                <strong>Weekly Coaching</strong> (Premium) — refleksi mingguan
                otomatis.
              </li>
              <li>
                <strong>Grafik kebiasaan</strong> &amp; insight (Premium) — melihat
                tren konsistensi dari catatan kebiasaan harianmu.
              </li>
              <li>
                <strong>Export PDF &amp; AI Weekly Planner</strong> (Premium),
                termasuk kirim ke Notion.
              </li>
            </ul>
          </div>

          {/* Q10 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              3.2 Apa fungsi &quot;Catat Kebiasaan Hari Ini&quot;?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Fitur <strong>📝 Catat Kebiasaan Hari Ini</strong> membantu kamu
              menandai satu tindakan kecil yang selaras dengan tujuanmu (misalnya:
              &quot;olahraga pagi&quot;, &quot;menulis jurnal 5 menit&quot;).
            </p>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Catatan ini disimpan oleh sistem dan digunakan untuk:
            </p>
            <ul className="mt-1 text-sm text-gray-700 space-y-1 list-disc list-inside">
              <li>Menampilkan grafik kebiasaan mingguan di dashboard (Premium).</li>
              <li>Memberikan insight singkat tentang tren konsistensi kamu.</li>
            </ul>
          </div>

          {/* Q11 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              3.3 Apa itu Life Arena Pro?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              <strong>Life Arena Pro</strong> (khusus Premium) adalah ruang simulasi
              keputusan hidup berbasis AI. Di sini kamu bisa &quot;mengujicoba&quot;
              skenario penting (karir, relasi, finansial, dan lain-lain) dan melihat
              pertimbangan, risiko, serta alternatif yang mungkin muncul.
            </p>
          </div>
        </section>

        {/* ====== SECTION 4: PRIVASI & KEAMANAN ====== */}
        <section className="space-y-4">
          <h2 className="text-lg sm:text-xl font-semibold text-slate-900">
            4. Privasi &amp; Keamanan Data
          </h2>

          {/* Q12 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              4.1 Apakah data saya aman di HidupAI?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Kami berupaya menjaga data kamu seaman mungkin. Data disimpan di
              infrastruktur cloud yang dikelola dengan standar keamanan modern, dan{' '}
              <strong>tidak dijual ke pihak ketiga</strong>. Data terutama digunakan
              untuk:
            </p>
            <ul className="mt-1 text-sm text-gray-700 space-y-1 list-disc list-inside">
              <li>
                Meningkatkan kualitas pendampingan dan personalisasi pengalamanmu.
              </li>
              <li>
                Mendukung fitur memori jangka panjang, insight kebiasaan, dan
                refleksi.
              </li>
            </ul>
            <p className="mt-2 text-xs text-gray-500">
              Detail lebih lengkap tentang penggunaan data akan dijelaskan di
              halaman Syarat &amp; Ketentuan serta Disclaimer.
            </p>
          </div>

          {/* Q13 */}
          <div className="rounded-2xl bg-white border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-blue-800">
              4.2 Bagaimana jika saya ingin berhenti menggunakan HidupAI?
            </h3>
            <p className="mt-2 text-sm text-gray-700 leading-relaxed">
              Kamu bisa berhenti kapan saja dengan tidak memperpanjang akses
              Premium dan berhenti login ke aplikasi. Jika ke depan kamu
              membutuhkan penghapusan data tertentu atau bantuan terkait akun,
              kamu dapat menghubungi kami melalui halaman{' '}
              <Link href="/contact" className="text-blue-600 underline">
                Contact
              </Link>
              .
            </p>
          </div>
        </section>

        {/* ====== FOOTER LINK ====== */}
        <div className="text-center mt-10">
          <Link
            href="/"
            className="text-sm text-blue-600 underline hover:text-blue-800"
          >
            ← Kembali ke Beranda HidupAI
          </Link>
        </div>
      </div>
    </main>
  );
}
