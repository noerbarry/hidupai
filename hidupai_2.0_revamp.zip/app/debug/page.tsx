'use client'

export default function Debug() {
  return (
    <pre className="p-6">
      URL: {process.env.NEXT_PUBLIC_SUPABASE_URL || 'not found'} <br />
      KEY: {process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? 'loaded' : 'not found'}
    </pre>
  )
}
