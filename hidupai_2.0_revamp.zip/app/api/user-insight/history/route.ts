import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export async function GET() {
  const supabase = createRouteHandlerClient({ cookies })
  const {
    data: { session },
  } = await supabase.auth.getSession()

  const email = session?.user?.email
  if (!email) {
    return Response.json({ insights: [] }, { status: 401 })
  }

  const { data, error } = await supabase
    .from('insight_logs')
    .select('insights, created_at')
    .eq('user_email', email)
    .order('created_at', { ascending: false })
    .limit(5)

  if (error) {
    console.error('Error fetching insight history:', error)
    return Response.json({ insights: [] }, { status: 500 })
  }

  return Response.json({ insights: data || [] })
}
