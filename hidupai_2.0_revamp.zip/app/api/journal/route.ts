import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  const { email, type, content } = await req.json()

  if (!email || !type || !content) {
    return NextResponse.json({ success: false, message: 'Data tidak lengkap.' }, { status: 400 })
  }

  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ success: false, message: 'User tidak ditemukan.' }, { status: 404 })
  }

  const today = new Date().toISOString().split('T')[0] // Format YYYY-MM-DD

  const { error: insertError } = await supabase.from('soul_journal').insert({
    user_id: user.id,
    type,
    content,
    date: today,
  })

  if (insertError) {
    return NextResponse.json({ success: false, message: 'Gagal menyimpan jurnal.' }, { status: 500 })
  }

  return NextResponse.json({ success: true, message: 'Refleksi berhasil disimpan.' })
}
