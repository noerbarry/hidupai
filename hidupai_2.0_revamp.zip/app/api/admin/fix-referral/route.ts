import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

// Init Supabase with service role key
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

function getBadge(points: number): string {
  if (points >= 30) return 'Champion'
  if (points >= 15) return 'Warrior'
  if (points >= 5) return 'Starter'
  return 'Newbie'
}

type User = {
  id: string
  referrer_code?: string
  referred_by?: string
  referral_points?: number
}

export async function GET() {
  const { data: users, error } = await supabase.from('users').select('*')
  if (error) {
    return NextResponse.json({ success: false, message: 'Gagal ambil data users.' })
  }

  const referrerMap: Record<string, number> = {}

  for (const user of users as User[]) {
    // 💡 1. Fix referral relationship
    if (user.referred_by || !user.referrer_code) continue

    const { data: referrer } = await supabase
      .from('users')
      .select('id')
      .eq('referral_code', user.referrer_code)
      .maybeSingle()

    if (referrer) {
      await supabase
        .from('users')
        .update({ referred_by: referrer.id })
        .eq('id', user.id)

      referrerMap[referrer.id] = (referrerMap[referrer.id] || 0) + 1
    }
  }

  // 💡 2. Update referral points
  const updates = Object.entries(referrerMap).map(([id, count]) => ({
    id,
    referral_points: count,
  }))

  for (const update of updates) {
    await supabase.from('users').update({
      referral_points: update.referral_points,
      badge: getBadge(update.referral_points ?? 0)
    }).eq('id', update.id)
  }

  return NextResponse.json({ success: true, total_updated: updates.length })
}
