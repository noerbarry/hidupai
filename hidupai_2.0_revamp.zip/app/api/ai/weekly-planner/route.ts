// app/api/weekly-planner/route.ts
import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { subWeeks, startOfWeek, addDays, format } from 'date-fns'
import { defaultPlannerTemplate } from '@/lib/templates'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const OPENAI_API_KEY = process.env.OPENAI_API_KEY!

export async function POST(req: Request) {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 7000)

  try {
    const { email } = await req.json()
    if (!email) {
      return NextResponse.json({ error: 'Email wajib diisi.' }, { status: 400 })
    }

    const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 })
    const weekStr = format(weekStart, 'yyyy-MM-dd')

    // ✅ Cek apakah planner minggu ini sudah ada
    const { data: existing } = await supabase
      .from('weekly_planners')
      .select('planner')
      .eq('email', email)
      .eq('week_start', weekStr)
      .maybeSingle()

    if (existing) {
      console.log(`[📌 Planner Cache] ${email} – Sudah ada planner untuk minggu ${weekStr}`)
      return NextResponse.json({ planner: existing.planner, cached: true })
    }

    const { data: user } = await supabase
      .from('users')
      .select('plan_type')
      .eq('email', email)
      .maybeSingle()

    const isPremium = user?.plan_type === 'pro' || user?.plan_type === 'super_premium'
    const model = isPremium ? 'gpt-4' : 'gpt-3.5-turbo'

    const startLastWeek = subWeeks(weekStart, 1)
    const endLastWeek = addDays(weekStart, -1)
    const startStr = format(startLastWeek, 'yyyy-MM-dd')
    const endStr = format(endLastWeek, 'yyyy-MM-dd')

    const { data: habits } = await supabase
      .from('habit_logs')
      .select('date, habit_name')
      .eq('email', email)
      .eq('completed', true)
      .gte('date', startStr)
      .lte('date', endStr)

    const logSummary = habits?.length
      ? habits.map(h => `📅 ${h.date} – ✅ ${h.habit_name}`).join('\n')
      : 'Tidak ada data yang tercatat minggu lalu.'

    const prompt = `
Berikut adalah log habit user minggu lalu:

${logSummary}

Tugas kamu sebagai AI:
Buatkan AI Weekly Habit Planner dalam format **tabel Markdown**, dan pastikan tidak menggunakan bullet list seperti "•".

Struktur output HARUS seperti ini:

# 🤔 Weekly Habit Planner – HidupAI Agentic Edition  
_Disusun otomatis berdasarkan tujuan hidup dan data kebiasaan mingguan kamu_

### Review minggu lalu:  
(Tuliskan refleksi pendek)

### Saran minggu ini:  
(Saran pendek dan actionable)

### Tabel Rencana Mingguan:

| Hari     | Rencana                                                                 |
|----------|--------------------------------------------------------------------------|
| Senin    | aktivitas 1, aktivitas 2, aktivitas 3                                    |
| Selasa   | aktivitas 1, aktivitas 2, aktivitas 3                                    |
| Rabu     | aktivitas 1, aktivitas 2, aktivitas 3                                    |
| Kamis    | aktivitas 1, aktivitas 2, aktivitas 3                                    |
| Jumat    | aktivitas 1, aktivitas 2, aktivitas 3                                    |
| Sabtu    | aktivitas 1, aktivitas 2, aktivitas 3                                    |
| Minggu   | aktivitas 1, aktivitas 2, aktivitas 3                                    |

### Catatan AI:  
_"Tuliskan catatan pendek suportif"_  

Catatan:
- Jangan gunakan bullet list (•).
- Jangan gunakan format paragraf.
- Gunakan hanya tabel Markdown.
- 1 kolom saja: Hari dan Rencana (dipisah koma, maksimal 3 per hari).
- Jangan gunakan HTML.
- Format harus bisa di-render langsung di Notion atau PDF.
    `.trim()

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7
      }),
      signal: controller.signal
    })

    clearTimeout(timeout)

    if (!res.ok) {
      const errText = await res.text()
      console.error('[❌ OpenAI Error]', errText)
      throw new Error('Gagal response dari OpenAI')
    }

    const ai = await res.json()
    const planner = ai.choices?.[0]?.message?.content || defaultPlannerTemplate

    const { error } = await supabase
      .from('weekly_planners')
      .insert([{ email, week_start: weekStr, planner }])

    if (error) {
      console.error('❌ Gagal menyimpan planner:', error)
      return NextResponse.json({ error: 'Gagal menyimpan planner.' }, { status: 500 })
    }

    console.log(`[✅ Planner Baru Tersimpan] ${email} – Minggu ${weekStr}`)

    return NextResponse.json({ planner, cached: false, model })
  } catch (err) {
    console.error('❌ Error fatal:', err)
    return NextResponse.json({
      planner: defaultPlannerTemplate,
      fallback: true,
      error: 'Terjadi kesalahan atau timeout. Template default digunakan.'
    }, { status: 500 })
  }
}
