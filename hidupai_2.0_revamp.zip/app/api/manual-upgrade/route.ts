// File: /app/api/manual-upgrade/route.ts

import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY!

export async function POST(req: Request) {
  const body = await req.json()
  const { order_id } = body

  if (!order_id) {
    return NextResponse.json({ error: '❌ Order ID wajib diisi' }, { status: 400 })
  }

  // 🔒 Validasi real-time ke Midtrans
  const midtransRes = await fetch(`https://api.midtrans.com/v2/${order_id}/status`, {
    headers: {
      Authorization: 'Basic ' + Buffer.from(MIDTRANS_SERVER_KEY + ':').toString('base64'),
      Accept: 'application/json'
    }
  })

  if (!midtransRes.ok) {
    return NextResponse.json({ error: '❌ Gagal fetch data Midtrans' }, { status: 500 })
  }

  const paymentData = await midtransRes.json()

  const {
    transaction_status,
    fraud_status,
    transaction_time,
    payment_type,
    customer_details
  } = paymentData

  let email = customer_details?.email

  const isSuccess =
    transaction_status === 'settlement' ||
    (transaction_status === 'capture' && fraud_status === 'accept')

  if (!isSuccess) {
    return NextResponse.json({
      error: `⚠️ Pembayaran belum berhasil (${transaction_status})`
    }, { status: 400 })
  }

  // 🛠 Ambil plan dan email dari database order (fallback)
  const { data: orderData, error: orderError } = await supabase
    .from('orders')
    .select('plan_type, email')
    .eq('order_id', order_id)
    .single()

  if (orderError || !orderData) {
    return NextResponse.json({ error: '❌ Order tidak ditemukan di DB' }, { status: 404 })
  }

  const planType = orderData.plan_type || 'premium'
  if (!email) email = orderData.email

  if (!email) {
    return NextResponse.json({ error: '❌ Email tidak ditemukan di data Midtrans atau DB' }, { status: 400 })
  }

  const now = new Date()
  const premiumUntil = new Date(now.getTime() + (
    planType === 'trial' ? 7 : planType === 'pro' ? 365 : 30
  ) * 24 * 60 * 60 * 1000)

  // ✅ Update tabel orders
  await supabase.from('orders').update({
    status: transaction_status,
    paid_at: now.toISOString(),
    transaction_time,
    payment_info: `Manual Verified (${payment_type})`
  }).eq('order_id', order_id)

  // ✅ Update tabel users
  const { error: userUpdateError } = await supabase.from('users').update({
    is_premium: true,
    plan_type: planType,
    premium_until: premiumUntil.toISOString(),
    just_upgraded: true
  }).eq('email', email)

  if (userUpdateError) {
    console.error('❌ Gagal update users:', userUpdateError)
    return NextResponse.json({ error: '❌ Gagal update user' }, { status: 500 })
  }

  return NextResponse.json({
    success: true,
    message: email,
    until: premiumUntil.toISOString()
  })
}
