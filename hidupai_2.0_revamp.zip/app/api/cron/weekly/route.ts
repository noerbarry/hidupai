// File: app/api/cron/weekly/route.ts

import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

// Optional: Resend atau integrasi lainnya
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export const config = {
  schedule: '0 7 * * 1' // setiap Senin jam 07:00 UTC / 14:00 WIB
}

export async function GET() {
  // 🔒 Optional safety switch (useful for maintenance)
  if (process.env.CRON_ENABLED !== 'true') {
    console.log('⏸️ Cron job is currently disabled (maintenance mode)')
    return NextResponse.json({ message: 'Cron is disabled' }, { status: 503 })
  }

  console.log('✅ Cron job berjalan... 🚀')

  // 🎯 Ambil semua user premium
  const { data: users, error } = await supabase
    .from('users')
    .select('email, name, goal')
    .eq('is_premium', true)

  if (error) {
    console.error('❌ Gagal mengambil data pengguna:', error)
    return NextResponse.json({ success: false, error }, { status: 500 })
  }

  // ✉️ Loop kirim email atau lakukan sesuatu
  for (const user of users) {
    console.log(`📨 Kirim ringkasan ke: ${user.email} (${user.name})`)
    // TODO: Kirim email via Resend, EmailJS, atau API lainnya
  }

  return NextResponse.json({ success: true, total_sent: users.length })
}
