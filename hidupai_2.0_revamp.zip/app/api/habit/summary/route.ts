import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: NextRequest) {
  const email = req.nextUrl.searchParams.get('email')

  if (!email) {
    return NextResponse.json({ success: false, error: 'Email wajib diisi' }, { status: 400 })
  }

  const { data, error } = await supabase
    .from('habit_logs')
    .select('date')
    .eq('email', email)
    // .eq('status', 'done') // Optional: aktifkan jika pakai kolom status

  if (error) {
    console.error('[Habit Summary Error]', error)
    return NextResponse.json({ success: false, error: 'Gagal ambil data habit' }, { status: 500 })
  }

  const uniqueDays = new Set<string>()
  const stats: { [day: string]: number } = {}

  data?.forEach(entry => {
    const date = new Date(entry.date)
    const isoDate = date.toISOString().split('T')[0] // yyyy-mm-dd
    uniqueDays.add(isoDate)

    const day = date.toLocaleDateString('id-ID', { weekday: 'short' })
    stats[day] = (stats[day] || 0) + 1
  })

  const formatted = Object.entries(stats).map(([day, total]) => ({
    day,
    total
  }))

  return NextResponse.json({
    success: true,
    stats: formatted,
    activeDaysCount: uniqueDays.size
  })
}
