// File: app/api/weekly-report/route.ts

import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { email, name, goal, last_question, last_response } = await req.json()

  // Kirim via Resend (misal kamu sudah punya API Key & domain)
  const RESEND_API_KEY = process.env.RESEND_API_KEY

  if (!RESEND_API_KEY) return NextResponse.json({ error: 'Resend key missing' }, { status: 500 })

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: 'HidupAI <noreply@hidupai.com>',
      to: [email],
      subject: `Insight Mingguan HidupAI untuk ${name}`,
      html: `<h2>Refleksi Mingguan</h2><p><strong>Tujuan Hidup:</strong> ${goal}</p><p><strong>Terakhir kamu bahas:</strong><br/>"${last_question}"<br/><em>${last_response}</em></p><hr/><p>Yuk terus berkembang! 🌱</p>`
    })
  })

  if (!res.ok) return NextResponse.json({ error: 'Gagal kirim email' }, { status: 500 })

  return NextResponse.json({ success: true })
}
