// File: app/api/email/welcome/route.ts

import { NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: Request) {
  const { name, email } = await req.json()

  try {
    const data = await resend.emails.send({
      from: 'HidupAI <welcome@on.resend.dev>',
      to: email,
      subject: `Selamat datang di HidupAI, ${name}! 👋`,
      html: `
        <div style="font-family: sans-serif;">
          <h2>Hai, ${name}! 👋</h2>
          <p>Selamat datang di <strong>HidupAI</strong> — teman sejiwa digitalmu ✨</p>
          <p>Kamu bisa langsung memulai perjalananmu menuju tujuan hidup di sini:</p>
          <a href="https://hidupai.vercel.app/chat" target="_blank" style="background:#2563eb;color:white;padding:10px 20px;border-radius:8px;text-decoration:none;display:inline-block;margin-top:10px;">Mulai Chat 🚀</a>
          <p style="margin-top:30px;font-size:12px;color:#999;">Powered by PABAR 🇮🇩</p>
        </div>
      `
    })

    return NextResponse.json({ success: true, data })
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 })
  }
}
