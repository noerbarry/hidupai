// File: app/api/memory/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';

// Penting: tandai route ini sebagai dynamic supaya boleh pakai cookies
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    // 1. Ambil cookies sekali lalu inject ke Supabase
    const cookieStore = cookies();
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore });

    const { searchParams } = new URL(req.url);
    const email = searchParams.get('email');

    if (!email) {
      return NextResponse.json(
        { error: '❌ Email tidak disediakan.' },
        { status: 400 }
      );
    }

    // 2. Ambil user berdasarkan email
    const {
      data: user,
      error: userError,
    } = await supabase
      .from('users')
      .select('id, preferred_mode, weekly_goal')
      .eq('email', email)
      .single();

    if (userError || !user) {
      console.error('[memory] user lookup error:', userError);
      return NextResponse.json(
        { error: '❌ User tidak ditemukan.' },
        { status: 404 }
      );
    }

    // 3. Ambil memori berdasarkan user_id
    const {
      data: memories,
      error: memoryError,
    } = await supabase
      .from('long_term_memories')
      .select('id, content')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true });

    if (memoryError) {
      console.error('[memory] query error:', memoryError);
      return NextResponse.json(
        {
          error: '❌ Gagal mengambil memori.',
          detail: memoryError.message,
        },
        { status: 500 }
      );
    }

    // 4. Response sukses
    return NextResponse.json(
      {
        memory: memories || [],
        mode: user.preferred_mode || '',
        goal: user.weekly_goal || '',
      },
      { status: 200 }
    );
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : 'Unknown error';

    console.error('[memory] unexpected error:', err);
    return NextResponse.json(
      {
        error: '❌ Terjadi kesalahan internal.',
        detail: message,
      },
      { status: 500 }
    );
  }
}
