// File: /app/api/memory/edit/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, index, newText } = await req.json()

  // Validasi input
  if (!email || typeof index !== 'number' || !newText?.trim()) {
    return NextResponse.json({ error: 'Data tidak lengkap atau format salah' }, { status: 400 })
  }

  // Ambil user ID
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
  }

  // Ambil semua memori user untuk mengetahui ID memori berdasarkan index
  const { data: memories, error: fetchError } = await supabase
    .from('long_term_memories')
    .select('id')
    .eq('user_id', user.id)
    .order('created_at', { ascending: true })

  if (fetchError) {
    return NextResponse.json({ error: fetchError.message || 'Gagal mengambil memori' }, { status: 500 })
  }

  // Validasi index
  if (!memories || index < 0 || index >= memories.length) {
    return NextResponse.json({ error: 'Index memori tidak valid' }, { status: 400 })
  }

  const memoryId = memories[index].id

  // Update konten memori
  const { error: updateError } = await supabase
    .from('long_term_memories')
    .update({
      content: newText.trim(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', memoryId)

  if (updateError) {
    return NextResponse.json({ error: updateError.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
