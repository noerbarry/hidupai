// File: app/api/agentic-preferences/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';

// Penting: route ini pakai cookies/Supabase → paksa dynamic
export const dynamic = 'force-dynamic';

type AgenticPreferencesRow = {
  email: string;
  mode?: string | null;
  goal?: string | null;
};

type AgenticPreferencesPayload = {
  email?: string;
  mode?: string;
  goal?: string;
};

function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === 'string') return error;
  try {
    return JSON.stringify(error);
  } catch {
    return 'Unknown error';
  }
}

export async function GET(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { searchParams } = new URL(req.url);
    const email = searchParams.get('email');

    if (!email) {
      return NextResponse.json(
        { error: 'Email diperlukan' },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('agentic_preferences')
      .select('mode, goal')
      .eq('email', email)
      .maybeSingle<AgenticPreferencesRow>();

    if (error) {
      console.error('[agentic-preferences][GET] error:', error);
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      );
    }

    return NextResponse.json({
      mode: data?.mode ?? '',
      goal: data?.goal ?? '',
    });
  } catch (err: unknown) {
    console.error('[agentic-preferences][GET] unexpected:', err);
    return NextResponse.json(
      {
        error: 'Terjadi kesalahan internal.',
        detail: getErrorMessage(err),
      },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = (await req.json().catch(() => null)) as
      | AgenticPreferencesPayload
      | null;

    const email = body?.email;
    const mode = body?.mode;
    const goal = body?.goal;

    if (!email) {
      return NextResponse.json(
        { error: 'Email diperlukan' },
        { status: 400 }
      );
    }

    // Cek apakah sudah ada record sebelumnya
    const { data: existing, error: existingError } = await supabase
      .from('agentic_preferences')
      .select('email')
      .eq('email', email)
      .maybeSingle<Pick<AgenticPreferencesRow, 'email'>>();

    if (existingError) {
      console.error(
        '[agentic-preferences][POST] existingError:',
        existingError
      );
      return NextResponse.json(
        { error: existingError.message },
        { status: 500 }
      );
    }

    const updates: Partial<AgenticPreferencesRow> = {};
    if (typeof mode === 'string') updates.mode = mode;
    if (typeof goal === 'string') updates.goal = goal;

    let upsertError: { message: string } | null = null;

    if (existing) {
      const { error: updateError } = await supabase
        .from('agentic_preferences')
        .update(updates)
        .eq('email', email);

      upsertError = updateError;
    } else {
      const { error: insertError } = await supabase
        .from('agentic_preferences')
        .insert({ email, ...updates });

      upsertError = insertError;
    }

    if (upsertError) {
      console.error(
        '[agentic-preferences][POST] upsertError:',
        upsertError
      );
      return NextResponse.json(
        { error: upsertError.message },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error('[agentic-preferences][POST] unexpected:', err);
    return NextResponse.json(
      {
        error: 'Terjadi kesalahan internal.',
        detail: getErrorMessage(err),
      },
      { status: 500 }
    );
  }
}
