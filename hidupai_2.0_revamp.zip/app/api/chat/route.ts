// File: app/api/chat/route.ts

import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { jwtDecode } from 'jwt-decode';
import { GoogleGenerativeAI } from '@google/generative-ai';

/* =========================================================
 * SUPABASE CLIENT
 * =======================================================*/

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface JwtPayload {
  email: string;
}

/* =========================================================
 * AI CONFIG — OPENAI + GEMINI
 * =======================================================*/

const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';
const OPENAI_MAIN_MODEL =
  process.env.OPENAI_MAIN_MODEL || 'gpt-4o-mini';
const OPENAI_SUMMARIZER_MODEL =
  process.env.OPENAI_SUMMARIZER_MODEL || 'gpt-4o-mini';

const GEMINI_MODEL =
  process.env.GEMINI_MODEL || 'gemini-1.5-flash-latest';

// Mode provider: openai | gemini | hybrid
const AI_PROVIDER =
  (process.env.AI_PROVIDER as 'openai' | 'gemini' | 'hybrid') || 'hybrid';

const genAI = process.env.GOOGLE_API_KEY
  ? new GoogleGenerativeAI(process.env.GOOGLE_API_KEY)
  : null;

/* =========================================================
 *  HUMAN MIND STACK PROMPT ENGINE
 * =======================================================*/

const buildBasePrompt = (
  name: string,
  goal: string,
  memory: string
): string => {
  return `
Kamu adalah HidupAI™, sahabat hidup ${name}.

TENTANG HIDUPAI:
- Kamu human-centered: fokusmu memahami manusia, bukan sekadar memberi jawaban.
- Kamu empatik, reflektif, tenang, dan tidak menghakimi.
- Kamu tidak menyebut diri sebagai AI, chatbot, atau model. Cukup "HidupAI".

KONTEKS HIDUP ${name}:
- Tujuan mingguan saat ini: "${goal || 'Belum ada tujuan mingguan yang jelas.'}"
- Catatan hidup & pola sejauh ini:
${memory || '- Belum ada memori panjang yang terekam.'}

PRINSIP CARA KERJA (Human Mind Stack):

1) EMOSI  
   - Baca emosi di balik kata-kata ${name}.
   - Validasi perasaan sebelum memberi solusi.

2) PIKIRAN & BIAS  
   - Bantu ${name} melihat pola pikir yang tidak sehat.
   - Luruskan generalisasi berlebihan dengan lembut.

3) MOTIVASI  
   - Dukung autonomy, competence, relatedness.

4) MAKNA  
   - Hubungkan keputusan dengan nilai hidup ${name}.

5) RUANG AMAN  
   - Bahasa lembut, tidak menghakimi.
   - Bila topik berat (trauma, self-harm), anjurkan bicara dengan manusia terpercaya.

GAYA BAHASA:
- Tenang, dewasa, hangat, tidak robotik.
- Boleh pakai emoji ✨🌱🤍 secukupnya.

MISI:
- Bantu ${name} memahami dirinya, bukan sekadar menjawab pertanyaan.`.trim();
};

const buildModeAddon = (name: string, mode: string): string => {
  switch (mode) {
    case 'pagi':
      return `
PAGI HARI ☀️
- Sambut ${name} dengan ringan & positif.
- Ajak set niat harian sederhana.
- Hindari to-do berlebihan.
`.trim();
    case 'mentok':
      return `
MENTOK / BUNTU 🌱
- Tugas utama: turunkan beban pikiran.
- Ajukan pertanyaan reflektif lembut.
- Beri langkah kecil yg realistis.
`.trim();
    case 'sedih':
      return `
SEDIH / LETIH 🤍
- Peluk lewat kata.
- Validasi emosi.
- Hindari toxic positivity.
`.trim();
    case 'sukses':
      return `
SUKSES 🎉
- Rayakan pencapaian ${name}.
- Ajak refleksi proses & usaha.
- Perkuat self-worth.
`.trim();
    default:
      return `
MODE UMUM
- Respon berdasarkan emosi dari pesan user.
`.trim();
  }
};

const getPrompt = (
  name: string,
  mode: string,
  goal: string,
  memory: string
): ChatMessage => ({
  role: 'system',
  content: `${buildBasePrompt(name, goal, memory)}\n\n${buildModeAddon(
    name,
    mode
  )}`,
});

/* =========================================================
 *  AI CALLERS — OPENAI / GEMINI / HYBRID
 * =======================================================*/

async function callOpenAI(
  systemPrompt: ChatMessage,
  messages: ChatMessage[]
): Promise<string> {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY missing');
  }

  const res = await fetch(OPENAI_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: OPENAI_MAIN_MODEL,
      temperature: 0.8,
      messages: [systemPrompt, ...messages],
    }),
  });

  if (!res.ok) {
    throw new Error(`OpenAI error ${res.status}`);
  }

  const json = await res.json();
  const msg: string | undefined =
    json.choices?.[0]?.message?.content?.trim();
  if (!msg) throw new Error('OpenAI returned empty');

  return msg;
}

async function callGemini(
  systemPrompt: ChatMessage,
  messages: ChatMessage[]
): Promise<string> {
  if (!genAI) throw new Error('GOOGLE_API_KEY missing');

  const model = genAI.getGenerativeModel({ model: GEMINI_MODEL });

  const combined = [systemPrompt, ...messages]
    .map((m) => `${m.role.toUpperCase()}:\n${m.content}`)
    .join('\n\n');

  const res = await model.generateContent({
    contents: [
      {
        role: 'user',
        parts: [{ text: combined }],
      },
    ],
  });

  const text = res.response.text().trim();
  if (!text) throw new Error('Gemini returned empty');

  return text;
}

async function callMainModel(
  systemPrompt: ChatMessage,
  messages: ChatMessage[]
): Promise<string> {
  if (AI_PROVIDER === 'gemini') return callGemini(systemPrompt, messages);
  if (AI_PROVIDER === 'openai') return callOpenAI(systemPrompt, messages);

  // HYBRID MODE
  try {
    return await callOpenAI(systemPrompt, messages);
  } catch {
    console.warn('[HidupAI] OpenAI gagal, fallback ke Gemini');
    return callGemini(systemPrompt, messages);
  }
}

/* =========================================================
 *  MEMORY ENGINE — INSIGHT USER
 * =======================================================*/

async function extractInsight(
  name: string,
  prev: string,
  userMsg: string,
  aiMsg: string
): Promise<string | null> {
  if (!process.env.OPENAI_API_KEY) return null;
  if (!userMsg || aiMsg.length < 40) return null;

  try {
    const res = await fetch(OPENAI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: OPENAI_SUMMARIZER_MODEL,
        temperature: 0.2,
        messages: [
          {
            role: 'system',
            content: `
Tuliskan SATU bullet insight tentang ${name}.
Fokus: nilai hidup, kekhawatiran, harapan, atau pola pikir.
Singkat, netral, tanpa emoji, tanpa sapaan.`.trim(),
          },
          {
            role: 'user',
            content: `
Memori sebelumnya:
${prev}

Pesan user:
${userMsg}

Jawaban HidupAI:
${aiMsg}
`.trim(),
          },
        ],
      }),
    });

    if (!res.ok) return null;

    const json = await res.json();
    const insight =
      json.choices?.[0]?.message?.content
        ?.trim()
        ?.replace(/^[-•]\s*/, '') || '';

    return insight ? `- ${insight}` : null;
  } catch {
    return null;
  }
}

/* =========================================================
 *  ROUTE HANDLER
 * =======================================================*/

type ChatRequestBody = {
  messages: ChatMessage[];
  name: string;
  email: string;
  mode?: string;
};

export async function POST(req: Request) {
  const body = (await req.json()) as ChatRequestBody;
  const { messages, name, email, mode: rawMode } = body;

  // Token check
  const token = req.headers.get('Authorization')?.split(' ')[1];
  if (!token) {
    return NextResponse.json(
      { message: 'Token tidak ditemukan' },
      { status: 401 }
    );
  }

  let decodedEmail = '';
  try {
    const decoded = jwtDecode<JwtPayload>(token);
    decodedEmail = decoded.email;
  } catch {
    return NextResponse.json(
      { message: 'Token tidak valid' },
      { status: 401 }
    );
  }

  if (decodedEmail !== email) {
    return NextResponse.json(
      { message: 'Akses tidak sah 🔒' },
      { status: 401 }
    );
  }

  // Ambil user
  const { data: user, error } = await supabase
    .from('users')
    .select(
      'is_premium, usage_today, last_used, long_term_memory, preferred_mode, weekly_goal'
    )
    .eq('email', email)
    .single();

  if (error || !user) {
    return NextResponse.json(
      { message: 'Akun tidak ditemukan' },
      { status: 404 }
    );
  }

  /* ===== KUOTA ===== */

  const today = new Date().toISOString().split('T')[0];

  if (user.last_used !== today) {
    await supabase
      .from('users')
      .update({ usage_today: 1, last_used: today })
      .eq('email', email);
  } else if (!user.is_premium && user.usage_today >= 5) {
    return NextResponse.json(
      {
        message:
          'Batas penggunaan gratis sudah 5x hari ini 😅\nCoba lagi besok ya! 🚀',
      },
      { status: 200 }
    );
  } else if (!user.is_premium) {
    await supabase
      .from('users')
      .update({ usage_today: (user.usage_today || 0) + 1 })
      .eq('email', email);
  }

  /* ===== MAIN CHAT ===== */

  const mode = rawMode || user.preferred_mode || '';
  const goal = user.weekly_goal || '';
  const memory: string = user.long_term_memory || '';

  const systemPrompt = getPrompt(name, mode, goal, memory);

  let aiMessage = '';
  try {
    aiMessage = await callMainModel(systemPrompt, messages);
  } catch {
    return NextResponse.json(
      {
        message:
          'Mesin berpikir HidupAI sedang gangguan 😵 Coba sebentar lagi ya.',
      },
      { status: 500 }
    );
  }

  aiMessage = aiMessage.trim();

  /* ===== UPDATE MEMORI: SIMPAN INSIGHT ===== */

  const lastUserMessage =
    messages[messages.length - 1]?.content || '';

  try {
    const insight = await extractInsight(
      name,
      memory,
      lastUserMessage,
      aiMessage
    );
    if (insight) {
      const updated = memory ? `${memory}\n${insight}` : insight;
      await supabase
        .from('users')
        .update({ long_term_memory: updated })
        .eq('email', email);
    }
  } catch {
    // kegagalan memori tidak boleh mengganggu jawaban utama
  }

  /* ===== UPDATE LOG ===== */

  await supabase
    .from('users')
    .update({
      last_question: lastUserMessage,
      last_response: aiMessage,
      last_interaction: new Date().toISOString(),
    })
    .eq('email', email);

  return NextResponse.json({ message: aiMessage });
}
