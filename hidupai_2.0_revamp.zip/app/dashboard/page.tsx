'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import Image from 'next/image';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { PDFDownloadLink } from '@react-pdf/renderer';
import SummaryPDF from '@/components/pdf/SummaryPDF';
import PlannerPDF from '@/components/pdf/PlannerPDF';
import LifeRankCard from '@/components/LifeRankCard';
import MemoryPanel from '@/components/agentic/MemoryPanel';
import AgenticSettings from '@/components/AgenticSettings';

interface HabitStat {
  day: string;
  total: number;
}

/* =========================================================
 *  WEEKLY COACHING (AGENTIC)
 * =======================================================*/
function WeeklyCoachingPanel({ email }: { email: string }) {
  const [coaching, setCoaching] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchCoaching = useCallback(async () => {
    if (!email) return;
    setLoading(true);
    setCoaching('');

    try {
      const res = await fetch('/api/agentic-chat/weekly-coaching', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (!res.ok || !res.body) throw new Error('Gagal stream');

      const reader = res.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        setCoaching((prev) => prev + chunk);
      }
    } catch (err) {
      console.error('Gagal mengambil refleksi mingguan:', err);
      setCoaching('⚠️ Error mengambil refleksi mingguan');
    } finally {
      setLoading(false);
    }
  }, [email]);

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-semibold text-indigo-600">
            🧭 Refleksi Mingguan
          </h2>
          <Button size="sm" onClick={fetchCoaching} disabled={loading}>
            {loading ? '⏳ Memuat...' : coaching ? '🔁 Ulangi' : '✨ Mulai'}
          </Button>
        </div>

        {loading ? (
          <p className="text-sm italic text-gray-500">
            🤖 HidupAI sedang menyiapkan refleksi mingguan kamu...
          </p>
        ) : coaching ? (
          <p className="text-sm text-gray-800 whitespace-pre-line leading-relaxed">
            {coaching}
          </p>
        ) : (
          <p className="text-sm text-gray-500 italic">
            Klik tombol mulai untuk refleksi mingguan.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/* =========================================================
 *  DASHBOARD PAGE
 * =======================================================*/
export default function Dashboard() {
  const router = useRouter();
  const supabase = createClientComponentClient();

  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [goal, setGoal] = useState('');
  const [email, setEmail] = useState('');
  const [isPremium, setIsPremium] = useState(false);
  const [badge, setBadge] = useState('Newbie');
  const [usageToday, setUsageToday] = useState(0);
  const [lastQuestion, setLastQuestion] = useState('');
  const [lastResponse, setLastResponse] = useState('');
  const [habitStats, setHabitStats] = useState<HabitStat[]>([]);
  const [habitInsight, setHabitInsight] = useState('');
  const [trendEmoji, setTrendEmoji] = useState('');
  const [plannerText, setPlannerText] = useState('');
  const [plannerLoading, setPlannerLoading] = useState(false);
  const [plannerCached, setPlannerCached] = useState(false);
  const [preferredMode, setPreferredMode] = useState('');
  const [weeklyGoal, setWeeklyGoal] = useState('');

  /* -------------------------
   *  LOAD SEMUA DATA
   * ------------------------*/
  useEffect(() => {
    const fetchAll = async () => {
      const {
        data: { session },
        error,
      } = await supabase.auth.getSession();
      const token = session?.access_token;

      if (!session?.user?.email || error || !token) {
        router.push('/login');
        return;
      }

      const email = session.user.email;
      setEmail(email);

      // Agentic preferences (mode & goal)
      fetch('/api/agentic-preferences?email=' + email)
        .then(async (res) => {
          if (!res.ok) {
            const text = await res.text();
            throw new Error(`Gagal fetch preferences: ${text}`);
          }
          return res.json();
        })
        .then((data) => {
          setPreferredMode(data.mode || '');
          setWeeklyGoal(data.goal || '');
        })
        .catch((err) => console.error('Agentic preferences fetch error:', err));

      // Profil user
      const res = await fetch('/api/check-user', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        router.push('/register');
        return;
      }

      const data = await res.json();
      setName(data.name);
      setGoal(data.goal);
      setIsPremium(data.is_premium);
      setBadge(data.badge || 'Newbie');
      setLastQuestion(data.last_question || '');
      setLastResponse(data.last_response || '');

      // Usage hari ini
      fetch('/api/usage', {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((resp) => resp.json())
        .then((resp) => setUsageToday(resp.usage_today || 0))
        .catch((err) => console.error('Usage fetch error:', err));

      // Habit stats
      fetch('/api/habit/stats?email=' + email, {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((resp) => resp.json())
        .then((resp) => {
          setHabitStats(resp.stats || []);
          setHabitInsight(resp.insight || '');
          if (resp.insight?.includes('meningkat')) setTrendEmoji('📈');
          else if (resp.insight?.includes('menurun')) setTrendEmoji('📉');
          else setTrendEmoji('➖');
        })
        .catch((err) => console.error('Habit stats error:', err));

      setLoading(false);
    };

    fetchAll();
  }, [router, supabase]);

  /* -------------------------
   *  LOGOUT
   * ------------------------*/
  const handleLogout = async () => {
    await supabase.auth.signOut();
    document.cookie = 'sb-access-token=; Max-Age=0; path=/;';
    document.cookie = 'sb-refresh-token=; Max-Age=0; path=/;';
    router.push('/login');
  };

  /* -------------------------
   *  WEEKLY PLANNER (AI)
   * ------------------------*/
  const generatePlanner = async () => {
    if (!email) return;
    setPlannerLoading(true);
    const res = await fetch('/api/ai/weekly-planner', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    setPlannerText(data.planner || 'Gagal memuat planner.');
    setPlannerCached(data.cached || false);
    setPlannerLoading(false);
  };

  const pushToNotion = async () => {
    if (!plannerText || !email) return;
    const res = await fetch('/api/notion/push-planner', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ planner: plannerText }),
    });
    const data = await res.json();
    alert(
      data.success
        ? '✅ Planner berhasil dikirim ke Notion!'
        : '❌ Gagal kirim ke Notion.'
    );
  };

  /* -------------------------
   *  LOADING STATE
   * ------------------------*/
  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-[#F5F7FA] text-sm text-gray-500">
        ⏳ Memuat dashboard kamu...
      </main>
    );
  }

  /* -------------------------
   *  MAIN UI
   * ------------------------*/
  return (
    <main className="min-h-screen bg-[#F5F7FA]">
      <div className="max-w-4xl mx-auto px-4 pt-[96px] sm:pt-[112px] md:pt-[128px] pb-10 space-y-6">
        {/* =========================================
         *  HEADER SUMMARY
         * =======================================*/}
        <Card className="border border-gray-200 shadow-sm bg-white/90 backdrop-blur">
          <CardContent className="p-4 sm:p-5 flex flex-col sm:flex-row gap-4 sm:gap-6 items-start sm:items-center">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-11 h-11 rounded-full bg-[#1A73E8]/10 flex items-center justify-center mt-0.5">
                <span className="text-lg">👤</span>
              </div>
              <div className="space-y-1">
                <h1 className="text-lg sm:text-xl font-semibold text-[#0F172A]">
                  Halo, {name} 👋
                </h1>
                <p className="text-xs sm:text-sm text-gray-600">
                  Tujuanmu saat ini:{' '}
                  <span className="font-medium text-[#1A73E8] italic">
                    {goal || 'belum diatur'}
                  </span>
                </p>
                <div className="flex flex-wrap gap-2 mt-2 text-[11px] sm:text-xs">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100">
                    {isPremium ? 'Premium aktif 🚀' : 'Versi gratis 🌱'}
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                    Badge: {badge}
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-slate-50 text-slate-600 border border-slate-200">
                    {usageToday}/5 chat gratis hari ini
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-end gap-2">
              <Image
                src="/images/logo-hidupai.png"
                alt="Logo HidupAI"
                width={72}
                height={72}
                className="rounded-xl"
              />
              <div className="flex flex-wrap justify-end gap-2 text-[11px] sm:text-xs">
                <Button
                  variant="ghost"
                  className="h-auto p-0 text-blue-600 hover:underline"
                  onClick={() => router.push('/profile')}
                >
                  🛠️ Edit Profil
                </Button>
                <Button
                  variant="ghost"
                  className="h-auto p-0 text-blue-600 hover:underline"
                  onClick={() => router.push('/history')}
                >
                  💳 Riwayat Pembayaran
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* =========================================
         *  LIFE RANK + AGENTIC BLOCKS
         * =======================================*/}
        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] gap-4">
          <div className="space-y-4">
            {/* Life Rank */}
            <LifeRankCard email={email} isPremium={isPremium} />

            {/* Memory Panel */}
            <MemoryPanel email={email} />

            {/* Agentic Settings */}
            <AgenticSettings email={email} mode={preferredMode} goal={weeklyGoal} />
          </div>

          {/* Side column: mingguan & arena */}
          <div className="space-y-4">
            {isPremium && <WeeklyCoachingPanel email={email} />}

            {isPremium && (
              <Card>
                <CardContent className="p-4 space-y-3">
                  <h2 className="text-sm font-semibold text-indigo-600">
                    🔮 Life Arena Pro
                  </h2>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    Simulasikan keputusan hidup besar kamu bersama AI yang
                    memahami tujuan dan emosimu.
                  </p>
                  <Button
                    onClick={() => router.push('/life-arena')}
                    className="w-full"
                  >
                    Jelajahi Life Arena
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* =========================================
         *  INFO CARDS (AKUN & USAGE)
         * =======================================*/}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                Email
              </p>
              <p className="mt-1 font-medium text-sm break-all">{email}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                Status
              </p>
              <p
                className={`mt-1 font-medium text-sm ${
                  isPremium ? 'text-green-600' : 'text-red-600'
                }`}
              >
                {isPremium ? 'Premium 🚀' : 'Gratis'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                Badge
              </p>
              <p className="mt-1 font-medium text-sm text-indigo-600">
                {badge}
              </p>
            </CardContent>
          </Card>

          <Card className="md:col-span-1">
            <CardContent className="p-4 space-y-3">
              <p className="text-[11px] text-gray-500 uppercase tracking-wide">
                Penggunaan Chat Hari Ini
              </p>
              <Progress value={(usageToday / 5) * 100} />
              <p className="text-sm text-gray-600">
                {usageToday}/5 chat gratis
              </p>
            </CardContent>
          </Card>
        </div>

        {/* =========================================
         *  LAST CHAT HISTORY
         * =======================================*/}
        {lastQuestion && lastResponse && (
          <Card>
            <CardContent className="p-4 space-y-2">
              <p className="text-sm font-semibold">
                ✅ Kilas Balik Percakapan Terakhir
              </p>
              <p className="text-xs text-gray-500 italic">
                Terakhir kamu tanya:
              </p>
              <p className="text-sm">“{lastQuestion}”</p>
              <p className="text-xs text-gray-500 italic">
                Jawaban HidupAI:
              </p>
              <p className="text-sm leading-relaxed">{lastResponse}</p>
            </CardContent>
          </Card>
        )}

        {/* =========================================
         *  PREMIUM TOOLS
         * =======================================*/}
        {isPremium && (
          <>
            {/* Habit chart */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <p className="text-sm font-semibold">
                  📊 Progress Kebiasaan Mingguan{' '}
                  {trendEmoji && <span>{trendEmoji}</span>}
                </p>
                {habitStats.length === 0 ? (
                  <p className="text-sm text-gray-500 italic">
                    Belum ada data kebiasaan.
                  </p>
                ) : (
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={habitStats}>
                      <XAxis dataKey="day" />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Bar
                        dataKey="total"
                        fill="#3b82f6"
                        radius={[6, 6, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Habit insight */}
            <Card>
              <CardContent className="p-4 space-y-2">
                <p className="text-sm font-semibold">🧠 Insight Mingguan</p>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {habitInsight}
                </p>
              </CardContent>
            </Card>

            {/* PDF summary */}
            <Card>
              <CardContent className="p-4 space-y-2">
                <p className="text-sm font-semibold">
                  📥 Export Ringkasan Mingguan
                </p>
                <PDFDownloadLink
                  document={
                    <SummaryPDF
                      name={name}
                      goal={goal}
                      stats={habitStats}
                    />
                  }
                  fileName="hidupai-ringkasan.pdf"
                >
                  {({ loading }) => (
                    <Button>
                      {loading
                        ? 'Menyiapkan PDF...'
                        : '📄 Unduh PDF Ringkasan'}
                    </Button>
                  )}
                </PDFDownloadLink>
              </CardContent>
            </Card>

            {/* Planner */}
            <Card>
              <CardContent className="p-4 space-y-3">
                <div className="flex justify-between items-center gap-2">
                  <p className="text-sm font-semibold">
                    🎯 AI Weekly Habit Planner
                  </p>
                  <Button
                    size="sm"
                    onClick={generatePlanner}
                    disabled={plannerLoading}
                  >
                    {plannerLoading ? '⏳ Memuat...' : 'Generate'}
                  </Button>
                </div>

                {plannerText && (
                  <>
                    <pre className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-zinc-800 border border-gray-200 bg-gray-50 p-4 rounded-md">
                      {plannerText}
                    </pre>

                    {plannerCached && (
                      <p className="text-xs text-right italic text-gray-500 mt-1">
                        📌 Diambil dari cache minggu ini
                      </p>
                    )}

                    <div className="flex flex-wrap justify-end gap-3 mt-3">
                      <PDFDownloadLink
                        document={
                          <PlannerPDF name={name} planner={plannerText} />
                        }
                        fileName="hidupai-weekly-planner.pdf"
                      >
                        {({ loading }) => (
                          <Button variant="outline" size="sm">
                            {loading ? '⏳ PDF...' : '📄 Download PDF'}
                          </Button>
                        )}
                      </PDFDownloadLink>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={pushToNotion}
                      >
                        📤 Kirim ke Notion
                      </Button>
                    </div>

                    <div className="text-right mt-2">
                      <a
                        href="https://www.notion.so/Weekly-Planner-AI-1e76cb5980ac800090eed29bdfeb53b1"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-blue-600 underline"
                      >
                        🔗 Lihat Planner di Notion
                      </a>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </>
        )}

        {/* =========================================
         *  ACTIONS
         * =======================================*/}
        <div className="flex flex-col md:flex-row gap-3 justify-center">
          <Button onClick={() => router.push('/onboarding')}>
            💬 Lanjut Ngobrol Bareng HidupAI
          </Button>

          {!isPremium && (
            <Button
              variant="outline"
              onClick={() => router.push('/pricing')}
            >
              🚀 Upgrade ke Premium
            </Button>
          )}

          <Button
            variant="destructive"
            className="text-sm"
            onClick={handleLogout}
          >
            🔓 Keluar dari Akun
          </Button>
        </div>
      </div>
    </main>
  );
}
