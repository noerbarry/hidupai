'use client'

import Link from 'next/link'

export default function PrivacyPolicyPage() {
  return (
    <main className="max-w-3xl mx-auto px-6 py-12 text-gray-800 space-y-6">
      <h1 className="text-3xl font-bold">Kebijakan Privasi</h1>

      <p>
        HidupAI menghargai privasi Anda. Halaman ini menjelaskan bagaimana kami mengelola data Anda selama penggunaan aplikasi.
      </p>

      <h2 className="text-xl font-semibold mt-6">Data yang Kami Kumpulkan</h2>
      <ul className="list-disc ml-6 space-y-2">
        <li><strong>Nama</strong>: untuk personalisasi pengalaman Anda.</li>
        <li><strong>Email</strong>: digunakan untuk keperluan autentikasi dan transaksi.</li>
        <li><strong>Tujuan hidup</strong>: sebagai bagian dari konteks percakapan yang Anda berikan.</li>
        <li><strong>Status Premium</strong>: untuk menentukan akses fitur lanjutan.</li>
        <li><strong>Pertanyaan dan jawaban terakhir</strong>: disimpan secara terbatas untuk meningkatkan pengalaman Anda saat kembali menggunakan aplikasi.</li>
      </ul>

      <h2 className="text-xl font-semibold mt-6">Apa yang Tidak Kami Simpan</h2>
      <p>
        HidupAI tidak menyimpan seluruh riwayat percakapan Anda secara permanen. Kami hanya menyimpan ringkasan percakapan terakhir secara terbatas.
      </p>

      <h2 className="text-xl font-semibold mt-6">Keamanan</h2>
      <p>
        Data Anda dikelola dengan aman menggunakan layanan cloud dan pembayaran yang telah memenuhi standar keamanan industri. Kami menjaga kerahasiaan data dengan praktik terbaik.
      </p>

      <h2 className="text-xl font-semibold mt-6">Perubahan Kebijakan</h2>
      <p>
        Kebijakan privasi ini dapat diperbarui sewaktu-waktu. Perubahan besar akan kami umumkan melalui platform resmi.
      </p>

      <h2 className="text-xl font-semibold mt-6">Kontak</h2>
      <p>
      Jika Anda memiliki pertanyaan mengenai privasi atau data Anda, silakan <a
         href="mailto:hidupaiapp@gmail.com"
         className="text-blue-600 underline"
      >
        hubungi kami
        </a>
      </p>

      <p className="mt-8 text-center text-sm">
        <Link href="/">
          <span className="text-blue-600 underline hover:text-blue-800">← Kembali ke Beranda</span>
        </Link>
      </p>
    </main>
  )
}
