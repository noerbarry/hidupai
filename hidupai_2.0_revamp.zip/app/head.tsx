// File: app/head.tsx
export default function Head() {
    return (
      <>
        <title>HidupAI™ - Mentor Digitalmu Setiap Hari</title>
        <meta name="description" content="Asisten AI personal yang bantu kamu bertumbuh, mengingat tujuan, dan mendampingi perjalanan hidupmu. Powered by PABAR 🇮🇩" />
      </>
    )
  }
  