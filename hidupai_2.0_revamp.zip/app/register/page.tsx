'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import Image from 'next/image'

export default function RegisterPage() {
  const supabase = createClientComponentClient()
  const router = useRouter()

  const [email, setEmail] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [goal, setGoal] = useState('')
  const [loading, setLoading] = useState(false)
  const [formError, setFormError] = useState('')

  // ✅ Retry logic agar session terambil sebelum redirect ke /login
  useEffect(() => {
    let attempt = 0
    const maxAttempts = 5

    const fetchUser = async () => {
      attempt++
      const { data: { user } } = await supabase.auth.getUser()

      if (user?.email) {
        setEmail(user.email)
        sessionStorage.removeItem('redirected')
      } else if (attempt < maxAttempts) {
        setTimeout(fetchUser, 500) // Retry setelah 0.5 detik
      } else {
        const redirected = sessionStorage.getItem('redirected')
        if (!redirected) {
          sessionStorage.setItem('redirected', 'yes')
          router.replace('/login')
        }
      }
    }

    fetchUser()
  }, [supabase, router])

  const handleSubmit = async () => {
    if (!name.trim() || !goal.trim()) {
      setFormError('Nama dan tujuan hidup wajib diisi.')
      return
    }

    setLoading(true)

    await supabase.auth.updateUser({ data: { name, goal } })

    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, goal, email }),
    })

    if (res.ok) {
      window.location.href = '/dashboard'
    } else {
      setFormError('❌ Gagal menyimpan data. Coba lagi nanti.')
    }

    setLoading(false)
  }

  if (!email) {
    return (
      <main className="h-screen flex items-center justify-center">
        <p className="text-sm text-gray-500">⏳ Menyiapkan halaman registrasi...</p>
      </main>
    )
  }

  return (
    <main className="max-w-md mx-auto p-6 space-y-4">
      <div className="flex justify-center">
        <Image src="/images/logo-hidupai.png" alt="Logo HidupAI" width={64} height={64} />
      </div>

      <h1 className="text-xl font-bold text-center mb-4">Selamat Datang di HidupAI 👋</h1>

      <Card>
        <CardContent className="space-y-4 p-4">
          <Input placeholder="Nama kamu" value={name} onChange={e => setName(e.target.value)} />
          <Input placeholder="Tujuan hidup kamu" value={goal} onChange={e => setGoal(e.target.value)} />
          {formError && <p className="text-xs text-red-500">{formError}</p>}
          <Button className="w-full" onClick={handleSubmit} disabled={loading}>
            {loading ? 'Menyimpan...' : 'Mulai Sekarang 🚀'}
          </Button>
        </CardContent>
      </Card>

      <p className="text-center text-xs text-gray-500 mt-4">
      ✨ Data ini bikin pengalaman kamu makin personal & bermakna bersama HidupAI 💙
      </p>
    </main>
  )
}
