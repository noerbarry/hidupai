'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'

type ContactResponse = {
  success?: boolean
  message?: string
}

export default function ContactPage() {
  const [captchaUrl, setCaptchaUrl] = useState('')
  const [captchaInput, setCaptchaInput] = useState('')
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const reloadCaptcha = () => {
    setCaptchaUrl(`/api/custom-captcha?reload=${Date.now()}`)
  }

  useEffect(() => {
    reloadCaptcha()
  }, [])

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSuccess(false)
    setError('')
    setIsSubmitting(true)

    const form = e.currentTarget
    const formData = new FormData(form)
    const name = formData.get('name')
    const email = formData.get('email')
    const message = formData.get('message')

    let data: ContactResponse = {}

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          message,
          captcha_input: captchaInput,
        }),
      })

      try {
        data = (await res.json()) as ContactResponse
      } catch {
        data = {}
      }

      if (res.ok && data.success) {
        setSuccess(true)
        setError('')
        form.reset()
        setCaptchaInput('')
      } else {
        setError(data.message || 'Gagal mengirim pesan.')
        setSuccess(false)
      }
    } catch (err) {
      console.error('[Contact] submit error:', err)
      setError('Terjadi kesalahan jaringan. Coba lagi sebentar lagi.')
      setSuccess(false)
    } finally {
      setIsSubmitting(false)
      reloadCaptcha()
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-blue-50/60 to-blue-100/40 text-gray-800 pt-28 pb-16">
      <div className="max-w-4xl mx-auto px-6 space-y-10">
        {/* HERO / INTRO */}
        <section className="text-center space-y-4">
          <div className="flex justify-center">
            <Image
              src="/images/logo-hidupai.png"
              alt="HidupAI"
              width={110}
              height={110}
              className="drop-shadow-sm"
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
            📬 Hubungi Tim HidupAI
          </h1>
          <p className="text-sm sm:text-base text-gray-600 max-w-md mx-auto">
            Kirimkan pertanyaan, ide, atau masukanmu — kami senang mendengar langsung
            dari orang-orang yang sedang membangun hidupnya dengan lebih sadar.
          </p>
        </section>

        {/* CONTENT GRID: FORM + INFO */}
        <section className="grid gap-8 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] items-start">
          {/* FORM CARD */}
          <div className="rounded-2xl bg-white border border-gray-200 shadow-sm p-6 sm:p-7">
            <h2 className="text-base font-semibold text-slate-900 mb-1">
              Kirim Pesan
            </h2>
            <p className="text-xs text-gray-500 mb-4">
              Form ini akan mengirim email langsung ke tim HidupAI.
            </p>

            {success && (
              <div className="mb-4 rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-xs sm:text-sm text-green-700">
                ✅ Pesan berhasil dikirim. Terima kasih sudah menghubungi HidupAI!
              </div>
            )}

            {error && (
              <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs sm:text-sm text-red-700">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Nama */}
              <div className="space-y-1">
                <label
                  htmlFor="name"
                  className="text-xs font-medium text-gray-700"
                >
                  Nama Kamu
                </label>
                <Input
                  id="name"
                  type="text"
                  name="name"
                  placeholder="Contoh: Noer Barri"
                  required
                  className="text-sm"
                />
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label
                  htmlFor="email"
                  className="text-xs font-medium text-gray-700"
                >
                  Email Aktif
                </label>
                <Input
                  id="email"
                  type="email"
                  name="email"
                  placeholder="contoh@email.com"
                  required
                  className="text-sm"
                />
              </div>

              {/* Pesan */}
              <div className="space-y-1">
                <label
                  htmlFor="message"
                  className="text-xs font-medium text-gray-700"
                >
                  Pesan
                </label>
                <Textarea
                  id="message"
                  name="message"
                  rows={5}
                  placeholder="Ceritakan kebutuhanmu, ide fitur, atau masukan untuk HidupAI..."
                  required
                  className="text-sm resize-none"
                />
              </div>

              {/* CAPTCHA */}
              <div className="space-y-1">
                <span className="text-xs font-medium text-gray-700">
                  Verifikasi Manusia
                </span>
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  {captchaUrl && (
                    <Image
                      src={captchaUrl}
                      alt="CAPTCHA"
                      width={120}
                      height={48}
                      className="h-12 border rounded-md cursor-pointer bg-white"
                      onClick={reloadCaptcha}
                      unoptimized
                    />
                  )}
                  <Input
                    type="text"
                    name="captcha_input"
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                    placeholder="Masukkan kode di gambar"
                    required
                    className="text-sm"
                  />
                </div>
                <p className="text-[11px] text-gray-500 mt-1">
                  Klik gambar untuk memuat ulang jika kode sulit dibaca.
                </p>
              </div>

              <Button
                type="submit"
                className="w-full mt-3 text-sm"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Mengirim...' : 'Kirim Pesan'}
              </Button>
            </form>
          </div>

          {/* SIDE INFO / CONTEXT */}
          <aside className="space-y-4 text-sm text-gray-700">
            <div className="rounded-2xl bg-white/70 border border-blue-100 p-4 shadow-sm">
              <h3 className="text-xs font-semibold text-blue-800 uppercase tracking-wide mb-2">
                Kapan Sebaiknya Menghubungi?
              </h3>
              <ul className="space-y-1.5 text-xs sm:text-sm">
                <li>• Ingin tahu lebih jauh tentang arah HidupAI.</li>
                <li>• Masukan fitur atau ide integrasi (Notion, tools lain).</li>
                <li>• Pertanyaan seputar paket Premium dan penggunaan untuk tim.</li>
              </ul>
            </div>

            <div className="rounded-2xl bg-slate-900 text-slate-50 p-4 shadow-sm space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-300">
                Catatan Penting
              </p>
              <p className="text-xs sm:text-sm text-slate-100">
                HidupAI bukan pengganti layanan psikolog/psikiater. Untuk kondisi
                darurat atau klinis, tetap utamakan bantuan profesional.
              </p>
            </div>

            <div className="rounded-2xl bg-white/80 border border-gray-200 p-4 shadow-sm text-xs sm:text-sm">
              <p className="font-semibold text-gray-800 mb-1">
                Waktu Respon
              </p>
              <p className="text-gray-600">
                Kami berusaha merespon pesan yang masuk secepat mungkin. Jika
                belum terbalas, pesanmu tetap kami baca dan pertimbangkan dalam
                pengembangan HidupAI ke depan. 🌱
              </p>
            </div>
          </aside>
        </section>
      </div>
    </main>
  )
}
