'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { useRouter } from 'next/navigation'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import Image from 'next/image'

export default function ProfilePage() {
  const supabase = createClientComponentClient()
  const router = useRouter()

  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user?.email) {
        router.replace('/login')
        return
      }

      setEmail(user.email)

      const { data } = await supabase
        .from('users')
        .select('name')
        .eq('email', user.email)
        .single()

      if (data) {
        setName(data.name || '')
      }
    }

    fetchUser()
  }, [router, supabase])

  const handleUpdate = async () => {
    setLoading(true)
    setMessage('')

    const { error } = await supabase
      .from('users')
      .update({ name })
      .eq('email', email)

    if (error) {
      setMessage('❌ Gagal update nama.')
    } else {
      setMessage('✅ Nama berhasil diperbarui!')
    }

    setLoading(false)
  }

  return (
    <main className="max-w-md mx-auto p-6 space-y-4">
      <div className="flex justify-center">
        <Image src="/images/logo-hidupai.png" alt="Logo" width={64} height={64} />
      </div>

      <h1 className="text-xl font-bold text-center mb-4">Edit Nama Profil ✏️</h1>

      <Card>
        <CardContent className="space-y-4 p-4">
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nama kamu"
          />
          <Input
            value={email}
            readOnly
            className="bg-gray-100 text-gray-500"
          />

          <Button onClick={handleUpdate} disabled={loading} className="w-full">
            {loading ? 'Menyimpan...' : '💾 Simpan Perubahan'}
          </Button>

          {message && <p className="text-sm text-center mt-2 text-blue-600">{message}</p>}
        </CardContent>
      </Card>

      <div className="text-center">
        <Button variant="ghost" onClick={() => router.push('/dashboard')}>
          ← Kembali ke Dashboard
        </Button>
      </div>
    </main>
  )
}
