// File: app/compare-plan/page.tsx

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

const plans = [
  {
    name: 'Gratis',
    price: 'Rp0',
    features: [
      '5 chat per hari',
      'Ringkasan mingguan (terbatas)',
      'Tanpa login Google',
    ]
  },
  {
    name: 'Trial 7 Hari',
    price: 'Rp15.000',
    features: [
      'Akses premium selama 7 hari',
      'Semua fitur premium terbuka',
      'Auto expire setelah 7 hari',
    ]
  },
  {
    name: 'Premium Lifetime',
    price: 'Rp50.000',
    features: [
      'Akses selamanya',
      'Tanpa langganan bulanan',
      'Akses fitur dasar premium',
    ]
  },
  {
    name: 'Pro Plan',
    price: 'Rp79.000 / tahun',
    features: [
      'Akses semua fitur premium + tools AI',
      'Unduh PDF, dashboard interaktif',
      'Fitur roadmap, planner, & Notion',
    ]
  },
]

export default function ComparePlanPage() {
  return (
    <main className="max-w-5xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center mb-10">📊 Bandingkan Paket HidupAI</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan, i) => (
          <Card key={i}>
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-semibold text-center">{plan.name}</h2>
              <p className="text-center text-2xl text-blue-600 font-bold">{plan.price}</p>
              <ul className="text-sm text-gray-600 space-y-2">
                {plan.features.map((feat, idx) => (
                  <li key={idx}>✅ {feat}</li>
                ))}
              </ul>
              <div className="text-center pt-4">
                <Link href="/pricing">
                  <Button className="w-full">Pilih Paket</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      <p className="text-center text-sm text-gray-400 mt-8">
        Ingin tahu lebih banyak? <Link href="/pricing" className="underline">Lihat detail lengkap & kebijakan upgrade</Link>
      </p>
    </main>
  )
}
