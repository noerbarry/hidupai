import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { cookies } from 'next/headers'
import type { NextRequest } from 'next/server'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function middleware(request: NextRequest) {
  const cookieStore = await cookies() // ✅ Pakai await
  const email = cookieStore.get('user-email')?.value

  if (!email) {
    return NextResponse.json({ success: false, message: 'Unauthorized (no email)' }, { status: 401 })
  }

  const { data: user, error } = await supabase
    .from('users')
    .select('is_premium, premium_until')
    .eq('email', email)
    .maybeSingle()

  if (error || !user) {
    return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 })
  }

  const today = new Date().toISOString().split('T')[0]
  const expired = user.premium_until && new Date(user.premium_until) < new Date(today)
  const isPremium = user.is_premium && !expired

  if (!isPremium) {
    return NextResponse.json({ success: false, message: 'Access denied – premium only' }, { status: 403 })
  }

  return NextResponse.next()
}
