import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST() {
  const supabase = createRouteHandlerClient({ cookies })

  const {
    data: { user },
    error
  } = await supabase.auth.getUser()

  if (error || !user?.email) {
    return NextResponse.json({ success: false, badge: 'Newbie' }, { status: 401 })
  }

  const { data, error: userError } = await supabase
    .from('users')
    .select('referral_points')
    .eq('email', user.email)
    .maybeSingle()

  if (userError || !data) {
    return NextResponse.json({ success: false, badge: 'Newbie' }, { status: 404 })
  }

  const badge = getBadge(data.referral_points || 0)

  // optional: update badge di Supabase
  await supabase
    .from('users')
    .update({ badge })
    .eq('email', user.email)

  return NextResponse.json({ success: true, badge })
}

// Helper function
function getBadge(points: number): string {
  if (points >= 30) return 'Champion'
  if (points >= 15) return 'Warrior'
  if (points >= 5) return 'Starter'
  return 'Newbie'
}
