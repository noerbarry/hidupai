import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  const { newUserEmail, referralCode } = await req.json()

  if (!newUserEmail || !referralCode) {
    return NextResponse.json({ error: 'Missing email or referral code' }, { status: 400 })
  }

  const { data: referrer } = await supabase
    .from('users')
    .select('email')
    .eq('referral_code', referralCode)
    .single()

  if (!referrer) {
    return NextResponse.json({ error: 'Referral code tidak valid' }, { status: 404 })
  }

  // Update user baru → isi kolom referred_by
  await supabase
    .from('users')
    .update({ referred_by: referralCode })
    .eq('email', newUserEmail)

  // Tambah poin referral untuk afiliator
  await supabase
    .from('users')
    .update({ referral_points: supabase.rpc('increment_referral_points', { email_input: referrer.email }) })
    .eq('email', referrer.email)

  return NextResponse.json({ success: true })
}
