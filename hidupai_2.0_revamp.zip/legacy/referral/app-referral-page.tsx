'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import Cookies from 'js-cookie'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import Image from 'next/image'

export default function ReferralPage() {
  const [referralCode, setReferralCode] = useState('')
  const [referralPoints, setReferralPoints] = useState(0)
  const [copied, setCopied] = useState(false)
  const [fullLink, setFullLink] = useState('')

  const email = Cookies.get('user-email')

  useEffect(() => {
    if (!email) return

    fetch('/api/check-user')
      .then(res => res.json())
      .then(data => {
        const code = data.referral_code || ''
        setReferralCode(code)

        if (typeof window !== 'undefined') {
          setFullLink(`${window.location.origin}/login?ref=${code}`)
        }

        setReferralPoints(data.referral_points || 0)
      })
  }, [email])

  const copyLink = () => {
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(fullLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <main className="max-w-md mx-auto p-6 space-y-6">
      <div className="text-center">
        <Image
          src="/images/logo-hidupai.png"
          alt="Logo"
          width={64}
          height={64}
          className="mx-auto mb-3"
        />
        <h1 className="text-2xl font-bold">Program Referral HidupAI 🎁</h1>
        <p className="text-sm text-gray-600 mt-1">Ajak temanmu dan dapatkan hadiah!</p>
      </div>

      <Card>
        <CardContent className="space-y-4 p-4">
          <div>
            <p className="text-sm text-gray-700 font-medium">Kode Referral Kamu:</p>
            <Input readOnly value={referralCode} />
          </div>

          <div>
            <p className="text-sm text-gray-700 font-medium">Link Ajak Teman:</p>
            <div className="flex gap-2">
              <Input readOnly value={fullLink} />
              <Button onClick={copyLink} variant="outline">
                {copied ? '✅' : '📋'}
              </Button>
            </div>
          </div>

          <div className="text-sm text-green-700">
            🎉 Kamu sudah mengajak <strong>{referralPoints}</strong> teman!
          </div>
        </CardContent>
      </Card>

      <p className="text-center text-xs text-gray-400">
        1 teman yang daftar = +1 poin. Kumpulkan & tukarkan dengan hadiah 🎁
      </p>
    </main>
  )
}
