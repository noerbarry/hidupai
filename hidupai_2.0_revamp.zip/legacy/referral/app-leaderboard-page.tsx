'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'

interface Leader {
  name: string
  referral_points: number
}

export default function ReferralLeaderboardPage() {
  const [leaders, setLeaders] = useState<Leader[]>([])

  useEffect(() => {
    fetch('/api/referral/leaderboard')
      .then(res => res.json())
      .then(data => setLeaders(data))
  }, [])

  return (
    <main className="max-w-md mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold text-center">🏆 Top 10 Referral</h1>
      <Card>
        <CardContent className="p-4 space-y-2">
          {leaders.length === 0 ? (
            <p className="text-sm text-center text-gray-500 italic">Belum ada referral yang dikumpulkan.</p>
          ) : (
            <ul className="space-y-2">
              {leaders.map((leader, i) => (
                <li key={i} className="flex justify-between items-center">
                  <span>{i + 1}. {leader.name}</span>
                  <span className="text-blue-600 font-bold">{leader.referral_points} pts</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <p className="text-xs text-center text-gray-500 mt-4">🎁 Peringkat tinggi berpeluang dapat reward premium, eWallet, dan akses tools eksklusif!</p>
    </main>
  )
}
