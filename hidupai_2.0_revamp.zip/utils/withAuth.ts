// utils/withAuth.ts

import { verifyToken } from './verifyToken'
import { NextResponse } from 'next/server'

export async function withAuth(
  req: Request,
  handler: (email: string, req: Request) => Promise<Response>
): Promise<Response> {
  try {
    const { email } = await verifyToken(req) // ✅ pastikan async/await
    return await handler(email, req)
  } catch (err: any) {
    console.error('🔐 Auth Error:', err.message)
    return NextResponse.json({ error: err.message }, { status: 401 })
  }
}
