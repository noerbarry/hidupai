// utils/verifyToken.ts
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function verifyToken(req: Request): Promise<{ email: string }> {
  const authHeader =
    req.headers.get('Authorization') || req.headers.get('authorization')
  const token = authHeader?.split(' ')[1]

  if (!token) throw new Error('Token tidak ditemukan')

  const {
    data: { user },
    error
  } = await supabase.auth.getUser(token)

  if (error || !user?.email) {
    console.error('❌ Token tidak valid atau email tidak ditemukan:', error)
    throw new Error('Token tidak valid')
  }

  return { email: user.email }
}
