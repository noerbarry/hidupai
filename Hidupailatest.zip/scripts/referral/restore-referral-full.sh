#!/bin/bash

echo "♻️ Memulihkan semua file referral dari legacy/referral..."

# ⬅️ Kembalikan file halaman
mkdir -p app/referral/leaderboard

mv legacy/referral/app-referral-page.tsx app/referral/page.tsx 2>/dev/null
mv legacy/referral/app-leaderboard-page.tsx app/referral/leaderboard/page.tsx 2>/dev/null

# ⬅️ Kembalikan folder /refer
mv legacy/referral/app-refer app/refer 2>/dev/null

# ⬅️ Kembalikan folder API referral
mv legacy/referral/api-referral app/api/referral 2>/dev/null

# ⬅️ Kembalikan komponen
mv legacy/referral/ReferralShare.tsx components/ReferralShare.tsx 2>/dev/null
mv legacy/referral/ReferralFriends.tsx components/ReferralFriends.tsx 2>/dev/null
mv legacy/referral/ReferralLeaderboard.tsx components/ReferralLeaderboard.tsx 2>/dev/null

echo "✅ Semua file referral berhasil dipulihkan!"

