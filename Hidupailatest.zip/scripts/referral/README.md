# 📦 Referral Feature – Archive Notes

Per 21 April 2025, semua fitur referral diarsipkan karena strategi monetisasi difokuskan ulang.

## Komponen yang Dipindahkan:

### ✅ UI/Components
- ReferralShare.tsx
- ReferralLeaderboard.tsx
- ReferralFriends.tsx

### ✅ API Endpoints
- /api/referral/points
- /api/referral/badge
- /api/referral/convert

### ✅ Pages
- /app/referral/page.tsx
- /app/referral/leaderboard/page.tsx
- /app/refer/

### 📁 Lokasi Arsip
Dipindahkan ke: `legacy/referral/`

### 🛑 Environment
Pastikan `.env` menyertakan:
```
FEATURE_REFERRAL=false
```

## Catatan Tambahan
Jika ingin mengaktifkan ulang referral, cukup jalankan script `restore-referral-full.sh` dan set `FEATURE_REFERRAL=true`.

---
