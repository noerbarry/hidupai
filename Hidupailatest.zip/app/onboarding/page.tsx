/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Send, Mic, User, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

type MessageType = { role: 'user' | 'assistant'; content: string };

export default function OnboardingPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClientComponentClient(), []);

  // refs
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // state
  const [name, setName] = useState<string>('');
  const [goal, setGoal] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [isPremium, setIsPremium] = useState<boolean>(false);
  const [usageToday, setUsageToday] = useState<number>(0);

  // upgrade modal state
  const [upgrading, setUpgrading] = useState<boolean>(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState<boolean>(false);
  const [upgradeError, setUpgradeError] = useState<boolean>(false);
  const [lastAmount, setLastAmount] = useState<number | null>(null);

  // voice input
  const [listening, setListening] = useState<boolean>(false);
  const showUpgradeCTA = !isPremium && messages.length === 0;

  // dynamically loaded component
  const LifeRankCard = useMemo(
    () => dynamic(() => import('@/components/LifeRankCard'), { ssr: false }),
    []
  );

  // typing indicator
  const TypingDots = () => (
    <div className="flex items-center gap-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="w-2 h-2 bg-[#2563EB] dark:bg-[#1E40AF] rounded-full animate-bounce"
          style={{ animationDelay: `${i * 0.2}s` }}
        />
      ))}
    </div>
  );

  // initialize SpeechRecognition
  const initVoice = useCallback(() => {
    if (typeof window === 'undefined') return;
    const RecClass = (window as any).webkitSpeechRecognition;
    if (typeof RecClass !== 'function') return;
    const rec = new RecClass();
    rec.lang = 'id-ID';
    rec.interimResults = false;
    rec.onresult = (e: any) => {
      setInput(e.results[0][0].transcript);
      inputRef.current?.focus();
    };
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
  }, []);

  // toggle voice recording
  const toggleListening = useCallback(() => {
    const rec = recognitionRef.current;
    if (!rec) return;
    if (listening) rec.stop();
    else rec.start();
    setListening((v) => !v);
  }, [listening]);

  // load session & profile
  useEffect(() => {
    initVoice();
    let isMounted = true;
    const ctl = new AbortController();

    async function loadProfile() {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();
        if (!session?.access_token) {
          router.push('/login');
          return;
        }
        const res = await fetch('/api/check-user', {
          signal: ctl.signal,
          headers: { Authorization: `Bearer ${session.access_token}` },
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          router.push('/register');
          return;
        }
        if (isMounted) {
          setEmail(data.email);
          setName(data.name);
          setGoal(data.goal);
          setIsPremium(data.is_premium);
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.error(err);
          toast.error('Gagal memuat profil');
        }
      }
    }

    loadProfile();
    return () => {
      isMounted = false;
      ctl.abort();
    };
  }, [initVoice, supabase, router]);

  // fetch usage for free users
  useEffect(() => {
    if (!email || isPremium) return;
    let isMounted = true;
    const ctl = new AbortController();

    async function fetchUsage() {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();
        if (!session?.access_token) return;
        const res = await fetch('/api/usage', {
          signal: ctl.signal,
          headers: { Authorization: `Bearer ${session.access_token}` },
        });
        const d = await res.json();
        if (res.ok && d.success && isMounted) {
          setUsageToday(d.usage_today ?? 0);
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.error(err);
          toast.error('Gagal mengambil data penggunaan');
        }
      }
    }

    fetchUsage();
    return () => {
      isMounted = false;
      ctl.abort();
    };
  }, [email, isPremium, supabase]);

  // auto scroll on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // send chat message
  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text) return;
    if (!isPremium && usageToday >= 5) {
      setUpgradeError(false);
      setUpgradeModalOpen(true);
      return;
    }
    const userMsg: MessageType = { role: 'user', content: text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No session');
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ messages: [...messages, userMsg], name, goal, email }),
      });
      const d = await res.json();
      setMessages((m) => [...m, { role: 'assistant', content: d.message }]);
      setUsageToday((u) => u + 1);
    } catch (err: any) {
      console.error(err);
      toast.error('Gagal mengirim pesan');
    } finally {
      setLoading(false);
    }
  }, [input, isPremium, usageToday, messages, name, goal, email, supabase]);

  // handle upgrade via Midtrans Snap.js
  const handleUpgrade = useCallback(
    async (amount: number) => {
      setUpgradeError(false);
      setLastAmount(amount);
      setUpgrading(true);
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();
        if (!session?.access_token) throw new Error('No session');
        const res = await fetch('/api/snap-token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            email,
            amount,
            plan_type: amount === 15000 ? 'trial' : 'pro',
          }),
        });
        const d = await res.json();
        const snap = (window as any).snap;
        if (d.token && typeof snap?.pay === 'function') {
          snap.pay(d.token, {
            onSuccess: () => {
              toast.success('✅ Pembayaran berhasil');
              router.refresh();
            },
            onPending: () => toast('⏳ Menunggu konfirmasi'),
            onError: () => {
              setUpgradeError(true);
              toast.error('❌ Pembayaran gagal');
            },
            onClose: () => {
              setUpgradeError(true);
              toast.error('❌ Transaksi dibatalkan');
            },
          });
        } else {
          throw new Error('Midtrans error');
        }
      } catch (err: any) {
        console.error(err);
        setUpgradeError(true);
        toast.error('⚠️ Gagal memproses pembayaran');
      } finally {
        setUpgrading(false);
      }
    },
    [email, supabase, router]
  );

  // logout
  const handleLogout = useCallback(async () => {
    await supabase.auth.signOut();
    router.push('/login');
  }, [supabase, router]);

  return (
    <main className="min-h-screen bg-white dark:bg-zinc-900 dark:text-gray-100">
      {/* HEADER */}
      <header className="sticky top-0 bg-white dark:bg-zinc-900 z-40 shadow p-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="rounded-full bg-[#2563EB]/10 w-8 h-8 flex items-center justify-center">
            <User className="w-5 h-5 text-[#2563EB]" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">Hai, {name} 👋</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">Tujuanmu: {goal}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <a href="/dashboard" className="underline text-[#2563EB] dark:text-[#93C5FD]">
            📊 Dashboard
          </a>
          <button onClick={handleLogout} className="text-red-600 hover:scale-105 transition">
            Keluar
          </button>
        </div>
      </header>

      {/* CONTENT */}
      <section className="max-w-lg md:max-w-xl mx-auto px-4 space-y-4 pt-4 pb-[calc(env(safe-area-inset-bottom)+140px)]">
        {!isPremium && (
          <div className="mb-2">
            <Progress value={(usageToday / 5) * 100} />
            <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
              💬 {usageToday}/5 chat gratis hari ini
            </p>
          </div>
        )}

        {showUpgradeCTA && (
          <div className="mb-4 p-4 bg-[#EFF6FF] dark:bg-zinc-800 rounded-lg text-center max-w-sm mx-auto">
            <Button
              onClick={() => setUpgradeModalOpen(true)}
              disabled={upgrading}
              className="w-full mb-4 bg-[#2563EB] hover:bg-[#1E40AF] text-white rounded-xl flex items-center justify-center gap-2"
            >
              <Mic className="w-5 h-5" /> Trial 7 Hari — Rp15.000
            </Button>
            <Button
              variant="outline"
              onClick={() => setUpgradeModalOpen(true)}
              disabled={upgrading}
              className="w-full border-2 border-[#2563EB] text-[#2563EB] hover:bg-[#EFF6FF] dark:hover:bg-[#1E3A8A] rounded-xl flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" /> Premium — Rp79.000
            </Button>
          </div>
        )}

        {isPremium && (
          <>
            <div className="flex items-center gap-2">
              <span className="inline-block bg-gradient-to-r from-[#2563EB] to-[#2563EB]/80 text-white px-3 py-1 rounded-full text-xs font-semibold">
                Premium 🚀
              </span>
              <LifeRankCard email={email} isPremium={isPremium} />
            </div>
            <div className="bg-yellow-100 dark:bg-yellow-900/10 border border-yellow-200 dark:border-yellow-700 text-yellow-800 dark:text-yellow-200 p-4 rounded-xl text-sm">
              <h3 className="font-semibold">
                🔮 Sudah coba{' '}
                <a href="/life-arena" className="underline text-[#2563EB] dark:text-[#93C5FD]">
                  Life Arena Pro
                </a>
                ?
              </h3>
              <p>Simulasikan keputusan besar hidupmu dengan AI yang memahami emosi dan tujuanmu.</p>
              <Button onClick={() => router.push('/life-arena')} className="mt-3 w-full bg-[#2563EB] hover:bg-[#1E40AF] text-white">
                Jelajahi Life Arena
              </Button>
            </div>
          </>
        )}

        {/* Chat messages */}
        <div
          className="overflow-y-auto"
          style={{
            maxHeight: showUpgradeCTA
              ? `calc(100vh - 96px - 64px - 176px)`
              : `calc(100vh - 96px - 64px)`,
          }}
        >
          {messages.length === 0 && !loading ? (
            <div className="text-center text-sm text-gray-400 dark:text-gray-500 py-12">
              🌱 <span className="font-medium">Mulai cerita hidupmu hari ini</span>
            </div>
          ) : (
            <div className="space-y-2 px-2">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} text-sm`}
                >
                  <div
                    className={`max-w-[80%] px-4 py-3 my-1 rounded-2xl shadow ${
                      msg.role === 'user'
                        ? 'bg-blue-100 text-blue-900 ring-1 ring-blue-200'
                        : 'bg-yellow-100 dark:bg-zinc-800 text-yellow-900 dark:text-yellow-300 border border-yellow-300'
                    }`}
                  >
                    {msg.content}
                    {msg.role === 'assistant' && (
                      <div className="text-[10px] text-gray-400 dark:text-gray-500 mt-1 italic">
                        HidupAI
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 px-4 py-2">
                  <TypingDots /> <span>HidupAI sedang berpikir…</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </section>

      {/* INPUT BAR */}
      <div className="fixed inset-x-0 bottom-0 bg-white dark:bg-zinc-900 px-4 py-3 shadow-inner flex items-center gap-2 z-50">
        <button
          aria-label={listening ? 'Stop voice input' : 'Start voice input'}
          onClick={toggleListening}
          disabled={loading || upgrading}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-zinc-800 transition"
        >
          <Mic className="w-5 h-5 text-[#2563EB]" />
        </button>
        <Input
          ref={inputRef}
          value={input}
          placeholder="Ketik sesuatu..."
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          disabled={loading || upgrading}
          className="flex-1 focus:ring-2 focus:ring-[#2563EB]"
        />
        <Button
          onClick={handleSend}
          disabled={loading || upgrading || (!isPremium && usageToday >= 5)}
          className={`px-6 flex items-center gap-2 transition ${
            !isPremium && usageToday >= 5
              ? 'bg-gray-400 cursor-not-allowed text-gray-100'
              : 'bg-gradient-to-r from-[#2563EB] to-[#1E40AF] hover:opacity-90'
          }`}
        >
          <Send className="w-5 h-5 text-white" />
          {!isPremium && usageToday >= 5 ? 'Upgrade untuk lanjut' : 'Kirim'}
        </Button>
      </div>

      {/* UPGRADE MODAL */}
      {upgradeModalOpen && (
        <>
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
          <div className="fixed inset-x-0 bottom-0 z-50 max-h-[50vh] bg-white dark:bg-zinc-900 rounded-t-2xl p-6 space-y-4">
            <div className="w-10 h-1 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-2" />
            {upgradeError && lastAmount && (
              <div className="bg-red-100 text-red-800 px-4 py-2 rounded-md mb-4 text-sm flex items-center gap-2">
                <XCircle className="w-4 h-4" />
                Transaksi dibatalkan.{' '}
                <button onClick={() => handleUpgrade(lastAmount)} className="underline">Coba lagi</button>
              </div>
            )}
            <h2 className="text-lg font-semibold">Pilih paket upgrade</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Kuota chat gratis habis. Pilih paket untuk lanjut:
            </p>
            <div className="space-y-4">
              <Button
                onClick={() => handleUpgrade(15000)}
                disabled={upgrading}
                className="w-full bg-[#2563EB] hover:bg-[#1E40AF] text-white rounded-xl flex items-center justify-center gap-2 py-3"
              >
                <Mic className="w-5 h-5" /> Trial 7 Hari — Rp15.000
              </Button>
              <Button
                variant="outline"
                onClick={() => handleUpgrade(79000)}
                disabled={upgrading}
                className="w-full border-2 border-[#2563EB] text-[#2563EB] hover:bg-[#EFF6FF] dark:hover:bg-[#1E3A8A] rounded-xl flex items-center justify-center gap-2 py-3"
              >
                <Send className="w-5 h-5" /> Premium — Rp79.000
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  setUpgradeError(false);
                  setUpgradeModalOpen(false);
                }}
                className="w-full text-center text-gray-500 dark:text-gray-400"
              >
                Batal
              </Button>
            </div>
          </div>
        </>
      )}
    </main>
  );
}
