'use client'

import { useState } from 'react'

export default function ManualUpgradePage() {
  const [orderId, setOrderId] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [status, setStatus] = useState<'success' | 'error' | 'info' | ''>('')

  const handleSubmit = async () => {
    if (!orderId.trim()) {
      setStatus('error')
      setMessage('❌ Harap masukkan Order ID')
      return
    }

    setLoading(true)
    setStatus('info')
    setMessage('⏳ Memverifikasi ke Midtrans...')

    try {
      const res = await fetch('/api/manual-upgrade', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + (localStorage.getItem('access_token') || '')
        },
        body: JSON.stringify({ order_id: orderId.trim() })
      })

      const data = await res.json()
      if (res.ok && data.success) {
        setStatus('success')
        setMessage(`✅ Upgrade berhasil untuk ${data.message} (hingga ${data.until})`)
        setOrderId('')
      } else {
        setStatus('error')
        setMessage(`❌ Gagal: ${data.error || 'Terjadi kesalahan'}`)
      }
    } catch {
      setStatus('error')
      setMessage('❌ Gagal terhubung ke server')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-4 border rounded-xl shadow space-y-4">
      <h1 className="text-xl font-bold">🔧 Manual Upgrade Plan</h1>
      <input
        type="text"
        placeholder="Masukkan Order ID dari Midtrans"
        value={orderId}
        onChange={(e) => setOrderId(e.target.value)}
        className="w-full border p-2 rounded"
      />
      <button
        onClick={handleSubmit}
        disabled={loading}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full"
      >
        {loading ? 'Memproses...' : 'Upgrade Sekarang'}
      </button>

      {message && (
        <p
          className={`text-sm text-center ${
            status === 'success'
              ? 'text-green-600'
              : status === 'error'
              ? 'text-red-600'
              : 'text-gray-600'
          }`}
        >
          {message}
        </p>
      )}
    </div>
  )
}
