export default function PremiumError() {
    return (
      <main className="min-h-screen flex items-center justify-center text-center p-8">
        <div>
          <h1 className="text-xl font-bold text-red-600">❌ Pembayaran Gagal</h1>
          <p className="text-gray-600 mt-2">Yuk coba lagi atau hubungi tim kami jika masalah terus terjadi.</p>
        </div>
      </main>
    )
  }
  