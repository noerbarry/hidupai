// File: app/terms-and-conditions/page.tsx
'use client'


export default function TermsAndConditionsPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-gray-800 pt-24 pb-16">
      {/* ✅ Header Navigation - Konsisten */}


      {/* ✅ Main Content */}
      <div className="max-w-4xl mx-auto mt-40 px-6 space-y-6">
        <h1 className="text-2xl font-bold text-center">📜 Kebijakan Pengembalian Dana</h1>
        <p className="text-sm text-gray-600 text-center max-w-md mx-auto">
          Kami di HidupAI berkomitmen untuk memberikan layanan terbaik kepada pengguna kami. Berikut adalah kebijakan pengembalian dana untuk transaksi layanan premium.
        </p>

        <div className="mt-8 text-base md:text-lg text-gray-700 space-y-8">
          <div>
            <h2 className="font-semibold text-xl mb-2">1. Transaksi Final</h2>
            <p>
              Semua transaksi yang dilakukan pada platform HidupAI bersifat final dan tidak dapat dikembalikan. Setelah pembayaran untuk layanan Premium atau Pro berhasil diproses, layanan digital akan diberikan secara langsung, dan tidak ada pengembalian dana yang akan diproses setelah itu.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-xl mb-2">2. Produk Digital dan Pengembalian Dana</h2>
            <p>
              Mengingat sifat produk digital yang kami tawarkan, yang dapat segera diakses setelah pembayaran, kami tidak menyediakan pengembalian dana dalam situasi apapun, termasuk jika pengguna mengubah keputusan setelah melakukan pembelian.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-xl mb-2">3. Pengujian Layanan Sebelum Pembelian</h2>
            <p>
              Kami memberikan akses uji coba gratis untuk membantu Anda memahami layanan kami lebih baik sebelum melakukan pembelian. Silakan gunakan kesempatan ini untuk memastikan apakah layanan kami sesuai dengan kebutuhan Anda.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-xl mb-2">4. Masalah Teknis</h2>
            <p>
              Jika Anda mengalami masalah teknis yang menghambat akses ke fitur premium setelah pembayaran, tim support kami siap membantu untuk menyelesaikan kendala yang ada. Kami berkomitmen untuk memberikan solusi terbaik agar pengalaman Anda dengan HidupAI tetap optimal.
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}
