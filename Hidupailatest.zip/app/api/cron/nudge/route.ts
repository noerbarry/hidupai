// File: app/api/cron/nudge/route.ts

import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  // ✅ Proteksi endpoint (opsional tapi direkomendasikan)
  const auth = req.headers.get('Authorization')
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  // Ambil semua user dengan data penting
  const { data: users, error } = await supabase
    .from('users')
    .select('email, name, weekly_goal, preferred_mode')

  if (error || !users) {
    console.error('❌ Gagal ambil data user:', error)
    return NextResponse.json({ message: 'Gagal ambil user' }, { status: 500 })
  }

  // Susun nudge personal berdasarkan preferensi user
  const nudgePayload = users.map((user) => {
    const name = user.name || 'teman'
    const goal = user.weekly_goal || 'menjadi lebih baik'
    const mode = user.preferred_mode || 'default'

    let message = ''

    switch (mode) {
      case 'pagi':
        message = `Selamat pagi, ${name}! ☀️ Hari baru, semangat baru. Jangan lupa niatmu: "${goal}". Yuk mulai langkah kecil hari ini 💪`
        break
      case 'mentok':
        message = `${name}, kalau ngerasa buntu hari ini, pelan-pelan aja. Fokus ke satu hal kecil yang mendekatkan ke "${goal}" 🌱`
        break
      case 'sedih':
        message = `Hai ${name}, gak apa-apa merasa lelah. Tapi ingat, kamu tetap berharga. Pelan-pelan aja menuju "${goal}" 🤍`
        break
      default:
        message = `Hai ${name}, ingat tujuanmu minggu ini: "${goal}" 🌟 Yuk refleksi sebentar. Aku di sini buat kamu kapan pun.`
    }

    return {
      email: user.email,
      message,
      created_at: new Date().toISOString()
    }
  })

  // Simpan pesan ke tabel `nudge_messages`
  const { error: insertError } = await supabase
    .from('nudge_messages')
    .insert(nudgePayload)

  if (insertError) {
    console.error('❌ Gagal simpan nudge:', insertError)
    return NextResponse.json({ message: 'Gagal simpan nudge' }, { status: 500 })
  }

  return NextResponse.json({ message: '✅ Nudge berhasil dikirim ke semua user' })
}
