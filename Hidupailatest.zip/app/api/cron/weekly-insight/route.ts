// File: app/api/cron/weekly-insight/route.ts

import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET() {
  // ✅ Cek apakah cron sedang aktif (via .env)
  if (process.env.CRON_ENABLED !== 'true') {
    console.log('⏸️ Cron job is currently disabled (maintenance mode)')
    return NextResponse.json({ message: 'Cron is disabled' }, { status: 503 })
  }

  if (!process.env.RESEND_API_KEY) {
    console.error('❌ RESEND_API_KEY tidak tersedia.')
    return NextResponse.json({ success: false, error: 'Resend API key missing' }, { status: 500 })
  }

  // ✅ Ambil semua user premium
  const { data: users, error } = await supabase
    .from('users')
    .select('email, name')
    .eq('is_premium', true)

  if (error) {
    console.error('❌ Gagal fetch users:', error)
    return NextResponse.json({ success: false, error }, { status: 500 })
  }

  let successCount = 0

  for (const user of users) {
    const { email, name } = user

    try {
      console.log(`📬 Kirim weekly insight ke: ${email}`)

      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: 'HidupAI <noreply@hidupai.vercel.app>',
          to: [email],
          subject: `🧠 Refleksi Mingguan dari HidupAI`,
          html: `<h2>Halo, ${name || 'teman HidupAI'}!</h2>
            <p>✨ Saatnya meluangkan waktu sebentar untuk merenungkan perjalanan hidupmu minggu ini.</p>
            <p>Kamu sudah melakukan hal hebat, dan HidupAI siap bantu kamu melangkah ke depan.</p>
            <br/>
            <p class="text-sm text-gray-500">Email ini dikirim otomatis tiap minggu kepada user premium.</p>`
        })
      })

      successCount++
    } catch (err) {
      console.error(`❌ Gagal kirim ke ${email}`, err)
    }
  }

  return NextResponse.json({ success: true, sent: successCount })
}
