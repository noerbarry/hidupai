import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function GET(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { searchParams } = new URL(req.url)
  const email = searchParams.get('email')

  if (!email) return NextResponse.json({ error: 'Email diperlukan' }, { status: 400 })

  const { data, error } = await supabase
    .from('agentic_preferences')
    .select('mode, goal')
    .eq('email', email)
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({
    mode: data?.mode || '',
    goal: data?.goal || ''
  })
}

export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, mode, goal } = await req.json()

  if (!email) return NextResponse.json({ error: 'Email diperlukan' }, { status: 400 })

  const { data: existing } = await supabase
    .from('agentic_preferences')
    .select('email')
    .eq('email', email)
    .single()

  const updates = {
    ...(mode && { mode }),
    ...(goal && { goal })
  }

  let result
  if (existing) {
    result = await supabase
      .from('agentic_preferences')
      .update(updates)
      .eq('email', email)
  } else {
    result = await supabase
      .from('agentic_preferences')
      .insert({ email, ...updates })
  }

  if (result.error) {
    return NextResponse.json({ error: result.error.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
