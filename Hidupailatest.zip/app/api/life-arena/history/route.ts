import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const email = searchParams.get('email')
    if (!email) {
      return NextResponse.json({ success: false, message: 'Email dibutuhkan' }, { status: 400 })
    }

    const { data, error } = await supabase
      .from('life_arena_simulations')
      .select('*')
      .eq('email', email)
      .order('created_at', { ascending: false })

    if (error) throw error

    return NextResponse.json({ success: true, simulations: data })
  } catch (err) {
    console.error('[Life Arena History Error]', err)
    return NextResponse.json({ success: false, message: 'Gagal memuat histori' }, { status: 500 })
  }
}
