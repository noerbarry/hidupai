import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import OpenAI from 'openai'

// ✅ Supabase client (server role)
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

// ✅ OpenAI instance
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!
})

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // ✅ Ambil user dari token Supabase
    const { data: { user } } = await supabase.auth.getUser(token)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized user' }, { status: 401 })
    }

    const body: unknown = await req.json()
    if (
      !body ||
      typeof body !== 'object' ||
      !('topic' in body) ||
      !('decision' in body) ||
      !('values' in body)
    ) {
      return NextResponse.json({ error: 'Input tidak valid' }, { status: 400 })
    }

    const { topic, decision, values } = body as {
      topic: string
      decision: string
      values: string[]
    }

    if (!topic || !decision || !Array.isArray(values) || values.length === 0) {
      return NextResponse.json({ error: 'Input tidak valid' }, { status: 400 })
    }

    // ✅ Validasi akses premium
    const allowFree = process.env.FEATURE_LIFE_ARENA_FREE === 'true'

    const { data: profile } = await supabase
      .from('users')
      .select('plan_type, premium_until, name')
      .eq('email', user.email)
      .maybeSingle()

    const today = new Date().toISOString().split('T')[0]
    const isExpired = profile?.premium_until && new Date(profile.premium_until) < new Date(today)
    const isPremiumUser =
      ['premium', 'pro', 'trial'].includes(profile?.plan_type || '') && !isExpired

    if (!isPremiumUser && !allowFree) {
      return NextResponse.json({ error: 'Fitur hanya untuk pengguna premium' }, { status: 403 })
    }

    const userName = profile?.name || 'teman'

    // ✅ Prompt reflektif untuk AI
    const prompt = `
Kamu adalah AI reflektif yang membantu pengguna mengambil keputusan penting dalam hidup mereka berdasarkan nilai-nilai pribadi.

Topik keputusan: ${topic}
Deskripsi keputusan: ${decision}
Nilai-nilai yang dianggap penting: ${values.join(', ')}
Nama pengguna: ${userName}

Tulis analisis reflektif yang menyentuh dan bernilai emosional. Tunjukkan empati dan ajak pengguna untuk memahami dirinya lebih dalam. Setelah itu, berikan 3–5 langkah nyata yang bisa dilakukan pengguna dalam waktu dekat untuk memperjelas arah atau memperkuat keputusannya. Hindari nada seperti mesin atau chatbot. Gunakan gaya bahasa seperti mentor atau konselor hidup yang bijak dan peduli.
`

    const chatResponse = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: 'Kamu adalah AI reflektif dan empatik yang membantu pengguna mengevaluasi pilihan hidup dengan hati-hati.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7
    })

    const result = chatResponse.choices[0]?.message?.content || '❌ Gagal mendapatkan hasil dari AI.'

    // ✅ Simpan log ke Supabase
    await supabase.from('life_arena_logs').insert([
      {
        user_email: user.email,
        topic,
        decision,
        values,
        result
      }
    ])

    return NextResponse.json({ success: true, result })

  } catch (err: unknown) {
    console.error('🔥 Life Arena Error:', err)
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 })
  }
}
