// FINAL ✅ HidupAI Weekly Coaching Refleksi
// Lokasi: app/api/agentic-chat/weekly-coaching/route.ts

import { OpenAIStream, StreamingTextResponse } from 'ai'
import { NextResponse } from 'next/server'

export const runtime = 'edge'

export async function POST(req: Request) {
  const { email } = await req.json()

  if (!email) {
    return NextResponse.json({ error: 'Email diperlukan' }, { status: 400 })
  }

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, OPENAI_API_KEY } = process.env

  try {
    // Ambil data dari Supabase, termasuk is_premium
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/users?select=goal,preferred_mode,long_term_memory,is_premium&email=eq.${email}`,
      {
        headers: {
          apikey: SUPABASE_SERVICE_ROLE_KEY!,
          Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY!}`,
        },
      }
    )

    const users = await res.json()
    const user = users[0]

    if (!user) {
      return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
    }

    const memoryFormatted = user.long_term_memory
      ? JSON.stringify(user.long_term_memory, null, 2)
      : 'Belum ada memori.'

    const prompt = `
Kamu adalah pelatih hidup (Life Coach AI) yang memahami pengguna secara mendalam. Gunakan informasi berikut untuk membuat refleksi mingguan:

- Tujuan Hidup Pengguna: ${user.goal || 'Belum diisi'}
- Mode Reflektif: ${user.preferred_mode || 'default'}
- Memori Jangka Panjang Pengguna:
${memoryFormatted}

Tugasmu:
1. Tulis refleksi mingguan yang menyentuh, seperti catatan dari seorang mentor.
2. Berikan 2 pertanyaan reflektif personal untuk minggu berikutnya.
3. Jangan menyapa atau menyebut nama pengguna.

Gunakan gaya bahasa empatik, mendalam, dan penuh kesadaran.
`

    const model = user.is_premium ? 'gpt-4' : 'gpt-3.5-turbo'

    const aiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        stream: true,
        messages: [
          {
            role: 'system',
            content: 'Kamu adalah Life Coach AI reflektif dari HidupAI.',
          },
          { role: 'user', content: prompt },
        ],
      }),
    })

    const stream = OpenAIStream(aiResponse)
    return new StreamingTextResponse(stream)
  } catch (err) {
    console.error('[Weekly Coaching Error]', err)
    return NextResponse.json({ error: 'Terjadi kesalahan saat menghasilkan refleksi.' }, { status: 500 })
  }
}
