import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { renderToBuffer } from '@react-pdf/renderer'
import { generateInvoicePDF } from '@/lib/pdf-generator'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const order_id = searchParams.get('order_id')

  if (!order_id) {
    return NextResponse.json({ error: 'order_id tidak ditemukan' }, { status: 400 })
  }

  const { data: order, error } = await supabase
  .from('orders')
  .select('*')
  .eq('order_id', order_id)
  .in('status', ['settlement', 'capture']) // 🔥 hanya status sukses
  .single()

  if (error || !order) {
    return NextResponse.json({ error: 'Order tidak ditemukan' }, { status: 404 })
  }

  const invoiceDocument = generateInvoicePDF({
    orderId: order.order_id,
    email: order.email,
    packageName: order.plan_type,
    amount: order.amount,
    status: order.status,
    paidAt: order.paid_at
  })

  const pdfBuffer = await renderToBuffer(invoiceDocument)

  return new NextResponse(pdfBuffer, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="invoice-${order.order_id}.pdf"`
    }
  })
}
