// File: app/api/liferank/insight/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  const { email } = await req.json()
  if (!email) {
    return NextResponse.json({ success: false, message: 'Email wajib diisi.' }, { status: 400 })
  }

  // Ambil data user dari Supabase
  const { data: user, error } = await supabase
    .from('users')
    .select('is_premium')
    .eq('email', email)
    .maybeSingle()

  if (error || !user) {
    return NextResponse.json({ success: false, message: 'User tidak ditemukan' }, { status: 404 })
  }

  if (!user.is_premium) {
    return NextResponse.json({ success: false, message: 'Hanya tersedia untuk pengguna Premium' }, { status: 403 })
  }

  // Ambil data LifeRank dari endpoint lokal
  const liferankRes = await fetch(`${process.env.APP_URL}/api/liferank?email=${email}`)
  const liferank = await liferankRes.json()

  if (!liferank.success) {
    return NextResponse.json({ success: false, message: 'Gagal ambil data LifeRank' }, { status: 500 })
  }

  const prompt = `
Kamu adalah asisten reflektif bernama HidupAI.

Berdasarkan data berikut:
- Skor LifeRank: ${liferank.score}/100
- Rank: ${liferank.rank}
- Habit aktif: ${liferank.habitDays} hari
- Goal diset: ${liferank.hasGoal ? '✅ Ya' : '❌ Tidak'}
- Chat AI aktif: ${liferank.usedChat ? '✅ Ya' : '❌ Tidak'}
- Ekspor Insight: ${liferank.hasExported ? '✅ Ya' : '❌ Tidak'}
- Poin Referral: ${liferank.referralPoints}

Buatlah 1 paragraf insight reflektif yang:
- Empatik dan memotivasi
- Bukan teknikal
- Tulis sebagai sahabat yang peduli
- Gaya bahasa hangat dan suportif
`

  const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'system', content: prompt }]
    })
  })

  const data = await openaiRes.json()
  const insight = data.choices?.[0]?.message?.content?.trim()

  return NextResponse.json({
    success: true,
    insight: insight || 'Belum tersedia.'
  })
}
