import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, mode } = await req.json()

  if (!email || !mode?.trim()) {
    return NextResponse.json({ error: 'Email dan mode diperlukan' }, { status: 400 })
  }

  const { error } = await supabase
    .from('users')
    .update({ preferred_mode: mode.trim() })
    .eq('email', email)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
