import { withAuth } from '@/utils/withAuth'
import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: Request) {
  return withAuth(req, async (email) => {
    const { data: user, error } = await supabase
      .from('users')
      .select('usage_today, is_premium, premium_until, plan_type')
      .eq('email', email)
      .maybeSingle()

    if (error || !user) {
      return NextResponse.json({ success: false }, { status: 404 })
    }

    const today = new Date().toISOString().split('T')[0]
    const expired = user.premium_until && new Date(user.premium_until) < new Date(today)
    const is_premium = user.is_premium && !expired

    return NextResponse.json({
      success: true,
      is_premium,
      usage_today: user.usage_today || 0,
      premium_until: user.premium_until,
      plan_type: user.plan_type || 'free'
    })
  })
}
