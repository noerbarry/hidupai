import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: Request) {
  const { name, email, message, captcha_input } = await req.json()
  const cookieStore = await cookies() // ✅ Fix async
  const token = cookieStore.get('captcha_token')?.value

  if (!token || captcha_input?.toLowerCase() !== token?.toLowerCase()) {
    return NextResponse.json({ success: false, message: 'Captcha tidak valid' }, { status: 400 })
  }

  // Email logic tetap sama
  const { error } = await resend.emails.send({
    from: 'HidupAI Contact <no-reply@hidupai.com>', // sementara pakai ini dulu
    to: ['hidupaiapp@gmail.com'],
    subject: `📩 Pesan Baru dari ${name}`,
    html: `
      <div style="font-family: sans-serif;">
        <h2>Pesan dari Website HidupAI</h2>
        <p><strong>Nama:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Pesan:</strong><br />${message}</p>
      </div>
    `
  })

  if (error) {
    console.error(error)
    return NextResponse.json({ success: false, message: 'Gagal mengirim email' }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}