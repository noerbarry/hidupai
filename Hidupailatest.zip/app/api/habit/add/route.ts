// File: app/api/habit/add/route.ts

import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  try {
    const { email, habit_name, completed = true } = await req.json()

    if (!email || !habit_name) {
      return NextResponse.json({ success: false, error: 'Email dan nama kebiasaan wajib diisi.' }, { status: 400 })
    }

    const today = new Date().toISOString().split('T')[0] // Format: YYYY-MM-DD

    const { error } = await supabase
      .from('habit_logs')
      .insert([{
        email,
        habit_name,
        completed,
        date: today
      }])

    if (error) {
      console.error('❌ Gagal menambahkan log kebiasaan:', error.message)
      return NextResponse.json({ success: false, error: 'Gagal menyimpan log.' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('❌ Error saat parsing:', err)
    return NextResponse.json({ success: false, error: 'Request tidak valid.' }, { status: 400 })
  }
}
