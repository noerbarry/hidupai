// File: /app/api/memory/new/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const { email, content } = await req.json()

    // Validasi input
    if (!email || typeof email !== 'string' || !content || typeof content !== 'string' || !content.trim()) {
      return NextResponse.json({ error: 'Email atau konten tidak valid' }, { status: 400 })
    }

    // Ambil user ID berdasarkan email
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single()

    if (userError || !user) {
      return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
    }

    // Simpan memori baru
    const { error: insertError } = await supabase
      .from('long_term_memories')
      .insert({
        user_id: user.id,
        content: content.trim(),
      })

    if (insertError) {
      return NextResponse.json({ error: insertError.message }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Unexpected error:', err)
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 })
  }
}
