// File: app/api/memory/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function GET(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { searchParams } = new URL(req.url)
  const email = searchParams.get('email')

  if (!email) {
    return NextResponse.json({ error: '❌ Email tidak disediakan.' }, { status: 400 })
  }

  // 1. Ambil user
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id, preferred_mode, weekly_goal')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: '❌ User tidak ditemukan.' }, { status: 404 })
  }

  // 2. Ambil memori berdasarkan user_id
  const { data: memories, error: memoryError } = await supabase
    .from('long_term_memories')
    .select('id, content')
    .eq('user_id', user.id)
    .order('created_at', { ascending: true })

  if (memoryError) {
    return NextResponse.json({ error: '❌ Gagal mengambil memori: ' + memoryError.message }, { status: 500 })
  }

  return NextResponse.json({
    memory: memories || [],
    mode: user.preferred_mode || '',
    goal: user.weekly_goal || ''
  })
}
