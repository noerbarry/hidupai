import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })

  const { email, mode = null, goal = null } = await req.json()

  if (!email) {
    return NextResponse.json({ error: 'Email tidak ditemukan' }, { status: 400 })
  }

  // Cek apakah preferensi sudah ada
  const { data: existing, error: fetchError } = await supabase
    .from('agentic_preferences')
    .select('email')
    .eq('email', email)
    .single()

  if (fetchError && fetchError.code !== 'PGRST116') {
    return NextResponse.json({ error: fetchError.message }, { status: 500 })
  }

  let result
  if (existing) {
    result = await supabase
      .from('agentic_preferences')
      .update({ mode, goal })
      .eq('email', email)
  } else {
    result = await supabase
      .from('agentic_preferences')
      .insert({ email, mode, goal })
  }

  if (result.error) {
    return NextResponse.json({ error: result.error.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
