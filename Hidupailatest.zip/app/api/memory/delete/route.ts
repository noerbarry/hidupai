// File: app/api/memory/delete/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function DELETE(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, index } = await req.json()

  // Validasi input
  if (!email || typeof index !== 'number') {
    return NextResponse.json({ error: 'Email dan index diperlukan.' }, { status: 400 })
  }

  // Ambil user.id dari email
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan.' }, { status: 404 })
  }

  // Ambil semua memori untuk user dan urutkan sesuai tampilan
  const { data: memories, error: memoryError } = await supabase
    .from('long_term_memories')
    .select('id')
    .eq('user_id', user.id)
    .order('created_at', { ascending: true })

  if (memoryError || !memories || !memories[index]) {
    return NextResponse.json({ error: 'Memori tidak ditemukan pada index tersebut.' }, { status: 404 })
  }

  const memoryIdToDelete = memories[index].id

  // Hapus memori berdasarkan id
  const { error: deleteError } = await supabase
    .from('long_term_memories')
    .delete()
    .eq('id', memoryIdToDelete)

  if (deleteError) {
    return NextResponse.json({ error: deleteError.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
