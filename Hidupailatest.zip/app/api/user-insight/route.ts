import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function GET() {
  const supabase = createRouteHandlerClient({ cookies })
  const { data: { session } } = await supabase.auth.getSession()

  const email = session?.user?.email
  if (!email) {
    return NextResponse.json({ insights: [] }, { status: 401 })
  }

  const { data, error } = await supabase
    .from('insight_logs')
    .select('insights')
    .eq('user_email', email)
    .order('created_at', { ascending: false })
    .limit(1)
    .single()

  if (error) {
    console.error('Error fetching insights:', error)
    return NextResponse.json({ insights: [] }, { status: 500 })
  }

  return NextResponse.json({ insights: data?.insights || [] })
}

export async function POST(request: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { data: { session } } = await supabase.auth.getSession()

  const email = session?.user?.email
  if (!email) {
    return NextResponse.json({ success: false }, { status: 401 })
  }

  const body = await request.json()
  const { insights } = body

  if (!Array.isArray(insights) || insights.length === 0) {
    return NextResponse.json({ success: false, message: 'Invalid insights' }, { status: 400 })
  }

  const { error } = await supabase
    .from('insight_logs')
    .insert({ user_email: email, insights })

  if (error) {
    console.error('Insert error:', error)
    return NextResponse.json({ success: false }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
