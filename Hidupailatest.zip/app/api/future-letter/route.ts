import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  const { email, message, open_date } = await req.json()

  if (!email || !message || !open_date) {
    return NextResponse.json({ success: false, message: 'Data tidak lengkap.' }, { status: 400 })
  }

  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ success: false, message: 'User tidak ditemukan.' }, { status: 404 })
  }

  const { error: insertError } = await supabase.from('future_letters').insert({
    user_id: user.id,
    message,
    open_date,
    is_opened: false
  })

  if (insertError) {
    return NextResponse.json({ success: false, message: 'Gagal menyimpan surat.' }, { status: 500 })
  }

  return NextResponse.json({ success: true, message: 'Surat berhasil disimpan.' })
}
