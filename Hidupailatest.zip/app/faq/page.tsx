'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function FAQPage() {
  return (
    <>
      {/* 🚀 Sticky Navigation Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-6 py-3 flex justify-between items-center">
          <Link href="/">
            <Image src="/images/logo-hidupai.png" alt="HidupAI" width={120} height={120} />
          </Link>
          <nav className="hidden md:flex gap-6 text-sm text-gray-700">
            <a href="#fitur" className="hover:text-blue-600">Beranda</a>
            <Link href="/pricing" className="hover:text-blue-600">Harga</Link>
            <Link href="/about" className="hover:text-blue-600">Tentang</Link>
            <a href="#komunitas" className="hover:text-blue-600">Komunitas</a>
            <Link href="/faq" className="hover:text-blue-600">FAQ</Link>
            <Link href="/contact" className="hover:text-blue-600">Contact</Link>
            <Link href="/terms-and-conditions" className="hover:text-blue-600">Term & Conditions</Link>
            <Link href="/disclaimer" className="hover:text-blue-600">Disclaimer</Link>
          </nav>
          <Link href="/login">
            <Button className="text-sm">✨ Masuk / Daftar</Button>
          </Link>
        </div>
      </header>

      {/* 📄 CONTENT */}
      <main className="max-w-3xl mx-auto px-6 py-32 text-gray-800 space-y-10">

        <section className="space-y-8 text-sm">
          <div>
            <h2 className="font-semibold text-blue-800">1. Apa itu HidupAI?</h2>
            <p className="mt-1 text-gray-700">
              HidupAI adalah platform refleksi diri berbasis Agentic AI yang mendampingi kamu dalam menetapkan tujuan,
              membangun kebiasaan, dan melakukan refleksi bermakna setiap hari.
              Tidak seperti chatbot biasa, HidupAI memiliki memori jangka panjang, memahami emosi, dan memberi insight mingguan yang relevan dan personal.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-blue-800">2. Apakah HidupAI gratis digunakan?</h2>
            <p className="mt-1 text-gray-700">
              Ya, versi gratis tersedia dengan akses hingga 5 percakapan per hari. Untuk fitur refleksi penuh, pengguna dapat upgrade ke versi Premium kapan saja.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-blue-800">3. Apa keunggulan versi Premium?</h2>
            <p className="mt-1 text-gray-700">
              - Akses tanpa batas & refleksi harian<br />
              - Insight mingguan berbasis AI<br />
              - Fitur Future Letter, Soul Journal, Growth Memory, Life Rank<br />
              - Ringkasan PDF dan tools eksklusif seperti Notion Planner & Roadmap Pribadi
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-blue-800">4. Apakah data saya aman di HidupAI?</h2>
            <p className="mt-1 text-gray-700">
              Tentu. Semua data disimpan secara aman dan hanya digunakan untuk meningkatkan pengalaman pengguna.
              Tidak ada data yang dijual ke pihak ketiga.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-blue-800">5. Apakah saya perlu login untuk menggunakan?</h2>
            <p className="mt-1 text-gray-700">
              Ya. Login dibutuhkan agar HidupAI dapat menyimpan progres kamu, mengenali pola pikir dan tujuan hidupmu, serta menjaga pengalaman tetap personal dan konsisten.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-blue-800">6. Apakah tersedia aplikasi di Android/iOS?</h2>
            <p className="mt-1 text-gray-700">
              Belum. Saat ini HidupAI tersedia sebagai aplikasi web yang bisa diakses dari browser HP atau desktop, dengan tampilan ringan dan responsif.
            </p>
          </div>

          <div>
            <h2 className="font-semibold text-blue-800">7. Bagaimana cara upgrade ke Premium?</h2>
            <p className="mt-1 text-gray-700">
              Buka halaman <Link href="/pricing" className="text-blue-600 underline">Harga</Link>, lalu klik “Upgrade Sekarang” dan selesaikan pembayaran.
              Akunmu akan langsung aktif sebagai pengguna Premium tanpa perlu input manual.
            </p>
          </div>
        </section>

        <div className="text-center mt-12">
          <Link href="/" className="text-blue-600 underline text-sm hover:text-blue-800">
            ← Kembali ke Beranda HidupAI
          </Link>
        </div>
      </main>
    </>
  )
}
