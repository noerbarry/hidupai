'use client'

import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { useState, useEffect } from 'react'


export default function ContactPage() {
  const [captchaUrl, setCaptchaUrl] = useState('')
  const [captchaInput, setCaptchaInput] = useState('')
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    reloadCaptcha()
  }, [])

  const reloadCaptcha = () => {
    setCaptchaUrl(`/api/custom-captcha?reload=${Date.now()}`)
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const name = formData.get('name')
    const email = formData.get('email')
    const message = formData.get('message')

    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        email,
        message,
        captcha_input: captchaInput
      })
    })

    if (res.ok) {
      setSuccess(true)
      setError('')
      e.currentTarget.reset()
      setCaptchaInput('')
    } else {
      const data = await res.json()
      setError(data.message || 'Gagal mengirim pesan.')
      setSuccess(false)
    }

    reloadCaptcha()
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-gray-800 pt-24 pb-16">
      {/* Header */}


      {/* Contact Section */}
      <div className="max-w-xl mx-auto mt-40 px-6 space-y-6">
        <h1 className="text-2xl font-bold text-center">📬 Hubungi Tim HidupAI</h1>
        <p className="text-sm text-gray-600 text-center max-w-md mx-auto">
          Kirimkan pertanyaan, ide, atau masukanmu — kami terbuka dan senang mendengarnya.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input type="text" name="name" placeholder="Nama Kamu" required />
          <Input type="email" name="email" placeholder="Email Aktif" required />
          <Textarea name="message" rows={5} placeholder="Pesanmu" required />

          {/* CAPTCHA */}
          <div className="flex items-center gap-4">
            {captchaUrl && (
              <Image
                src={captchaUrl}
                alt="CAPTCHA"
                width={100}
                height={48}
                className="h-12 border rounded cursor-pointer"
                onClick={reloadCaptcha}
                unoptimized
              />
            )}
            <Input
              type="text"
              name="captcha_input"
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value)}
              placeholder="Masukkan kode di gambar"
              required
            />
          </div>

          <Button type="submit" className="w-full mt-4">Kirim Pesan</Button>

          {success && <p className="text-green-600 text-sm text-center">✅ Pesan berhasil dikirim!</p>}
          {error && <p className="text-red-600 text-sm text-center">{error}</p>}
        </form>
      </div>
    </main>
  )
}
