// File: app/pricing/page.tsx
import Image from 'next/image'
import Pricing from '@/components/Pricing'
import WhyHidupAI from '@/components/WhyHidupAI'



// ✅ Metadata SEO
export const metadata = {
  title: 'Harga HidupAI Premium – AI Mentor untuk Tujuan Hidupmu',
  description:
    'Upgrade ke HidupAI Premium untuk akses AI tanpa batas, refleksi mingguan, dan pendampingan personal setiap hari. Coba sekarang & wujudkan hidup yang lebih terarah.',
  openGraph: {
    title: 'Harga HidupAI Premium – AI Mentor untuk Tujuan Hidupmu',
    description:
      'AI mentor digital untuk bantu kamu fokus, refleksi, dan bertumbuh setiap hari. Pilih paket terbaik HidupAI sekarang.',
    url: 'https://hidupai.com/pricing',
    type: 'website',
    images: [
      {
        url: 'https://hidupai.com/og/pricing-og.png',
        width: 1200,
        height: 630,
        alt: 'Harga HidupAI Premium'
      }
    ]
  }
}

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-amber-50 pb-16">
      {/* ✅ HEADER */}


      {/* ✅ HERO */}
      <section className="max-w-4xl mx-auto text-center pt-40 pb-12 px-4">
        <div className="mb-4">
          <Image
            src="/images/logo-hidupai.png"
            alt="Logo HidupAI"
            width={100}
            height={100}
            className="mx-auto"
          />
        </div>
        <h1 className="text-4xl font-bold text-gray-800">Pilih Paket HidupAI Premium</h1>
        <p className="mt-2 text-gray-600 text-lg">
          Dapatkan fitur lebih, bantu kamu fokus ke tujuan hidup ✨
        </p>
        <p className="mt-3 text-sm text-orange-500 font-medium">
          🚧 Telah Resmi Launching: HidupAI kini siap digunakan untuk bantu kamu mencapai tujuan hidup dengan AI ✨
        </p>
      </section>

      {/* ✅ PRICING SECTION */}
      <Pricing />

      {/* ✅ WHY HIDUPAI */}
      <section className="max-w-4xl mx-auto mt-16 px-4">
        <WhyHidupAI />
      </section>
    </main>
  )
}
