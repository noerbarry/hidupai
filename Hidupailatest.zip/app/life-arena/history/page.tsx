'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

interface Simulation {
  created_at: string
  title?: string
  result: string
}

export default function LifeArenaHistory() {
  const [simulations, setSimulations] = useState<Simulation[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const resSession = await fetch('/api/check-user')
        if (!resSession.ok) {
          router.push('/login')
          return
        }

        const user = await resSession.json()

        const res = await fetch(`/api/life-arena/history?email=${user.email}`)
        if (!res.ok) throw new Error('Gagal fetch histori')

        const data = await res.json()
        if (data.success) {
          setSimulations(data.simulations)
        }
      } catch (err) {
        console.error('❌ Gagal memuat histori:', err)
      } finally {
        setLoading(false)
      }
    }

    setTimeout(fetchData, 100)
  }, [router])

  return (
    <main className="max-w-2xl mx-auto px-4 pt-24 space-y-6">
      <h1 className="text-2xl font-bold">📚 Histori Life Arena</h1>
      {loading ? (
        <p className="text-sm text-gray-500 italic">Memuat histori...</p>
      ) : simulations.length === 0 ? (
        <p className="text-sm text-gray-500 italic">Belum ada histori simulasi.</p>
      ) : (
        <ul className="space-y-4">
          {simulations.map((sim, i) => (
            <li key={i} className="p-4 border border-gray-200 rounded shadow bg-white">
              <p className="text-xs text-gray-400">{new Date(sim.created_at).toLocaleString()}</p>
              <p className="font-semibold text-gray-800">{sim.title || 'Simulasi Tanpa Judul'}</p>
              <p className="text-sm text-gray-600 mt-1 whitespace-pre-line">{sim.result}</p>
            </li>
          ))}
        </ul>
      )}
    </main>
  )
}
