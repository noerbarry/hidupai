// File: app/disclaimer/page.tsx
'use client'


export default function DisclaimerPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-gray-800 pt-24 pb-16">
      {/* ✅ HEADER */}

      {/* 📝 CONTENT */}
      <div className="max-w-3xl mx-auto px-6 mt-40 space-y-8 text-sm text-gray-800">
        <h1 className="text-3xl font-bold text-gray-800">📢 Disclaimer HidupAI</h1>
        <p>
          Terima kasih telah menggunakan <strong>HidupAI</strong>. Dengan menggunakan situs, aplikasi, dan seluruh layanan HidupAI, Anda dianggap telah menyetujui seluruh isi dari disclaimer ini.
        </p>

        <div className="space-y-6">
          <section>
            <h2 className="text-xl font-semibold">1. Bukan Pengganti Profesional</h2>
            <p>
              HidupAI adalah platform <strong>AI mentoring digital</strong> yang bertujuan untuk membantu refleksi pribadi, peningkatan diri, dan konsistensi kebiasaan harian.
              <br />
              Namun, <strong>HidupAI bukan pengganti layanan profesional</strong> seperti psikolog, dokter, atau konselor. Untuk kondisi medis atau psikologis, harap hubungi tenaga profesional berwenang.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">2. Keakuratan dan Batasan Informasi</h2>
            <p>
              Semua informasi dari AI, habit, refleksi, atau insight disediakan <em>sebagaimana adanya</em> dan <strong>bukan sebagai nasihat absolut</strong>. 
              Pengguna bertanggung jawab penuh atas keputusan yang diambil.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">3. Konten yang Dibuat Pengguna</h2>
            <p>
              Semua data dan konten yang dimasukkan pengguna ke HidupAI adalah tanggung jawab pengguna. Kami tidak bertanggung jawab atas konsekuensi dari konten yang dikirim atau diproses oleh sistem.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">4. Interaksi AI dan Respon Otomatis</h2>
            <ul className="list-disc ml-6 space-y-1">
              <li>Respon AI bisa bersifat umum dan tidak selalu sesuai konteks pribadi pengguna.</li>
              <li>Respon dapat mengandung bias dari data pelatihan.</li>
              <li>Tidak semua respon mencerminkan posisi resmi HidupAI sebagai platform.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold">5. Perubahan dan Pembaruan</h2>
            <p>
              Isi halaman ini dapat berubah sewaktu-waktu tanpa pemberitahuan. Harap tinjau halaman ini secara berkala.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">6. Kontak</h2>
            <p>
              Jika ada pertanyaan tentang disclaimer ini, silakan <a href="https://hidupai.com/contact" className="underline text-blue-600">hubungi kami</a>.
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}
