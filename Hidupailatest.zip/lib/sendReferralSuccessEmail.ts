import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY!)

export async function sendReferralSuccessEmail(to: string, friendEmail: string) {
  try {
    await resend.emails.send({
      from: 'HidupAI <noreply@hidupai.com>',
      to,
      subject: '🎉 Temanmu berhasil upgrade Premium!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4f46e5;">Selamat! 🎉</h2>
          <p>Teman yang kamu undang, <strong>${friendEmail}</strong>, baru saja upgrade ke <strong>HidupAI Premium</strong>!</p>
          <p>Kamu dapat 5 poin tambahan. Terus bagikan link referralmu dan kumpulkan lebih banyak reward 💪</p>
          <p>Yuk ke dashboard sekarang dan cek reward kamu 👉 <a href="https://hidupai.com/dashboard">hidupai.com/dashboard</a></p>
          <br />
          <p style="font-size: 12px; color: #888;">Email ini dikirim otomatis oleh sistem HidupAI.</p>
          <p>— Tim HidupAI</p>
        </div>
      `
    })
  } catch (error) {
    console.error('❌ Gagal kirim email notifikasi referral:', error)
  }
}
