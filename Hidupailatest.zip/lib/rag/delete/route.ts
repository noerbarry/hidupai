// 📁 /app/api/rag/delete/route.ts
import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

export async function DELETE(req: Request) {
  const { email, index } = await req.json()

  const supabase = createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const { data } = await supabase
    .from('user_memories')
    .select('id')
    .eq('email', email)
    .order('created_at', { ascending: false })

  const target = data?.[index]
  if (!target) return NextResponse.json({ error: 'Memori tidak ditemukan' }, { status: 404 })

  const { error } = await supabase
    .from('user_memories')
    .delete()
    .eq('id', target.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
