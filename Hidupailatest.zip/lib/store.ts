import { create } from 'zustand'

type ChatMessage = {
  role: 'user' | 'assistant' | 'system'
  content: string
}

interface ChatStore {
  messages: ChatMessage[]
  name: string
  goal: string
  mode: string
  setMessages: (messages: ChatMessage[]) => void
  appendMessage: (message: ChatMessage) => void
  setUserInfo: (name: string, goal: string, mode?: string) => void
  clearMessages: () => void
}

export const useChatStore = create<ChatStore>((set) => ({
  messages: [],
  name: '',
  goal: '',
  mode: '',
  setMessages: (messages) => set({ messages }),
  appendMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),
  setUserInfo: (name, goal, mode = '') =>
    set({ name, goal, mode }),
  clearMessages: () =>
    set({ messages: [], name: '', goal: '', mode: '' }),
}))
