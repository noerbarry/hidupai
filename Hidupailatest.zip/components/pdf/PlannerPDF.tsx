// components/pdf/PlannerPDF.tsx

import React from 'react'
import { Document, Page, Text, StyleSheet } from '@react-pdf/renderer'

const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 12,
    lineHeight: 1.6,
    fontFamily: 'Helvetica'
  },
  title: {
    fontSize: 16,
    marginBottom: 10,
    fontWeight: 'bold'
  },
  content: {
    fontSize: 12,
    whiteSpace: 'pre-wrap'
  }
})

export default function PlannerPDF({
  name,
  planner
}: {
  name: string
  planner: string
}) {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <Text style={styles.title}>Weekly Habit Planner – {name}</Text>
        <Text style={styles.content}>{planner}</Text>
      </Page>
    </Document>
  )
}
