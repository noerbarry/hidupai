'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'

export default function AgenticSettings({
  email,
  mode,
  goal
}: {
  email: string
  mode: string
  goal: string
}) {
  const [newMode, setNewMode] = useState(mode || '')
  const [newGoal, setNewGoal] = useState(goal || '')
  const [saving, setSaving] = useState(false)
  const [savedAt, setSavedAt] = useState<Date | null>(null)

  // Ensure UI update when parent props change (from Supabase fetch)
  useEffect(() => {
    setNewMode(mode || '')
    setNewGoal(goal || '')
  }, [mode, goal])

  const handleSave = async () => {
    if (!email) return
    setSaving(true)

    try {
      const res = await fetch('/api/memory/update-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, mode: newMode, goal: newGoal })
      })

      if (!res.ok) throw new Error('Gagal menyimpan')

      setSavedAt(new Date())
    } catch (err) {
      console.error(err)
      alert('❌ Gagal menyimpan preferensi.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <h2 className="text-sm font-bold text-purple-600">⚙️ Pengaturan AI Agen</h2>

        <div className="space-y-2">
          <Label htmlFor="mode">Mode Interaksi</Label>
          <Input
            id="mode"
            value={newMode}
            onChange={(e) => setNewMode(e.target.value)}
            placeholder="Misalnya: Reflektif, Coaching, Spiritual"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="goal">Target Mingguan</Label>
          <Input
            id="goal"
            value={newGoal}
            onChange={(e) => setNewGoal(e.target.value)}
            placeholder="Contoh: Bangun jam 5 pagi & meditasi tiap hari"
          />
        </div>

        <Button onClick={handleSave} disabled={saving}>
          {saving ? '⏳ Menyimpan...' : '💾 Simpan Preferensi'}
        </Button>

        <div className="text-xs text-gray-500 italic mt-1">
          {saving && 'Menyimpan ke memori...'}
          {!saving && savedAt && '✅ Preferensi berhasil disimpan!'}
        </div>
      </CardContent>
    </Card>
  )
}
