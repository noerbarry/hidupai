'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

export default function PricingHeader() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const supabase = createClientComponentClient()

  useEffect(() => {
    const checkLogin = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      setIsLoggedIn(!!session?.user?.email)
    }
    checkLogin()
  }, [supabase])

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-6 py-3 flex flex-wrap md:flex-nowrap items-center justify-between gap-3">
        <Link href="/">
          <Image src="/images/logo-hidupai.png" alt="HidupAI" width={120} height={120} />
        </Link>
        <div className="hidden md:flex gap-6 text-sm text-gray-700">
          <Link href="/" className="hover:text-blue-600">Beranda</Link>
          <Link href="/pricing" className="hover:text-blue-600 font-bold">Harga</Link>
          <Link href="/about" className="hover:text-blue-600">Tentang</Link>
          <a href="#komunitas" className="hover:text-blue-600">Komunitas</a>
          <Link href="/faq" className="hover:text-blue-600">FAQ</Link>
          <Link href="/contact" className="hover:text-blue-600">Contact</Link>
          <Link href="/terms-and-conditions" className="hover:text-blue-600">Syarat dan Ketentuan</Link>
          <Link href="/disclaimer" className="hover:text-blue-600">Disclaimer</Link>
        </div>
        {isLoggedIn ? (
          <Link href="/dashboard" className="ml-auto md:ml-0">
            <Button className="text-sm">🚀 Dashboard</Button>
          </Link>
        ) : (
          <Link href="/login" className="ml-auto md:ml-0">
            <Button className="text-sm">✨ Masuk / Daftar</Button>
          </Link>
        )}
      </div>
    </header>
  )
}
