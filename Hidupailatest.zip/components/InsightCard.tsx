'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'

interface InsightCardProps {
  email: string
}

export default function InsightCard({ email }: InsightCardProps) {
  const [insights, setInsights] = useState<string[]>([])

  useEffect(() => {
    const fetchInsights = async () => {
      const res = await fetch(`/api/user-insight?email=${email}`)
      const data = await res.json()
      setInsights(data.insights || [])
    }
    fetchInsights()
  }, [email])

  const coachFeedback =
    insights.length > 0
      ? `✨ Berdasarkan datamu, kamu menunjukkan kecenderungan positif terhadap perkembangan diri. Pertahankan fokusmu, terutama dalam ${insights[0].toLowerCase().replace('✨ ', '')}`
      : ''

  return (
    <div className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-700 rounded-2xl shadow-md p-6 space-y-4">
      <h2 className="text-lg font-semibold text-blue-600 dark:text-blue-400">🧠 Insight Reflektif Mingguan</h2>
      <p className="text-sm text-gray-600 dark:text-gray-300">
        Apa yang AI pelajari dari aktivitas kamu minggu ini?
      </p>

      {/* Grafik */}
      <Image
        src={`/api/habit-chart?email=${email}`}
        alt="Grafik Habit"
        width={600}
        height={300}
        className="rounded-xl border shadow-sm mx-auto"
      />

      {/* List Insight */}
      <ul className="list-disc text-sm text-gray-700 dark:text-gray-200 pl-5 space-y-1">
        {insights.map((item, idx) => (
          <li key={idx}>{item}</li>
        ))}
      </ul>

      {/* AI Coach Comment */}
      {coachFeedback && (
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-800/30 border border-blue-200 dark:border-blue-700 rounded-xl text-sm text-blue-800 dark:text-blue-200">
          <p>💬 <strong>Refleksi AI:</strong> {coachFeedback}</p>
        </div>
      )}
    </div>
  )
}
