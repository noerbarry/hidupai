'use client'

import { useState } from 'react'

export default function RewardUnlock({ referralPoints }: { referralPoints: number }) {
  const [message, setMessage] = useState('')

  const handleUnlock = async (reward: 'planner' | 'notion' | 'beta') => {
    const res = await fetch('/api/referral/reward', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reward })
    })

    const data = await res.json()
    if (data.success) {
      if (reward === 'planner') {
        window.open('/downloads/planner.pdf', '_blank')
      } else if (reward === 'notion') {
        window.open('https://notion.link/hidupai-template', '_blank')
      }
    }

    setMessage(data.message || (data.success ? 'Reward berhasil di-unlock!' : 'Gagal unlock.'))
  }

  return (
    <div className="mt-6 p-4 border rounded-xl bg-white dark:bg-slate-800 space-y-4">
      <h2 className="text-lg font-bold">🎁 Hadiah dari Poin Referral</h2>
      <p className="text-sm text-gray-500">Kumpulkan poin dan tukarkan reward digital eksklusif!</p>

      <div className="space-y-3">
        <button
          className="text-sm px-3 py-2 bg-blue-100 text-blue-700 rounded disabled:opacity-50"
          onClick={() => handleUnlock('planner')}
          disabled={referralPoints < 3}
        >
          📄 Unduh Planner (3 Poin)
        </button>
        <button
          className="text-sm px-3 py-2 bg-green-100 text-green-700 rounded disabled:opacity-50"
          onClick={() => handleUnlock('notion')}
          disabled={referralPoints < 7}
        >
          📘 Notion Template (7 Poin)
        </button>
        <button
          className="text-sm px-3 py-2 bg-indigo-100 text-indigo-700 rounded disabled:opacity-50"
          onClick={() => handleUnlock('beta')}
          disabled={referralPoints < 10}
        >
          🚀 Akses Fitur Beta (10 Poin)
        </button>
      </div>

      {message && <p className="text-sm text-center text-emerald-600">{message}</p>}
    </div>
  )
}
