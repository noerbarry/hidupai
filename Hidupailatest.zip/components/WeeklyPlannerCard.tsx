'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'

export default function WeeklyPlannerCard({ email }: { email: string }) {
  const [planner, setPlanner] = useState('')
  const [loading, setLoading] = useState(true)

  const fetchPlanner = useCallback(async () => {
    if (!email) return
    setLoading(true)
    try {
      const res = await fetch('/api/ai/weekly-planner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      const data = await res.json()
      setPlanner(data.planner || 'Tidak ada planner tersedia.')
    } catch (err) {
      console.error('❌ Gagal mengambil planner:', err)
    } finally {
      setLoading(false)
    }
  }, [email])

  useEffect(() => {
    fetchPlanner()
  }, [fetchPlanner])

  const handleDownloadPDF = () => {
    alert('🚧 Fitur Download PDF belum diimplementasikan.')
  }

  const handleSendToNotion = () => {
    alert('🚧 Fitur Kirim ke Notion belum diimplementasikan.')
  }

  return (
    <Card>
      <CardContent className="p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold tracking-tight flex items-center gap-2">
            <span className="inline-block w-6 h-6 rounded-full bg-gradient-to-tr from-pink-500 to-indigo-500 text-white text-xs font-bold flex items-center justify-center shadow">
              🎯
            </span>
            <span className="bg-gradient-to-r from-gray-800 via-gray-900 to-black bg-clip-text text-transparent">
              AI Weekly Habit Planner
            </span>
          </h2>
          <Button size="sm" onClick={fetchPlanner}>
            🔄 Generate
          </Button>
        </div>

        {/* Planner Body */}
        <div className="rounded border bg-gray-50 p-4 text-sm text-gray-800 whitespace-pre-wrap overflow-x-auto">
          {loading ? (
            <p className="italic text-gray-500">
              🤖 HidupAI sedang menyusun strategi mingguanmu...
            </p>
          ) : (
            <div className="prose prose-sm max-w-none text-sm">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  table: (props) => (
                    <div className="overflow-x-auto">
                      <table className="table-auto border-collapse border border-gray-300 w-full text-left text-sm">
                        {props.children}
                      </table>
                    </div>
                  ),
                  th: (props) => (
                    <th
                      className="border border-gray-300 bg-gray-100 px-3 py-1 font-semibold"
                      {...props}
                    />
                  ),
                  td: (props) => (
                    <td className="border border-gray-200 px-3 py-1" {...props} />
                  ),
                }}
              >
                {planner}
              </ReactMarkdown>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
              📄 Download PDF
            </Button>
            <Button variant="outline" size="sm" onClick={handleSendToNotion}>
              🧾 Kirim ke Notion
            </Button>
          </div>
          <a
            href="https://www.notion.so/Weekly-Planner-AI-1e76cb5980ac800090eed29bdfeb53b1"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-blue-600 underline"
          >
            🔍 Lihat Planner di Notion
          </a>
        </div>
      </CardContent>
    </Card>
  )
}
