'use client'

import { useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function RedirectRefCheck() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const ref = searchParams.get('ref')

  useEffect(() => {
    const redirected = sessionStorage.getItem('redirected')
    const email = sessionStorage.getItem('user-email')

    if (!email && ref && !redirected) {
      sessionStorage.setItem('redirected', 'yes')
      router.replace(`/login?ref=${ref}`)
    }
  }, [ref, router])

  return null
}
