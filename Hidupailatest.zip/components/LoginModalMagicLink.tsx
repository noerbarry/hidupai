'use client'

import { useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Loader2, LogIn } from 'lucide-react'

export default function LoginModal({
  open,
  onClose
}: {
  open: boolean
  onClose: () => void
}) {
  const supabase = createClientComponentClient()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')

  const handleMagicLink = async () => {
    setLoading(true)
    setError('')
    const { error } = await supabase.auth.signInWithOtp({ email })
    if (error) {
      setError(error.message)
    } else {
      setSent(true)
    }
    setLoading(false)
  }

  const handleGoogleLogin = async () => {
    await supabase.auth.signInWithOAuth({ provider: 'google' })
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm mx-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Login ke HidupAI</DialogTitle>
        </DialogHeader>

        {sent ? (
          <div className="text-sm text-center text-green-600">
            ✅ Link login telah dikirim ke email kamu.
          </div>
        ) : (
          <div className="space-y-4">
            <Input
              placeholder="Email kamu"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
            {error && <p className="text-sm text-red-600">{error}</p>}
            <Button onClick={handleMagicLink} disabled={loading} className="w-full">
              {loading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <LogIn className="w-4 h-4 mr-2" />
              )}
              Kirim Magic Link
            </Button>
            <div className="text-center text-xs text-gray-400">atau</div>
            <Button onClick={handleGoogleLogin} variant="outline" className="w-full">
              Masuk dengan Google
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
