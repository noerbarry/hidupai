'use client'

import { useEffect, useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

interface Props {
  referralCode: string
}

export default function ReferralShare({ referralCode }: Props) {
  const [referralLink, setReferralLink] = useState('')
  const [whatsappText, setWhatsappText] = useState('')
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (!isMounted) return
    const baseUrl = window.location.origin
    const link = `${baseUrl}/login?ref=${referralCode}`
    const text = `Yuk daftar di HidupAI pakai link referral aku dan dapatin akses premium! 🚀\n${link}`
    setReferralLink(link)
    setWhatsappText(text)
  }, [referralCode, isMounted])

  if (!isMounted) return null

  return (
    <Card className="border-amber-300 bg-yellow-50 mt-4">
      <CardContent className="space-y-4 p-4">
        <p className="text-sm font-semibold text-yellow-800">📢 Ajak Teman & Dapatkan Poin</p>
        <p className="text-xs text-yellow-700">
          Setiap teman yang daftar pakai linkmu, kamu dapat <strong>1 poin</strong>. Kumpulkan 5 poin dan dapatkan akses <strong>Premium!</strong> 🚀
        </p>

        <div className="bg-white border rounded-md p-3 shadow-inner space-y-2">
          <p className="text-xs text-gray-600">Link Referral Kamu:</p>
          <div className="flex gap-2 items-center">
            <Input readOnly value={referralLink} className="text-xs bg-gray-100" />
            <Button
              size="sm"
              onClick={() => {
                navigator.clipboard.writeText(referralLink)
                alert('✅ Link disalin ke clipboard!')
              }}
            >
              Salin
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                window.open(`https://wa.me/?text=${encodeURIComponent(whatsappText)}`, '_blank')
              }
            >
              WhatsApp 📲
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
