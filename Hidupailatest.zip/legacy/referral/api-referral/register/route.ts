// File: app/api/register/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const referrerCode = searchParams.get('ref')

  const { name, goal, email } = await req.json()

  if (!email) {
    return NextResponse.json(
      { error: '🔒 Menyiapkan halaman... (login diperlukan)' },
      { status: 401 }
    )
  }

  const referralCode = 'ref-' + Math.random().toString(36).substring(2, 8)

  const { data: existingUser, error: existingError } = await supabase
    .from('users')
    .select('*')
    .eq('email', email)
    .single()

  if (!existingUser && !existingError) {
    await supabase.from('users').insert({
      email,
      name,
      goal,
      referral_code: referralCode,
      referrer_code: referrerCode || null,
      referral_points: 0,
      is_premium: false,
      badge: 'Newbie'
    })

    if (referrerCode) {
      await supabase.rpc('add_referral_point', { input_code: referrerCode })
    }
  } else {
    await supabase
      .from('users')
      .update({ name, goal })
      .eq('email', email)
  }

  return NextResponse.json({ status: 'ok' })
}
