import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

interface RewardRequest {
  reward: 'planner' | 'notion' | 'beta'
}

interface UserUpdate {
  referral_points?: number
  can_access_beta?: boolean
}

export async function POST(req: Request) {
  const cookieStore = await cookies() // ✅ Await di sini
  const email = cookieStore.get('user-email')?.value

  if (!email) {
    return NextResponse.json({ success: false, message: 'User belum login.' }, { status: 401 })
  }

  const { reward } = (await req.json()) as RewardRequest

  const { data: user, error: fetchError } = await supabase
    .from('users')
    .select('referral_points, can_access_beta')
    .eq('email', email)
    .single()

  if (fetchError || !user) {
    return NextResponse.json({ success: false, message: 'User tidak ditemukan.' }, { status: 404 })
  }

  let requiredPoints = 0
  const updateData: Partial<UserUpdate> = {}

  switch (reward) {
    case 'planner':
      requiredPoints = 3
      break
    case 'notion':
      requiredPoints = 7
      break
    case 'beta':
      requiredPoints = 10
      updateData.can_access_beta = true
      break
    default:
      return NextResponse.json({ success: false, message: 'Reward tidak valid.' }, { status: 400 })
  }

  if ((user.referral_points ?? 0) < requiredPoints) {
    return NextResponse.json({ success: false, message: 'Poin kamu belum cukup.' }, { status: 400 })
  }

  const newPoints = (user.referral_points ?? 0) - requiredPoints

  const { error: updateError } = await supabase
    .from('users')
    .update({ referral_points: newPoints, ...updateData })
    .eq('email', email)

  if (updateError) {
    return NextResponse.json({ success: false, message: 'Gagal unlock reward.' }, { status: 500 })
  }

  return NextResponse.json({
    success: true,
    message: `🎁 Reward "${reward}" berhasil di-unlock!`,
    remainingPoints: newPoints
  })
}
