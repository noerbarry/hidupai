import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { cookies } from 'next/headers'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET() {
  const cookieStore = await cookies() // ✅ PENTING: await di App Router
  const email = cookieStore.get('user-email')?.value

  if (!email) {
    return NextResponse.json({ success: false, friends: [], message: 'Email tidak ditemukan di cookies.' })
  }

  // ✅ Ambil data user yang sedang login
  const { data: userData, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !userData?.id) {
    return NextResponse.json({ success: false, friends: [], message: 'User tidak ditemukan atau ID kosong.' })
  }

  // ✅ Ambil semua teman yang mendaftar dengan referred_by = ID user
  const { data: referredFriends, error: referralError } = await supabase
    .from('users')
    .select('name, email, created_at, is_premium')
    .eq('referred_by', userData.id)

  if (referralError) {
    console.error('[Referral Friends Error]', referralError.message)
    return NextResponse.json({ success: false, friends: [], message: 'Gagal ambil data teman referral.' })
  }

  return NextResponse.json({ success: true, friends: referredFriends || [] })
}
