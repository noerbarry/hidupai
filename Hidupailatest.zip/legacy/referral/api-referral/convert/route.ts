import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST() {
  const supabase = createRouteHandlerClient({ cookies })

  const {
    data: { user },
    error
  } = await supabase.auth.getUser()

  if (error || !user?.email) {
    return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
  }

  const { data, error: fetchError } = await supabase
    .from('users')
    .select('referral_points')
    .eq('email', user.email)
    .maybeSingle()

  if (fetchError || !data) {
    return NextResponse.json({ success: false, message: 'User tidak ditemukan' }, { status: 404 })
  }

  if ((data.referral_points || 0) < 5) {
    return NextResponse.json({ success: false, message: 'Poin referral belum cukup untuk konversi' }, { status: 400 })
  }

  // Kurangi 5 poin dan aktifkan Premium Trial 7 hari
  const now = new Date()
  const premiumUntil = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)

  const { error: updateError } = await supabase
    .from('users')
    .update({
      referral_points: (data.referral_points || 0) - 5,
      plan_type: 'trial',
      premium_until: premiumUntil,
      just_upgraded: true
    })
    .eq('email', user.email)

  if (updateError) {
    return NextResponse.json({ success: false, message: 'Gagal upgrade akun' }, { status: 500 })
  }

  return NextResponse.json({
    success: true,
    message: '🎉 Selamat! Kamu berhasil tukarkan poin ke Premium 7 Hari'
  })
}
