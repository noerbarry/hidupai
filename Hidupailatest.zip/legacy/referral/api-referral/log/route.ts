import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { parse } from 'cookie'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  const rawCookie = req.headers.get('cookie') || ''
  const parsedCookie = parse(rawCookie)
  const email = parsedCookie['user-email']

  if (!email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()
  const { type, points } = body

  const { error } = await supabase.from('referral_rewards').insert({
    email,
    type,
    points,
  })

  if (error) {
    console.error('[❌ Referral Log Error]:', error.message)
    return NextResponse.json({ error: 'Gagal mencatat log reward' }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
