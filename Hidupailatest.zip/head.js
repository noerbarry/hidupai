export default function Head() {
    return (
      <>
        <title>HidupAI™ — Teman Sejiwa, Mentor Digital</title>
        <meta name="description" content="Asisten AI yang bantu kamu capai tujuan hidup, lebih fokus, dan berkembang setiap hari." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" type="image/x-icon" sizes="16x16" />
  
        {/* OG Meta Tags */}
        <meta property="og:title" content="HidupAI – Asisten AI Personal untuk Hidup Lebih Sadar" />
        <meta property="og:description" content="Bangun kebiasaan positif dan refleksi mingguan bersama HidupAI. Gratis & mudah!" />
        <meta property="og:image" content="https://www.hidupai.com/og-image.png" />
        <meta property="og:url" content="https://www.hidupai.com" />
        <meta property="og:type" content="website" />
  
        {/* Twitter Meta Tags */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="HidupAI – Asisten AI untuk Hidup Lebih Bermakna" />
        <meta name="twitter:description" content="Buat hidupmu lebih terarah bersama HidupAI. Refleksi. Habit. Progress. Satu tempat." />
        <meta name="twitter:image" content="https://www.hidupai.com/og-image.png" />
      </>
    );
  }
  