// File: /app/api/redeem-referral/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  const cookieStore = req.cookies
  const email = cookieStore.get('user-email')?.value

  if (!email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: user, error: fetchError } = await supabase
    .from('users')
    .select('referral_points')
    .eq('email', email)
    .single()

  if (fetchError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan.' }, { status: 404 })
  }

  if ((user.referral_points ?? 0) < 10) {
    return NextResponse.json({ error: 'Poin tidak cukup.' }, { status: 400 })
  }

  const { error: updateError } = await supabase
    .from('users')
    .update({
      is_premium: true,
      referral_points: user.referral_points - 10
    })
    .eq('email', email)

  if (updateError) {
    return NextResponse.json({ error: 'Gagal mengupdate data user.' }, { status: 500 })
  }

  const { error: logError } = await supabase
    .from('referral_rewards')
    .insert({
      email,
      type: 'redeem',
      points: -10
    })

  if (logError) {
    console.warn('⚠️ Gagal menyimpan log referral reward:', logError)
  }

  return NextResponse.json({ success: true, message: '🎉 Kamu berhasil upgrade ke Premium!' })
}
