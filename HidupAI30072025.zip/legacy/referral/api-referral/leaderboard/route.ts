import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET() {
  const { data, error } = await supabase
    .from('users')
    .select('name, referral_points, badge')
    .gt('referral_points', 0) // ✅ hanya user dengan poin > 0
    .order('referral_points', { ascending: false })
    .limit(10)

  if (error) {
    console.error('[Leaderboard Error]', error)
    return NextResponse.json({
      success: false,
      message: 'Gagal ambil data leaderboard',
    }, { status: 500 })
  }

  const sanitized = (data || []).map((user) => ({
    name: user.name || 'Anonim',
    referral_points: user.referral_points ?? 0,
    badge: user.badge || 'Newbie',
  }))

  return NextResponse.json({ success: true, leaderboard: sanitized })
}
