import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST() {
  const supabase = createRouteHandlerClient({ cookies })

  const {
    data: { user },
    error
  } = await supabase.auth.getUser()

  if (error || !user?.email) {
    return NextResponse.json({ success: false, points: 0 }, { status: 401 })
  }

  const { data, error: fetchError } = await supabase
    .from('users')
    .select('referral_points')
    .eq('email', user.email)
    .maybeSingle()

  if (fetchError) {
    return NextResponse.json({ success: false, points: 0 }, { status: 500 })
  }

  return NextResponse.json({ success: true, points: data?.referral_points || 0 })
}
