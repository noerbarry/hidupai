import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'

interface Simulation {
  id: number
  question: string
  goal: string
  duration: string
  result: string
  created_at: string
}

export default function LifeArenaHistoryCard({ email }: { email: string }) {
  const [simulations, setSimulations] = useState<Simulation[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!email) return

    const fetchHistory = async () => {
      const res = await fetch(`/api/life-arena/history?email=${email}`)
      const data = await res.json()
      setSimulations(data.simulations || [])
      setLoading(false)
    }

    fetchHistory()
  }, [email])

  if (loading) return <p className="text-sm text-gray-500">⏳ Memuat histori simulasi hidup...</p>

  return (
    <Card className="w-full mt-6">
      <CardContent className="space-y-4 p-4">
        <h2 className="text-lg font-bold">📜 Histori Simulasi Hidup</h2>
        {simulations.length === 0 ? (
          <p className="text-sm text-gray-500 italic">Belum ada simulasi tersimpan.</p>
        ) : (
          simulations.map((sim) => (
            <div key={sim.id} className="border rounded p-3 bg-gray-50">
              <p className="text-sm font-medium">📌 {sim.question}</p>
              <p className="text-xs text-gray-500">🎯 Tujuan: {sim.goal} | ⏳ {sim.duration}</p>
              <p className="text-xs text-gray-400">🕓 {new Date(sim.created_at).toLocaleString()}</p>
              <details className="mt-2">
                <summary className="text-sm text-blue-600 cursor-pointer">Lihat Hasil Simulasi</summary>
                <pre className="text-sm mt-2 whitespace-pre-line">{sim.result}</pre>
              </details>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  )
}
