'use client'

import { useChatStore } from '@/lib/store'
import { useEffect, useRef, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

export default function ChatBox() {
  const supabase = createClientComponentClient()

  const {
    messages,
    name,
    goal,
    mode,
    setMessages,
    appendMessage,
    setUserInfo,
    clearMessages
  } = useChatStore()

  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState('')
  const [isPremium, setIsPremium] = useState(false)
  const chatRef = useRef<HTMLDivElement>(null)

  // 🧠 Restore dari localStorage
  useEffect(() => {
    const saved = localStorage.getItem('hidupai-chat')
    if (saved) {
      const parsed = JSON.parse(saved)
      if (parsed.messages) setMessages(parsed.messages)
      if (parsed.name && parsed.goal) {
        setUserInfo(parsed.name, parsed.goal, parsed.mode || '')
      }
    }
  }, [setMessages, setUserInfo])

  // 🧠 Simpan ke localStorage
  useEffect(() => {
    localStorage.setItem(
      'hidupai-chat',
      JSON.stringify({ messages, name, goal, mode })
    )
  }, [messages, name, goal, mode])

  // 🧠 Auto-scroll
  useEffect(() => {
    chatRef.current?.scrollTo({
      top: chatRef.current.scrollHeight,
      behavior: 'smooth'
    })
  }, [messages, loading])

  // 🔐 Ambil session Supabase
  useEffect(() => {
    const fetchUser = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      const userEmail = session?.user?.email || ''
      setEmail(userEmail)

      const { data } = await supabase
        .from('users')
        .select('is_premium')
        .eq('email', userEmail)
        .single()

      setIsPremium(data?.is_premium || false)
    }

    fetchUser()
  }, [supabase])

  // 🧠 Deteksi mode otomatis
  const detectMode = (text: string) => {
    if (text.match(/capek|lelah|down|sedih/i)) return 'sedih'
    if (text.match(/bingung|mentok|buntu/i)) return 'mentok'
    if (text.match(/selesai|berhasil|goal/i)) return 'sukses'
    if (text.match(/pagi|semangat/i)) return 'pagi'
    return ''
  }

  // 🚀 Submit pesan ke Agentic API
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage = { role: 'user', content: input } as const
    const detected = detectMode(input)

    appendMessage(userMessage)
    setInput('')
    setLoading(true)

    const endpoint = isPremium ? '/api/agentic-chat' : '/api/chat'

    // 🧠 Thinking effect
    appendMessage({ role: 'assistant', content: '🤖 Sabar ya… HidupAI sedang memahami perasaanmu dulu...' })

    const res = await fetch(endpoint, {
      method: 'POST',
      body: JSON.stringify({
        messages: [...messages, userMessage],
        name,
        goal,
        email,
        mode: detected
      })
    })

    const data = await res.json()

    // ✅ FIX: Tidak pakai callback di setMessages
    const updatedMessages = messages
      .filter((msg) => !msg.content.includes('🤖 Sabar ya'))
      .concat({ role: 'assistant', content: data.message })

    setMessages(updatedMessages)
    setLoading(false)
  }

  return (
    <div className="max-w-xl mx-auto p-4">
      <div
        id="chat-scroll"
        ref={chatRef}
        className="bg-white rounded-xl border p-4 h-[400px] overflow-y-auto space-y-3 text-sm text-gray-800"
      >
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right' : 'text-left'}>
            <span className="inline-block px-3 py-2 rounded-lg bg-gray-100">
              {m.content}
            </span>
          </div>
        ))}
        {loading && (
          <div className="text-left text-gray-400 italic">
            ⏳ HidupAI sedang menanggapi kamu dengan hati-hati...
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Tulis pesan ke HidupAI™..."
          className="flex-1 border px-3 py-2 rounded-lg text-sm"
        />
        <button
          type="submit"
          className="bg-black text-white px-4 py-2 rounded-lg text-sm"
        >
          Kirim
        </button>
      </form>

      <button
        onClick={() => {
          clearMessages()
          localStorage.removeItem('hidupai-chat')
        }}
        className="mt-4 text-xs text-red-500 underline"
      >
        Reset obrolan
      </button>
    </div>
  )
}
