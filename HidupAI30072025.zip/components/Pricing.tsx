'use client'

import { Button } from '@/components/ui/button'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Cookies from 'js-cookie'
import Link from 'next/link'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { toastHidupAI } from '@/components/ui/custom-toast'

interface PricingPlan {
  title: string
  price: string
  tagline?: string
  features: string[]
  action: {
    label: string
    href?: string
    upgrade?: boolean
    highlight?: boolean
  }
}

const pricingPlans: PricingPlan[] = [
  {
    title: '🌱 Gratis',
    price: 'Rp0',
    tagline: 'Coba dulu tanpa komitmen. Kenali dirimu bersama HidupAI.',
    features: [
      '5 percakapan / hari',
      'Tanpa login kartu kredit',
      'Akses fitur dasar HidupAI'
    ],
    action: {
      label: 'Mulai Gratis',
      href: '/onboarding'
    }
  },
  {
    title: '🚀 Premium',
    price: 'Rp50.000 / bulan',
    tagline: 'Upgrade ke AI mentor pribadi yang hadir setiap hari.',
    features: [
      'Akses AI tanpa batas',
      'Memori personal & refleksi harian',
      'Respons super cepat (prioritas)',
      'Insight & refleksi mingguan',
      'Export PDF Ringkasan',
      'Tools eksklusif: Roadmap, Notion, Planner'
    ],
    action: {
      label: 'Upgrade Sekarang',
      upgrade: true,
      highlight: true
    }
  },
  {
    title: '🎯 Pro (Coming Soon)',
    price: 'Rp150.000',
    tagline: 'Untuk kamu yang ingin kustomisasi hidup lebih dalam.',
    features: [
      'Semua fitur Premium',
      'Kustomisasi tujuan & coaching AI',
      'Insight lanjutan & analisa kebiasaan',
      'Simulasi AI persona kamu sendiri'
    ],
    action: {
      label: 'Hubungi Kami',
      href: 'mailto:hidupaiapp@gmail.com'
    }
  }
]

export default function Pricing() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [upgradeError, setUpgradeError] = useState('')
  const [loading, setLoading] = useState(false)
  const supabase = createClientComponentClient()

  useEffect(() => {
    const init = async () => {
      let userEmail = Cookies.get('user-email')
      if (!userEmail) {
        const { data: { session } } = await supabase.auth.getSession()
        userEmail = session?.user?.email || ''
        if (userEmail) {
          Cookies.set('user-email', userEmail)
          setIsLoggedIn(true)
        }
      } else {
        setIsLoggedIn(true)
      }
      setEmail(userEmail || '')
    }
  
    // ✅ Preload Snap.js
    const script = document.createElement('script')
    script.src = 'https://app.midtrans.com/snap/snap.js'
    script.setAttribute('data-client-key', process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY!)
    script.async = true
    document.body.appendChild(script)
  
    init()
  }, [supabase])
  
  const handleUpgrade = async () => {
    if (loading) return
    setLoading(true)

    try {
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token
      const userEmail = session?.user?.email || email

      if (!token || !userEmail) {
        setUpgradeError('⚠️ Silakan login terlebih dahulu sebelum melakukan upgrade.')
        router.push('/login')
        return
      }

      const res = await fetch('/api/snap-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          email: userEmail,
          amount: 50000,
          plan_type: 'premium'
        })
      })

      const data = await res.json()

      if (typeof window !== 'undefined' && data.token) {
        window.snap.pay(data.token, {
          onSuccess: () => {
            toastHidupAI.success('🎉 Pembayaran sukses! Selamat bergabung dengan Premium.')
            router.push('/dashboard')
          },
          onPending: () => toastHidupAI.neutral('⌛ Menunggu pembayaran...'),
          onError: () => toastHidupAI.error('❌ Pembayaran gagal. Coba lagi ya.'),
          onClose: () => toastHidupAI.neutral('⚠️ Transaksi dibatalkan. Kamu bisa mencoba lagi kapan saja.')
        })
      } else {
        toastHidupAI.error(data.error || '❌ Gagal memproses pembayaran.')
      }
    } catch (err) {
      console.error('❌ Error saat proses upgrade:', err)
      toastHidupAI.error('Terjadi kesalahan internal.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10 space-y-10">
      <h1 className="text-3xl md:text-4xl font-bold text-center text-gray-800">
        💡 Pilih Rencana HidupAI yang Tepat untuk Kamu
      </h1>
      <p className="text-center text-sm text-gray-500 max-w-2xl mx-auto">
        Temukan teman digital yang selalu hadir untuk bantu kamu refleksi, bertumbuh, dan tetap konsisten setiap hari.
      </p>

      <div className="grid gap-6 md:grid-cols-3">
        {pricingPlans.map((plan, index) => (
          <div
            key={index}
            className={`rounded-2xl border p-6 shadow-md transition-all hover:shadow-xl hover:scale-[1.015] bg-white ${
              plan.action.highlight ? 'border-yellow-400 ring-2 ring-yellow-300' : 'border-gray-200'
            }`}
          >
            <h3 className="text-2xl font-bold text-gray-800 mb-1">{plan.title}</h3>
            <p className="text-sm text-gray-500 italic mb-3">{plan.tagline}</p>
            <p className="text-3xl font-extrabold text-gray-900 mb-4">{plan.price}</p>

            <ul className="space-y-2 text-sm text-gray-600">
              {plan.features.map((feat, i) => (
                <li key={i} className="flex items-start">
                  <span className="mr-2">✅</span> <span>{feat}</span>
                </li>
              ))}
            </ul>

            {plan.action.upgrade ? (
              isLoggedIn ? (
                <>
                  <Button
                    className="mt-6 w-full"
                    onClick={handleUpgrade}
                    disabled={loading}
                  >
                    {loading ? <span className="animate-pulse">⏳ Memproses...</span> : plan.action.label}
                  </Button>
                  {upgradeError && (
                    <p className="text-red-600 text-sm mt-2 text-center">{upgradeError}</p>
                  )}
                </>
              ) : (
                <>
                  <Link href="/login">
                    <Button className="mt-6 w-full" variant="outline">
                      Login untuk Upgrade
                    </Button>
                  </Link>
                  {upgradeError && (
                    <p className="text-red-600 text-sm mt-2 text-center">{upgradeError}</p>
                  )}
                </>
              )
            ) : plan.action.href?.startsWith('/') ? (
              <Link href={plan.action.href}>
                <Button className="mt-6 w-full" variant={plan.action.highlight ? 'default' : 'outline'}>
                  {plan.action.label}
                </Button>
              </Link>
            ) : (
              <a href={plan.action.href}>
                <Button className="mt-6 w-full" variant="outline">
                  {plan.action.label}
                </Button>
              </a>
            )}
          </div>
        ))}
      </div>

      <div className="text-center mt-10 space-y-1 text-sm text-gray-500">
        <Link href="/dashboard" className="underline hover:text-blue-600">← Kembali ke Chat</Link>
      </div>
    </div>
  )
}
