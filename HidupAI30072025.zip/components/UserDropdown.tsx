'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

export default function UserDropdown() {
  const [initial, setInitial] = useState('?')
  const router = useRouter()
  const supabase = createClientComponentClient()

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user }, error: userError } = await supabase.auth.getUser()
      if (userError || !user?.email) return

      const { data } = await supabase
        .from('users')
        .select('name')
        .eq('email', user.email)
        .single()

      if (data?.name) {
        setInitial(data.name.charAt(0).toUpperCase())
      }
    }

    fetchUser()
  }, [supabase])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    document.cookie = 'user-email=; Max-Age=0; path=/'
    router.replace('/login')
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <div
          className="w-9 h-9 rounded-full bg-indigo-600 text-white flex items-center justify-center cursor-pointer hover:opacity-90 transition"
          title="Profil"
        >
          {initial}
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-44">
        <DropdownMenuItem onClick={() => router.push('/profile')}>
          ✏️ Edit Profil
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleLogout}>
          🔓 Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
