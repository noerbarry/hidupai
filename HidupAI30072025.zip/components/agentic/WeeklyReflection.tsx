'use client'

import { useEffect, useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'

type Props = {
  email: string
}

export default function WeeklyReflection({ email }: Props) {
  const [reflection, setReflection] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchReflection = useCallback(async () => {
    setLoading(true)
    setError(null)

    try {
      const res = await fetch(`/api/weekly-reflection?email=${email}`)
      const text = await res.text()

      if (!res.ok) {
        throw new Error(text || 'Gagal memuat refleksi.')
      }

      setReflection(text || 'Belum ada refleksi sebelumnya.')
    } catch (err) {
      console.error('Gagal memuat refleksi:', err)
      setError('⚠️ Error saat memuat refleksi.')
    } finally {
      setLoading(false)
    }
  }, [email])

  const generateStreamingReflection = async () => {
    setLoading(true)
    setReflection('')
    setError(null)

    try {
      const res = await fetch('/api/agentic-chat/weekly-coaching', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })

      if (!res.ok || !res.body) {
        throw new Error('Streaming gagal dimulai.')
      }

      const reader = res.body.getReader()
      const decoder = new TextDecoder()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value, { stream: true })
        setReflection(prev => prev + chunk)
      }
    } catch (err) {
      console.error('Gagal stream refleksi:', err)
      setError('⚠️ Gagal memuat refleksi.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (email) fetchReflection()
  }, [email, fetchReflection])

  return (
    <div className="border p-4 rounded-lg bg-white shadow-sm mt-4">
      <h2 className="text-xl font-semibold text-purple-700 mb-2">🧭 Refleksi Mingguan</h2>

      {loading ? (
        <p className="text-gray-500 italic">
          🤖 HidupAI sedang memahami dan menyiapkan refleksi mingguan kamu...
        </p>
      ) : error ? (
        <p className="text-red-500">{error}</p>
      ) : (
        <p className="text-gray-800 whitespace-pre-wrap">{reflection}</p>
      )}

      <Button
        variant="secondary"
        onClick={generateStreamingReflection}
        className="mt-4"
        disabled={loading}
      >
        🔁 Ulangi Refleksi
      </Button>
    </div>
  )
}
