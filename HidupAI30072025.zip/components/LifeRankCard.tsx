'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'

interface LifeRankData {
  score: number
  rank: string
  habitDays: number
  usedChat: boolean
  hasGoal: boolean
  hasExported: boolean
  referralPoints: number
}

export default function LifeRankCard({ email, isPremium }: { email: string, isPremium: boolean }) {
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<LifeRankData | null>(null)

  useEffect(() => {
    fetch(`/api/liferank?email=${email}`)
      .then(res => res.json())
      .then(res => {
        if (res.success) setData(res)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [email])

  if (loading) {
    return <div className="text-sm text-gray-500">⏳ Memuat LifeRank kamu...</div>
  }

  if (!data) return null

  return (
    <div className="bg-yellow-50 text-yellow-800 text-sm p-4 rounded-xl shadow">
      🧭 <strong>LifeRank™ Kamu:</strong> <span className="font-medium">{data.rank}</span>

      {isPremium ? (
        <div className="mt-2 space-y-1 text-xs text-gray-700">
          <p>🎯 Skor: <strong>{data.score}/100</strong></p>
          <p>
            📆 Kebiasaan aktif:{' '}
            {data.habitDays > 0 ? (
              `${data.habitDays} hari`
            ) : (
              <span className="text-gray-500 italic">Belum ada kebiasaan tercatat</span>
            )}
          </p>
          <p>💬 Pakai AI Chat: {data.usedChat ? '✅ Ya' : '❌ Belum'}</p>
          <p>🎯 Goal Hidup: {data.hasGoal ? '✅ Ada' : '❌ Belum Diisi'}</p>
          <p>📤 Ekspor Insight: {data.hasExported ? '✅ Sudah' : '❌ Belum'}</p>
          <p>👥 Referral: {data.referralPoints} poin</p>
        </div>
      ) : (
        <>
          <p className="text-xs text-gray-500 mt-1">🔒 Detail skor hanya tersedia untuk pengguna Premium</p>
          <Button variant="outline" className="mt-2 text-xs">🚀 Upgrade untuk Lihat Detail</Button>
        </>
      )}
    </div>
  )
}
