'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { usePathname } from 'next/navigation'

export default function Navbar() {
  const pathname = usePathname()
  const supabase = createClientComponentClient()
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      setIsLoggedIn(!!session?.user)
    }
    checkSession()
  }, [supabase])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    location.reload()
  }

  if (pathname.startsWith('/login') || pathname.startsWith('/auth')) return null

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/">
          <Image src="/images/logo-hidupai.png" alt="HidupAI" width={120} height={120} className="w-28 h-auto" />
        </Link>

        <nav className="hidden md:flex gap-5 text-sm text-gray-700">
          <Link href="/" className="hover:text-blue-600">Beranda</Link>
          <Link href="/pricing" className="hover:text-blue-600">Harga</Link>
          <Link href="/about" className="hover:text-blue-600">Tentang</Link>
          <Link href="/faq" className="hover:text-blue-600">FAQ</Link>
          <Link href="/contact" className="hover:text-blue-600">Kontak</Link>
          <Link href="/terms-and-conditions" className="hover:text-blue-600">Term</Link>
          <Link href="/disclaimer" className="hover:text-blue-600">Disclaimer</Link>
        </nav>

        <button
          aria-label="Toggle menu"
          className="md:hidden text-gray-700 focus:outline-none"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          ☰
        </button>

        <div className="hidden md:flex items-center gap-2">
          {isLoggedIn ? (
            <>
              <Link href="/dashboard">
                <Button size="sm" variant="outline">🚀 Dashboard</Button>
              </Link>
              <Button size="sm" onClick={handleLogout}>Keluar</Button>
            </>
          ) : (
            <Link href="/login">
              <Button size="sm">✨ Masuk / Daftar</Button>
            </Link>
          )}
        </div>
      </div>

      {menuOpen && (
        <div className="md:hidden px-4 py-3 space-y-2 text-sm text-gray-700 bg-white border-t border-gray-200 shadow">
          <Link href="/" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>Beranda</Link>
          <Link href="/pricing" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>Harga</Link>
          <Link href="/about" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>Tentang</Link>
          <Link href="/faq" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>FAQ</Link>
          <Link href="/contact" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>Kontak</Link>
          <Link href="/terms-and-conditions" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>Term</Link>
          <Link href="/disclaimer" className="block hover:text-blue-600" onClick={() => setMenuOpen(false)}>Disclaimer</Link>

          {isLoggedIn ? (
            <>
              <Link href="/dashboard" onClick={() => setMenuOpen(false)}>
                <Button variant="outline" size="sm" className="w-full mt-2">🚀 Dashboard</Button>
              </Link>
              <Button variant="outline" size="sm" onClick={handleLogout} className="w-full">Keluar</Button>
            </>
          ) : (
            <Link href="/login">
              <Button variant="default" size="sm" className="w-full mt-2">✨ Masuk / Daftar</Button>
            </Link>
          )}
        </div>
      )}
    </header>
  )
}
