'use client'

import { useEffect, useState } from 'react'

interface HabitLog {
  date: string
  habit_name: string
  completed: boolean
}

type HabitGrouped = {
  [habitName: string]: HabitLog[]
}

export default function HabitSummary({ email }: { email: string }) {
  const [logs, setLogs] = useState<HabitLog[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchLogs = async () => {
      const res = await fetch(`/api/habit/summary?email=${email}`)
      const data = await res.json()
      setLogs(data.logs || [])
      setLoading(false)
    }
    fetchLogs()
  }, [email])

  const grouped = logs.reduce((acc: HabitGrouped, log) => {
    const name = log.habit_name
    if (!acc[name]) acc[name] = []
    acc[name].push(log)
    return acc
  }, {} as HabitGrouped)

  if (loading) return <p className="text-sm text-gray-400">⏳ Mengambil ringkasan kebiasaan...</p>
  if (logs.length === 0) return <p className="text-sm text-gray-400">Belum ada log kebiasaan tercatat minggu ini.</p>

  return (
    <div className="bg-white p-4 rounded-xl shadow space-y-3 text-sm text-gray-800">
      <h3 className="font-semibold text-base">📊 Ringkasan Kebiasaan Mingguan</h3>
      {Object.entries(grouped).map(([habit, entries]) => {
        const done = entries.filter((e) => e.completed).length
        return (
          <div key={habit} className="flex justify-between">
            <span>{habit}</span>
            <span>{done}/{entries.length} hari</span>
          </div>
        )
      })}
    </div>
  )
}
