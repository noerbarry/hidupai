// components/pdf/SummaryPDF.tsx
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  Font,
  Svg,
  Rect,
} from '@react-pdf/renderer'

// ✅ Register Inter font dari /public/fonts
Font.register({
  family: 'Inter',
  fonts: [
    { src: '/fonts/Inter-Regular.ttf', fontWeight: 'normal' },
    { src: '/fonts/Inter-Bold.ttf', fontWeight: 'bold' },
  ],
})

const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 12,
    fontFamily: 'Inter',
    backgroundColor: '#f8fafc',
    position: 'relative',
  },
  logo: {
    width: 50,
    height: 50,
    marginBottom: 10,
  },
  section: {
    marginBottom: 20,
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#ffffff',
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2563eb',
    marginBottom: 8,
  },
  subheading: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 6,
  },
  text: {
    fontSize: 12,
    marginBottom: 3,
    color: '#1f2937',
  },
  highlight: {
    fontWeight: 'bold',
    color: '#16a34a',
  },
  chartContainer: {
    marginTop: 12,
  },
  footer: {
    position: 'absolute',
    bottom: 20,
    left: 30,
    right: 30,
    textAlign: 'center',
    fontSize: 10,
    color: '#9ca3af',
  },
})

interface Props {
  name: string
  goal: string
  stats: { day: string; total: number }[]
}

const SummaryPDF = ({ name, goal, stats }: Props) => {
  const max = Math.max(...stats.map((s) => s.total), 4)
  const currentYear = new Date().getFullYear()

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Logo */}
        {/* eslint-disable-next-line jsx-a11y/alt-text */}
        <Image src="/images/logo-hidupai.png" style={styles.logo} />

        {/* Header */}
        <View style={styles.section}>
          <Text style={styles.heading}>Ringkasan Mingguan HidupAI</Text>
          <Text style={styles.text}>
            Nama: <Text style={styles.highlight}>{name}</Text>
          </Text>
          <Text style={styles.text}>
            Tujuan Hidup: <Text style={styles.highlight}>{goal}</Text>
          </Text>
        </View>

        {/* Progress Summary */}
        <View style={styles.section}>
          <Text style={styles.subheading}>Progress Kebiasaan</Text>
          {stats.map((item, idx) => (
            <Text key={idx} style={styles.text}>
              {item.day}: <Text style={styles.highlight}>{item.total} kebiasaan</Text>
            </Text>
          ))}

          {/* Bar Chart */}
          <View style={styles.chartContainer}>
            <Svg width="100%" height="80">
              {stats.map((item, index) => {
                const barHeight = (item.total / max) * 60
                return (
                  <Rect
                    key={index}
                    x={index * 45}
                    y={70 - barHeight}
                    width="20"
                    height={barHeight}
                    fill="#3b82f6"
                  />
                )
              })}
            </Svg>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 4,
              }}
            >
              {stats.map((item, index) => (
                <Text
                  key={`label-${index}`}
                  style={{ fontSize: 10, color: '#6b7280', width: 45 }}
                >
                  {item.day}
                </Text>
              ))}
            </View>
          </View>
        </View>

        {/* Insight */}
        <View style={styles.section}>
          <Text style={styles.subheading}>Insight</Text>
          <Text style={styles.text}>
            Kamu menunjukkan <Text style={styles.highlight}>konsistensi hebat</Text> minggu ini.
            Pertahankan semangat dan tetap fokus mencapai tujuan hidupmu.
          </Text>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text>HidupAI • hidupai.com © {currentYear} | Dibuat dengan cinta & kopi ☕</Text>
        </View>
      </Page>
    </Document>
  )
}

export default SummaryPDF
