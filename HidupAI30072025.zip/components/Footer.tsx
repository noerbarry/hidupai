import Link from 'next/link'
import Image from 'next/image'

export default function Footer() {
  return (
    <footer className="bg-white pt-1 pb-6 text-xs text-gray-400 text-center space-y-2 border-t border-gray-100">
      {/* Logo HidupAI */}
      <div>
        <Image
          src="/images/logo-hidupai.png"
          alt="Logo HidupAI"
          width={60}
          height={60}
          className="mx-auto"
        />
      </div>

      {/* Navigation Links */}
      <nav className="flex flex-wrap justify-center gap-4 text-sm text-gray-500 font-light tracking-tight">
        <Link href="/" className="hover:text-blue-600 transition-colors">Beranda</Link>
        <Link href="/pricing" className="hover:text-blue-600 transition-colors">Harga</Link>
        <Link href="/about" className="hover:text-blue-600 transition-colors">Tentang</Link>
        <Link href="/faq" className="hover:text-blue-600 transition-colors">FAQ</Link>
        <Link href="/contact" className="hover:text-blue-600 transition-colors">Contact</Link>
        <Link href="/terms-and-conditions" className="hover:text-blue-600 transition-colors">Term & Conditions</Link>
        <Link href="/disclaimer" className="hover:text-blue-600 transition-colors">Disclaimer</Link>
      </nav>

      {/* Footer Content */}
      <p>
        HidupAI™ — Powered by <strong className="text-gray-700">PABAR 🇮🇩</strong> | Dibangun dengan cinta & kopi ☕
      </p>
      <p>
        <Link href="/pricing" className="underline hover:text-blue-500">Lihat Premium</Link> ·{' '}
        <Link href="/privacy" className="underline hover:text-blue-500">Kebijakan Privasi</Link> ·{' '}
        <Link href="/about" className="underline hover:text-blue-500">Tentang</Link>
      </p>
    </footer>
  )
}
