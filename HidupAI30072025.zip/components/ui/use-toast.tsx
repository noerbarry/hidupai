'use client'

import { createContext, useContext, useState } from 'react'

type Toast = { id: number; title: string; description?: string }

const ToastContext = createContext<{
  toasts: Toast[]
  showToast: (toast: Omit<Toast, 'id'>) => void
}>({
  toasts: [],
  showToast: () => {},
})

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const showToast = (toast: Omit<Toast, 'id'>) => {
    const id = Date.now()
    setToasts((prev) => [...prev, { ...toast, id }])
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id))
    }, 3000)
  }

  return (
    <ToastContext.Provider value={{ toasts, showToast }}>
      {children}
      <div className="fixed bottom-4 right-4 space-y-2 z-50">
        {toasts.map((toast) => (
          <div key={toast.id} className="bg-black text-white px-4 py-2 rounded-lg shadow">
            <p className="font-bold">{toast.title}</p>
            {toast.description && <p className="text-sm">{toast.description}</p>}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export const useToast = () => useContext(ToastContext)
