'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { toast, Toast } from 'react-hot-toast'
import { CheckCircle, XCircle, Info } from 'lucide-react'

type ToastType = 'success' | 'error' | 'neutral'

export const toastHidupAI = {
  success: (message: string) => toast.custom((t) => <ToastBox t={t} type="success" message={message} />),
  error: (message: string) => toast.custom((t) => <ToastBox t={t} type="error" message={message} />),
  neutral: (message: string) => toast.custom((t) => <ToastBox t={t} type="neutral" message={message} />)
}

function ToastBox({
  t,
  type,
  message
}: {
  t: Toast
  type: ToastType
  message: string
}) {
  const Icon = type === 'success' ? CheckCircle : type === 'error' ? XCircle : Info
  const bg = {
    success: 'bg-green-100 border-green-300 text-green-800 dark:bg-green-900 dark:text-green-100',
    error: 'bg-red-100 border-red-300 text-red-800 dark:bg-red-900 dark:text-red-100',
    neutral: 'bg-gray-100 border-gray-300 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
  }

  return (
    <AnimatePresence>
      {t.visible && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          onClick={() => toast.dismiss(t.id)}
          className={`max-w-sm w-full border px-4 py-3 rounded-xl shadow-lg flex items-start gap-3 cursor-pointer ${bg[type]}`}
        >
          <Icon className="w-5 h-5 mt-0.5 shrink-0" />
          <p className="text-sm font-medium">{message}</p>
        </motion.div>
      )}
    </AnimatePresence>
  )
}