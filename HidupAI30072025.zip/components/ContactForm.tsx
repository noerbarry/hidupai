// components/ContactForm.tsx
'use client'

import { useState } from 'react'
import ReCAPTCHA from 'react-google-recaptcha'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'

export default function ContactForm() {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [captchaToken, setCaptchaToken] = useState<string | null>(null)
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('loading')

    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, message, captchaToken })
    })

    if (res.ok) {
      setStatus('success')
      setEmail('')
      setMessage('')
    } else {
      setStatus('error')
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-xl mx-auto space-y-6 p-6 bg-white dark:bg-slate-900 border rounded-xl shadow-md"
    >
      <h1 className="text-xl font-semibold text-blue-600 dark:text-blue-300 text-center">
        📬 Hubungi Tim HidupAI
      </h1>
      <p className="text-sm text-gray-600 dark:text-gray-300 text-center">
        Silakan kirimkan pertanyaan atau masukanmu melalui formulir ini.
      </p>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Email</label>
        <Input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Alamat email kamu"
          required
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Pesan</label>
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Tulis pesan atau pertanyaan kamu di sini"
          rows={4}
          required
        />
      </div>

      <ReCAPTCHA
        sitekey={process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY!}
        onChange={(token) => setCaptchaToken(token)}
      />

      <Button
        type="submit"
        className="w-full"
        disabled={!captchaToken || status === 'loading'}
      >
        {status === 'loading' ? 'Mengirim...' : 'Kirim Pesan'}
      </Button>

      {status === 'success' && (
        <p className="text-sm text-green-600 text-center">✅ Pesan berhasil dikirim!</p>
      )}
      {status === 'error' && (
        <p className="text-sm text-red-600 text-center">❌ Terjadi kesalahan. Silakan coba lagi.</p>
      )}
    </form>
  )
}