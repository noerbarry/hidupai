'use client'

import { useState } from 'react'

export default function PremiumModal({ plan }: { plan: string }) {
  const [show, setShow] = useState(true)

  if (!show) return null

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-xl shadow-xl max-w-md text-center animate-fade-in">
        <h2 className="text-xl font-bold text-green-700 mb-2">Selamat! 🎉</h2>
        <p className="text-sm mb-4">
          Kamu berhasil upgrade ke paket <strong>{plan}</strong>. Nikmati semua fitur premium sekarang!
        </p>
        <button
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition"
          onClick={() => setShow(false)}
        >
          Lanjutkan ke Chat
        </button>
      </div>
    </div>
  )
}
