declare module 'svg-captcha' {
  interface CaptchaOptions {
    size?: number
    noise?: number
    color?: boolean
    background?: string
    width?: number
    height?: number
    fontSize?: number
    ignoreChars?: string
    charPreset?: string
    fontPath?: string
  }

  interface Captcha {
    data: string
    text: string
  }

  export function create(options?: CaptchaOptions): Captcha
  export function createMathExpr(options?: CaptchaOptions): Captcha
  export const options: {
    fontPath?: string
  }

  export default {
    create,
    createMathExpr,
    options
  }
}

