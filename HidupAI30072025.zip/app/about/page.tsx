// File: app/about/page.tsx
'use client'

import Image from 'next/image'
import Link from 'next/link'

export default function AboutPage() {
  return (
      <main className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-amber-50 pb-16">
  
      {/* ✅ HEADER */}
      {/* 🧠 Konten Halaman About */}
      <main className="max-w-3xl mx-auto px-6 py-12 text-gray-800 space-y-10 pt-36">
        <section className="text-center mb-8">
          <div className="mb-4">
            <Image src="/images/logo-hidupai.png" alt="Logo HidupAI" width={100} height={100} className="mx-auto" />
          </div>
          <h1 className="text-3xl font-bold">Tentang HidupAI</h1>
          <p className="mt-3 text-gray-600 max-w-xl mx-auto">
            HidupAI adalah <strong>mentor pribadi berbasis AI</strong> yang dirancang untuk membantumu mengenali tujuan, mengelola emosi, dan membangun kebiasaan bermakna. Ini bukan sekadar chatbot — melainkan cermin digital yang tumbuh bersamamu.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">🎯 Visi</h2>
          <p className="text-gray-700">
            Menjadi <strong>AI mentor pribadi</strong> paling berdampak di Asia dan dunia — membantu manusia menjalani hidup lebih sadar, penuh makna, dan terarah.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">🌍 Misi</h2>
          <ul className="list-disc ml-6 text-gray-700 space-y-2">
            <li>💡 Membantu manusia hidup lebih sadar, produktif, dan bertumbuh.</li>
            <li>🤝 Menyediakan ruang aman untuk refleksi & konsistensi harian.</li>
            <li>🧠 Menghubungkan teknologi dengan keseharian, bukan sekadar hype.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">🔎 Apa yang Membuat HidupAI Berbeda?</h2>
          <ul className="list-disc ml-6 text-gray-700 space-y-2">
            <li>📅 AI yang hadir setiap hari untuk mendengarkan dan memahami tujuan hidupmu.</li>
            <li>📓 Fitur unik seperti Future Letter, Soul Journal, dan Growth Memory.</li>
            <li>💎 Pendekatan human-centered yang fokus pada emosi dan kesadaran, bukan sekadar produktivitas.</li>
          </ul>
        </section>

        <section className="text-center">
          <h2 className="text-xl font-semibold mb-4">Bagian dari Ekosistem PABAR</h2>
          <Image src="/images/pabar-ecosystem.jpg" alt="Ekosistem PABAR" width={800} height={400} className="rounded-xl shadow mx-auto" />
          <p className="text-sm text-gray-500 mt-4 max-w-2xl mx-auto">
            HidupAI merupakan bagian dari <strong>Ekosistem PABAR</strong> — inovasi AI buatan Indonesia:
            <br />
            <strong>PABAR.ID</strong> (edukasi AI), <strong>Pabar Studio</strong> (konten kreator AI), dan <strong>PABAR.AI</strong> (produk SaaS AI global).
          </p>
        </section>

        <section className="text-center space-y-2">
          <h2 className="text-xl font-semibold">Tim & Credits</h2>
          <p className="text-sm text-gray-600">
            HidupAI dibangun oleh kreator AI & tim teknologi di bawah bendera <strong>PABAR</strong>.
            Dengan semangat kolaborasi, cinta, dan kopi ☕ — kami percaya AI bisa membuat hidup lebih berarti.
          </p>
          <Link href="/" className="inline-block mt-4 text-sm text-blue-600 underline hover:text-blue-800">
            ← Kembali ke Beranda HidupAI
          </Link>
        </section>
      </main>
    </main>
  )
}
