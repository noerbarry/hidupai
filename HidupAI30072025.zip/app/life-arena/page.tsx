'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { motion } from 'framer-motion'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { useRouter } from 'next/navigation'

export default function LifeArenaPage() {
  const router = useRouter()
  const [decision, setDecision] = useState('')
  const [topic, setTopic] = useState('')
  const [values, setValues] = useState<string[]>([])
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  const allValues = ['Keluarga', 'Karier', 'Kesehatan', 'Finansial', 'Kebebasan', 'Spiritual']

  const toggleValue = (val: string) => {
    setValues(prev => prev.includes(val) ? prev.filter(v => v !== val) : [...prev, val])
  }

  const simulateDecision = async () => {
    if (!decision || !topic) return
    setLoading(true)

    const supabase = createClientComponentClient()
    const { data: { session } } = await supabase.auth.getSession()
    const token = session?.access_token

    if (!token) {
      setResult('❌ Gagal: Tidak ada token login.')
      setLoading(false)
      return
    }

    const res = await fetch('/api/life-arena', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ topic, decision, values })
    })

    const data = await res.json()
    setResult(data.result || data.error || '❌ Gagal memproses respon.')
    setLoading(false)
  }

  return (
    <main className="max-w-2xl mx-auto px-6 py-12 space-y-8">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-3xl font-bold text-center text-blue-800"
      >
        💭 Arena Refleksi Hidup
      </motion.h1>

      <p className="text-center text-gray-600 text-sm">
        Renungkan keputusan penting dalam hidupmu bersama <strong>HidupAI</strong> — bukan untuk mencari jawaban cepat, tapi untuk memahami lebih dalam secara reflektif.
      </p>

      <div className="space-y-4">
        <Input
          placeholder="Topik keputusan (misal: Pindah kerja)"
          value={topic}
          onChange={e => setTopic(e.target.value)}
        />
        <Textarea
          placeholder="Ceritakan keputusan yang sedang kamu pikirkan"
          value={decision}
          onChange={e => setDecision(e.target.value)}
        />

        <div className="text-sm text-gray-700 font-medium mt-4">Nilai hidup yang kamu pegang:</div>
        <div className="flex flex-wrap gap-2">
          {allValues.map(val => (
            <button
              key={val}
              onClick={() => toggleValue(val)}
              className={`px-3 py-1 rounded-full text-sm border transition ${
                values.includes(val)
                  ? 'bg-blue-600 text-white border-blue-700'
                  : 'border-gray-300 text-gray-600'
              }`}
            >
              {val}
            </button>
          ))}
        </div>

        <Button onClick={simulateDecision} disabled={loading} className="w-full mt-4">
          {loading ? 'HidupAI sedang merenung...' : 'Refleksikan Bersama HidupAI'}
        </Button>
      </div>

      {result && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white shadow border border-blue-100 p-4 rounded-xl mt-6 space-y-4"
        >
          <h2 className="text-lg font-semibold text-blue-700">🧠 Refleksi HidupAI</h2>
          <p className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">{result}</p>

          <div className="flex flex-col sm:flex-row gap-2 pt-4 justify-center">
            <Button variant="secondary" onClick={() => router.push('/life-arena/history')}>
              📜 Lihat Histori Refleksi
            </Button>
            <Button variant="outline" onClick={() => router.push('/dashboard')}>
              ← Kembali ke Dashboard
            </Button>
          </div>
        </motion.div>
      )}
    </main>
  )
}
