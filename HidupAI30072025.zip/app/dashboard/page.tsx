"use client"

import { useEffect, useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import Image from 'next/image'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { PDFDownloadLink } from '@react-pdf/renderer'
import SummaryPDF from '@/components/pdf/SummaryPDF'
import PlannerPDF from '@/components/pdf/PlannerPDF'
import LifeRankCard from '@/components/LifeRankCard'
import MemoryPanel from '@/components/agentic/MemoryPanel'
import AgenticSettings from '@/components/AgenticSettings'

interface HabitStat {
  day: string
  total: number
}

function WeeklyCoachingPanel({ email }: { email: string }) {
  const [coaching, setCoaching] = useState('')
  const [loading, setLoading] = useState(false)

  const fetchCoaching = useCallback(async () => {
    if (!email) return
    setLoading(true)
    setCoaching('')
    try {
      const res = await fetch('/api/agentic-chat/weekly-coaching', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      })

      if (!res.ok || !res.body) throw new Error('Gagal stream')

      const reader = res.body.getReader()
      const decoder = new TextDecoder()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value, { stream: true })
        setCoaching(prev => prev + chunk)
      }
    } catch (err) {
      console.error('Gagal mengambil refleksi mingguan:', err)
      setCoaching('⚠️ Error mengambil refleksi mingguan')
    } finally {
      setLoading(false)
    }
  }, [email])

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-indigo-600">🧭 Refleksi Mingguan</h2>
          <Button size="sm" onClick={fetchCoaching} disabled={loading}>
            {loading ? '⏳ Memuat...' : coaching ? '🔁 Ulangi' : '✨ Mulai'}
          </Button>
        </div>
        {loading ? (
          <p className="text-sm italic text-gray-500">🤖 HidupAI sedang menyiapkan refleksi mingguan kamu...</p>
        ) : coaching ? (
          <p className="text-sm text-gray-800 whitespace-pre-line">{coaching}</p>
        ) : (
          <p className="text-sm text-gray-500 italic">Klik tombol mulai untuk refleksi mingguan.</p>
        )}
      </CardContent>
    </Card>
  )
}

export default function Dashboard() {
  const router = useRouter()
  const supabase = createClientComponentClient()

  const [loading, setLoading] = useState(true)
  const [name, setName] = useState('')
  const [goal, setGoal] = useState('')
  const [email, setEmail] = useState('')
  const [isPremium, setIsPremium] = useState(false)
  const [badge, setBadge] = useState('Newbie')
  const [usageToday, setUsageToday] = useState(0)
  const [lastQuestion, setLastQuestion] = useState('')
  const [lastResponse, setLastResponse] = useState('')
  const [habitStats, setHabitStats] = useState<HabitStat[]>([])
  const [habitInsight, setHabitInsight] = useState('')
  const [trendEmoji, setTrendEmoji] = useState('')
  const [plannerText, setPlannerText] = useState('')
  const [plannerLoading, setPlannerLoading] = useState(false)
  const [plannerCached, setPlannerCached] = useState(false)
  const [preferredMode, setPreferredMode] = useState('')
  const [weeklyGoal, setWeeklyGoal] = useState('')

  useEffect(() => {
    const fetchAll = async () => {
      const { data: { session }, error } = await supabase.auth.getSession()
      const token = session?.access_token

      if (!session?.user?.email || error || !token) {
        router.push('/login')
        return
      }

      const email = session.user.email
      setEmail(email)

      fetch('/api/agentic-preferences?email=' + email)
      .then(async res => {
        if (!res.ok) {
          const text = await res.text()
          throw new Error(`Gagal fetch preferences: ${text}`)
        }
        return res.json()
      })
      .then(data => {
        setPreferredMode(data.mode || '')
        setWeeklyGoal(data.goal || '')
      })
      .catch(err => console.error('Agentic preferences fetch error:', err))
      
      const res = await fetch('/api/check-user', {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (!res.ok) {
        router.push('/register')
        return
      }

      const data = await res.json()
      setName(data.name)
      setGoal(data.goal)
      setIsPremium(data.is_premium)
      setBadge(data.badge || 'Newbie')
      setLastQuestion(data.last_question || '')
      setLastResponse(data.last_response || '')

      fetch('/api/usage', {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(res => res.json())
        .then(res => setUsageToday(res.usage_today || 0))
        .catch(err => console.error('Usage fetch error:', err))

      fetch('/api/habit/stats?email=' + email, {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(res => res.json())
        .then(res => {
          setHabitStats(res.stats || [])
          setHabitInsight(res.insight || '')
          if (res.insight?.includes('meningkat')) setTrendEmoji('📈')
          else if (res.insight?.includes('menurun')) setTrendEmoji('📉')
          else setTrendEmoji('➖')
        })
        .catch(err => console.error('Habit stats error:', err))

      setLoading(false)
    }

    fetchAll()
  }, [router, supabase])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    document.cookie = 'sb-access-token=; Max-Age=0; path=/;'
    document.cookie = 'sb-refresh-token=; Max-Age=0; path=/;'
    router.push('/login')
  }

  const generatePlanner = async () => {
    if (!email) return
    setPlannerLoading(true)
    const res = await fetch('/api/ai/weekly-planner', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    })
    const data = await res.json()
    setPlannerText(data.planner || 'Gagal memuat planner.')
    setPlannerCached(data.cached || false)
    setPlannerLoading(false)
  }

  const pushToNotion = async () => {
    if (!plannerText || !email) return
    const res = await fetch('/api/notion/push-planner', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ planner: plannerText })
    })
    const data = await res.json()
    alert(data.success ? '✅ Planner berhasil dikirim ke Notion!' : '❌ Gagal kirim ke Notion.')
  }

  if (loading) {
    return (
      <main className="h-screen flex items-center justify-center text-sm text-gray-500">
        ⏳ Memuat dashboard kamu...
      </main>
    )
  }

  return (
    <main className="max-w-2xl mx-auto px-4 pt-[96px] sm:pt-[112px] md:pt-[128px] pb-10 space-y-6">  
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold mt-2">👤 Halo, {name}!</h1>
          <p className="text-gray-600 text-sm">
            Tujuanmu: <span className="italic">{goal}</span>
          </p>
        </div>
        <div className="flex flex-col items-end gap-2 mt-2">
          <Image src="/images/logo-hidupai.png" alt="Logo HidupAI" width={80} height={80} />
          <div className="flex flex-wrap justify-end gap-2">
            <Button variant="ghost" className="text-xs text-blue-600 underline p-0 h-auto" onClick={() => router.push('/profile')}>
              🛠️ Edit Profil
            </Button>
            <Button variant="ghost" className="text-xs text-blue-600 underline p-0 h-auto" onClick={() => router.push('/history')}>
              💳 Riwayat Pembayaran
            </Button>
          </div>
        </div>
      </div>

      {/* Life Rank */}
      <LifeRankCard email={email} isPremium={isPremium} />

      {/* ✅ Memory Panel Agentic */}
      <MemoryPanel email={email} />

      {/* ✅ Pengaturan Agentic AI */}
      <AgenticSettings email={email} mode={preferredMode} goal={weeklyGoal} />
      {/* ✅ Refleksi Mingguan oleh Agentic AI */}
    {isPremium && <WeeklyCoachingPanel email={email} />}

      {/* Life Arena Pro */}
      {isPremium && (
        <Card>
          <CardContent className="p-4 space-y-3">
            <h2 className="text-sm font-bold text-indigo-600">🔮 Life Arena Pro</h2>
            <p className="text-sm text-gray-700">Simulasikan keputusan hidup besar kamu bersama AI yang memahami tujuan dan emosimu.</p>
            <Button onClick={() => router.push('/life-arena')} className="w-full">
              Jelajahi Life Arena
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Email</p><p className="font-medium">{email}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Status</p><p className={`font-medium ${isPremium ? 'text-green-600' : 'text-red-600'}`}>{isPremium ? 'Premium 🚀' : 'Gratis ❌'}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Badge</p><p className="font-medium text-indigo-600">{badge}</p></CardContent></Card>
        <Card className="md:col-span-2">
          <CardContent className="p-4 space-y-3">
            <p className="text-xs text-gray-500">Penggunaan Chat Hari Ini</p>
            <Progress value={(usageToday / 5) * 100} />
            <p className="text-sm text-gray-600">{usageToday}/5 chat gratis</p>
          </CardContent>
        </Card>
      </div>

      {/* Last Chat History */}
      {lastQuestion && lastResponse && (
        <Card>
          <CardContent className="p-4 space-y-2">
            <p className="text-sm font-semibold">✅ History Chat Mingguan</p>
            <p className="text-xs text-gray-500 italic">Terakhir kamu tanya:</p>
            <p className="text-sm">“{lastQuestion}”</p>
            <p className="text-xs text-gray-500 italic">Jawaban HidupAI:</p>
            <p className="text-sm">{lastResponse}</p>
          </CardContent>
        </Card>
      )}

      {/* Premium Tools */}
      {isPremium && (
        <>
          {/* Habit Progress */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <p className="text-sm font-semibold">
                📊 Progress Kebiasaan Mingguan {trendEmoji && <span>{trendEmoji}</span>}
              </p>
              {habitStats.length === 0 ? (
                <p className="text-sm text-gray-500 italic">Belum ada data kebiasaan.</p>
              ) : (
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={habitStats}>
                    <XAxis dataKey="day" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="total" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Insight */}
          <Card>
            <CardContent className="p-4 space-y-2">
              <p className="text-sm font-semibold">🧠 Insight Mingguan</p>
              <p className="text-sm text-gray-700">{habitInsight}</p>
            </CardContent>
          </Card>

          {/* PDF Summary */}
          <Card>
            <CardContent className="p-4 space-y-2">
              <p className="text-sm font-semibold">📥 Export Ringkasan Mingguan</p>
              <PDFDownloadLink
                document={<SummaryPDF name={name} goal={goal} stats={habitStats} />}
                fileName="hidupai-ringkasan.pdf"
              >
                {({ loading }) => (
                  <Button>{loading ? 'Menyiapkan PDF...' : '📄 Unduh PDF Ringkasan'}</Button>
                )}
              </PDFDownloadLink>
            </CardContent>
          </Card>

          {/* Planner Section */}
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex justify-between items-center">
                <p className="text-sm font-semibold">🎯 AI Weekly Habit Planner</p>
                <Button size="sm" onClick={generatePlanner} disabled={plannerLoading}>
                  {plannerLoading ? '⏳ Memuat...' : 'Generate'}
                </Button>
              </div>

              {plannerText && (
                <>
                  <pre className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-zinc-800 border border-gray-200 bg-gray-50 p-4 rounded">
                    {plannerText}
                  </pre>

                  {plannerCached && (
                    <p className="text-xs text-right italic text-gray-500 mt-2">
                      📌 Diambil dari cache minggu ini
                    </p>
                  )}

                  <div className="flex justify-end gap-3 mt-3">
                    <PDFDownloadLink
                      document={<PlannerPDF name={name} planner={plannerText} />}
                      fileName="hidupai-weekly-planner.pdf"
                    >
                      {({ loading }) => (
                        <Button variant="outline" size="sm">
                          {loading ? '⏳ PDF...' : '📄 Download PDF'}
                        </Button>
                      )}
                    </PDFDownloadLink>
                    <Button variant="secondary" size="sm" onClick={pushToNotion}>
                      📤 Kirim ke Notion
                    </Button>
                  </div>

                  <div className="text-right mt-2">
                    <a
                      href="https://www.notion.so/Weekly-Planner-AI-1e76cb5980ac800090eed29bdfeb53b1"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-blue-600 underline"
                    >
                      🔗 Lihat Planner di Notion
                    </a>
                  </div>
                </>
              )}
            </CardContent>
          </Card>  
        </>
      )}

      {/* Actions */}
      <div className="flex flex-col md:flex-row gap-3 justify-center">
        <Button onClick={() => router.push('/onboarding')}>💬 Lanjut Ngobrol Bareng HidupAI</Button>
        {!isPremium && (
          <Button variant="outline" onClick={() => router.push('/pricing')}>
            🚀 Upgrade ke Premium
          </Button>
        )}
        <Button variant="destructive" className="text-sm" onClick={handleLogout}>
          🔓 Keluar dari Akun
        </Button>
      </div>
    </main>
  )
}
