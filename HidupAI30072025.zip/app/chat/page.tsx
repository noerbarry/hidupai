'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import ChatBox from '@/components/ChatBox'
import UpgradeCTA from '@/components/UpgradeCTA'
import PremiumModal from '@/components/PremiumModal'

interface UserData {
  plan_type: 'premium' | 'trial' | 'pro' | 'free'
  premium_until: string | null
  just_upgraded: boolean
}

export default function ChatPage() {
  const supabase = createClientComponentClient()
  const [user, setUser] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      const email = session?.user?.email
      if (!email) {
        setLoading(false)
        return
      }

      const { data, error } = await supabase
        .from('users')
        .select('plan_type, premium_until, just_upgraded')
        .eq('email', email)
        .single()

      if (error || !data) {
        console.error('Gagal mengambil data user:', error)
        setLoading(false)
        return
      }

      setUser(data)

      if (data.just_upgraded) {
        setShowModal(true)
        await supabase
          .from('users')
          .update({ just_upgraded: false })
          .eq('email', email)
      }

      setLoading(false)
    }

    fetchUser()
  }, [supabase])

  if (loading) {
    return (
      <div className="text-center mt-8 text-sm text-gray-500">
        ⏳ Memuat data pengguna...
      </div>
    )
  }

  const now = new Date()
  const isExpired =
    user?.premium_until && new Date(user.premium_until) < now

  const isAllowed =
    user?.plan_type === 'premium' ||
    (user?.plan_type === 'trial' && !isExpired) ||
    (user?.plan_type === 'pro' && !isExpired)

  return (
    <>
      {showModal && user && <PremiumModal plan={user.plan_type} />}

      {isAllowed ? (
        <ChatBox />
      ) : (
        <div className="max-w-md mx-auto mt-10">
          <UpgradeCTA plan={user?.plan_type || 'free'} />
        </div>
      )}
    </>
  )
}
