'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'

const carouselSlides = [
  { src: '/images/HidupAILifeCoach.png', alt: 'HidupAI Life Coach Slide' },
  { src: '/images/HidupAIMotivation.jpeg', alt: 'HidupAI Motivation Slide' },
  { src: '/images/HidupAImengertikamu.png', alt: 'HidupAI Mengerti Kamu' },
  { src: '/images/FiturReflektif HidupAI.png', alt: 'Fitur Reflektif HidupAI' }
]

export default function HomePage() {
  const [index, setIndex] = useState(0)
  const [checking, setChecking] = useState(true)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const supabase = createClientComponentClient()

  const handleNext = () => setIndex((prev) => (prev + 1) % carouselSlides.length)
  const handlePrev = () => setIndex((prev) => (prev - 1 + carouselSlides.length) % carouselSlides.length)

  const handleLogout = async () => {
    await supabase.auth.signOut()
    location.reload()
  }

  useEffect(() => {
    const checkLogin = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      setIsLoggedIn(!!session?.user?.email)
      setChecking(false)
    }
    checkLogin()
  }, [supabase])

  if (checking) {
    return (
      <main className="min-h-screen flex items-center justify-center text-sm text-gray-500">
        ⏳ Memuat...
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-gray-800 pt-24 pb-16">
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-3 flex flex-wrap md:flex-nowrap items-center justify-between gap-3">
          <Link href="/">
            <Image src="/images/logo-hidupai.png" alt="HidupAI" width={120} height={120} />
          </Link>
          <div className="hidden md:flex gap-6 text-sm text-gray-700">
            <a href="#fitur" className="hover:text-blue-600">Beranda</a>
            <Link href="/pricing" className="hover:text-blue-600">Harga</Link>
            <Link href="/about" className="hover:text-blue-600">Tentang</Link>
            <a href="#komunitas" className="hover:text-blue-600">Komunitas</a>
            <Link href="/faq" className="hover:text-blue-600">FAQ</Link>
            <Link href="/contact" className="hover:text-blue-600">Contact</Link>
            <Link href="/terms-and-conditions" className="hover:text-blue-600">Term & Conditions</Link>
            <Link href="/disclaimer" className="hover:text-blue-600">Disclaimer</Link>
          </div>
          {isLoggedIn ? (
            <Button className="text-sm" onClick={handleLogout}>🔓 Keluar</Button>
          ) : (
            <Link href="/login" className="ml-auto md:ml-0">
              <Button className="text-sm">✨ Masuk / Daftar</Button>
            </Link>
          )}
        </div>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full flex justify-center bg-yellow-50 border-t border-b border-yellow-300 py-2">
          <div className="text-yellow-800 text-sm px-4 font-medium">
            🌟 HidupAI telah resmi dirilis! Coba gratis hari ini — dan unlock fitur <strong className="text-blue-700 font-semibold">Premium</strong> untuk refleksi yang lebih dalam dan hasil yang bermakna.
          </div>
        </motion.div>
      </header>

      <div className="max-w-5xl mx-auto px-6 pt-40 text-center space-y-16">
        <section className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold leading-snug">
            Bayangkan Kalau <span className="text-blue-600">AI Bisa Bertumbuh</span> Bersamamu
          </h1>
          <p className="text-gray-600 max-w-xl mx-auto text-base">
            HidupAI bukan sekadar chatbot. Ini cermin hidup digital yang memahami tujuan dan emosimu. Ciptakan jejak hidupmu bersama AI yang berevolusi.
          </p>
          <div className="mt-6">
          <iframe
            width="100%"
            height="360"
            className="rounded-xl mx-auto shadow-md border"
            src="https://www.youtube.com/embed/videoseries?list=PLe2y23JJatjEbMMEFXo1P557rEayrYVlF"
            title="Playlist NARA - HidupAI"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-4">
            <Link href="/login">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white text-sm px-6 py-3 rounded-xl shadow-md transition">
                ✨ Coba Gratis Sekarang
              </Button>
            </Link>
            <Link href="/pricing"> 
              <Button variant="outline" className="text-sm px-6 py-3 border-blue-600 text-blue-600 rounded-xl hover:bg-blue-100 transition">
                💎 Lihat Harga Premium
              </Button>
            </Link>
          </div>
        </section>
        <section id="fitur" className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {[{ icon: '🌈', title: 'Life Arena', desc: 'Simulasi keputusan hidup bersama AI' }, { icon: '✉️', title: 'Future Letter', desc: 'Kirim surat untuk diri masa depan' }, { icon: '🧘', title: 'Soul Journal', desc: 'Refleksi niat pagi & malam' }, { icon: '📊', title: 'Growth Memory', desc: 'Grafik perkembangan pribadi' }, { icon: '🏆', title: 'Life Rank', desc: 'Badge perjalanan kesadaran' }, { icon: '🎯', title: 'Intention Engine', desc: 'AI yang paham tujuanmu' }].map(({ icon, title, desc }, i) => (
            <div key={i} className="bg-white shadow border border-blue-100 rounded-xl p-4 text-sm hover:scale-[1.02] transition">
              <p>{icon} <strong>{title}</strong></p>
              <p className="text-xs text-gray-500">{desc}</p>
            </div>
          ))}
        </section>

        <section className="mt-10">
          <h2 className="text-lg font-semibold text-blue-600 mb-2">🧠 Apa yang Membuat HidupAI Berbeda?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 text-left text-sm">
            <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
              <h3 className="font-semibold">AI Generik Umum</h3>
              <ul className="list-disc list-inside text-gray-600 mt-2 space-y-1">
                <li>Jawaban cepat & akurat</li>
                <li>Fokus pada produktivitas & efisiensi teknis</li>
                <li>Tidak menyimpan jejak emosional atau riwayat personal</li>
              </ul>
            </div>
            <div className="bg-blue-50 p-4 rounded-xl border border-blue-200 shadow">
              <h3 className="font-semibold text-blue-800">✅ HidupAI</h3>
              <ul className="list-disc list-inside text-blue-700 mt-2 space-y-1">
                <li>Memahami tujuan, nilai, dan perasaanmu setiap hari</li>
                <li>Fitur refleksi, surat masa depan, dan pelacakan pertumbuhan</li>
                <li>AI reflektif yang berevolusi bersama perjalanan hidupmu</li>
              </ul>
            </div>
          </div>
        </section>

        <section id="komunitas" className="mt-20">
          <h2 className="text-lg font-semibold text-blue-600">🌱 Gabung Komunitas Generasi AI Baru</h2>
          <p className="text-gray-600 max-w-xl mx-auto text-sm mt-1">
            HidupAI bukan hanya tools, tapi ruang tumbuh bersama. Diskusi reflektif, fitur eksklusif, dan teman seperjalananmu yang mengerti.
          </p>
          <Link href="#" target="_blank">
            <Button className="mt-4 bg-blue-600 text-white hover:bg-blue-700 text-sm">💬 Join Waitlist Komunitas</Button>
          </Link>
        </section>

        <section className="mt-20">
          <Image
            src="/images/visual-hidupai-productivity.jpeg"
            alt="Visual HidupAI Productivity"
            width={900}
            height={800}
            className="rounded-xl shadow-md border mx-auto"
          />
        </section>

        <section className="mt-20">
          <h2 className="text-xl font-semibold text-blue-700 mb-4">
            🔍 Jejak Nyata HidupAI: Dari Motivasi hingga Transformasi Personal
          </h2>
          <div className="relative w-full max-w-3xl mx-auto overflow-hidden rounded-xl shadow border">
            <AnimatePresence mode="wait">
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.4 }}
              >
                <Image
                  src={carouselSlides[index].src}
                  alt={carouselSlides[index].alt}
                  width={900}
                  height={600}
                  className="w-full object-cover rounded-xl"
                />
              </motion.div>
            </AnimatePresence>
            <div className="absolute inset-0 flex justify-between items-center px-4">
              <button onClick={handlePrev} className="text-blue-700 text-2xl font-bold bg-white/80 px-2 rounded-full shadow">‹</button>
              <button onClick={handleNext} className="text-blue-700 text-2xl font-bold bg-white/80 px-2 rounded-full shadow">›</button>
            </div>
          </div>
          <div className="mt-6">
            <Link href="/login">
              <Button className="bg-blue-600 text-white text-sm px-6 py-3 rounded-xl shadow-md w-full sm:w-auto"> 
                ✨ Coba Sekarang dan Temukan Versi Terbaik Dirimu
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </main>
  )
}