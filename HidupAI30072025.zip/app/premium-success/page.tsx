export default function PremiumSuccess() {
    return (
      <main className="min-h-screen flex items-center justify-center text-center p-8">
        <div>
          <h1 className="text-2xl font-bold text-green-600">🎉 Pembayaran Berhasil!</h1>
          <p className="text-gray-600 mt-2">Akun kamu sekarang sudah Premium. Yuk lanjut eksplorasi tujuan hidupmu bersama HidupAI 🚀</p>
        </div>
      </main>
    )
  }
  