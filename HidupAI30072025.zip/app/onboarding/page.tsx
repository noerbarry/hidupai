'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import LifeRankCard from '@/components/LifeRankCard'
import Image from 'next/image'

interface Message {
  role: 'user' | 'assistant'
  content: string
}

declare global {
  interface Window {
    snap: {
      pay: (
        token: string,
        options: {
          onSuccess?: () => void
          onPending?: () => void
          onError?: () => void
          onClose?: () => void
        }
      ) => void
    }
  }
}

const FEATURE_REFERRAL = process.env.NEXT_PUBLIC_FEATURE_REFERRAL === 'true'

export default function HomePage() {
  const router = useRouter()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [name, setName] = useState('')
  const [goal, setGoal] = useState('')
  const [email, setEmail] = useState('')
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [isPremium, setIsPremium] = useState(false)
  const [habitInput, setHabitInput] = useState('')
  const [habitMessage, setHabitMessage] = useState('')
  const [usageToday, setUsageToday] = useState(0)
  const [upgrading, setUpgrading] = useState(false)
  const thinkingMessages = [
    "🤖 Sabar ya… HidupAI sedang memahami perasaanmu terlebih dahulu...",
    "🧠 Memberi waktu sejenak untuk merenung...",
    "✨ HidupAI sedang mencari makna yang tepat buatmu...",
    "📖 Sedang membuka catatan hidupmu sebelumnya..."
  ]
  const randomMessage = useRef(thinkingMessages[Math.floor(Math.random() * thinkingMessages.length)])  

  useEffect(() => {
    const checkSession = async () => {
      const supabase = createClientComponentClient()
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token
      if (!token) return router.push('/login')
  
      const res = await fetch('/api/check-user', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` }
      })
  
      const data = await res.json()
      if (!res.ok || data.error) return router.push('/register')
  
      setEmail(data.email)
      setName(data.name)
      setGoal(data.goal)
      setIsPremium(data.is_premium)
  
      // ✅ Simpan goal ke memory jika belum ada
      if (data.goal && !data.weekly_goal) {
        await fetch('/api/memory/update-settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: data.email, goal: data.goal })
        })
      }
  
      if (data.last_question && data.last_response) {
        setMessages([
          { role: 'user', content: data.last_question },
          { role: 'assistant', content: data.last_response }
        ])
      }
    }
  
    checkSession()
  }, [router])
  

  useEffect(() => {
    const fetchUsage = async () => {
      const supabase = createClientComponentClient()
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token
      if (!token) return

      const res = await fetch('/api/usage', {
        headers: { Authorization: `Bearer ${token}` }
      })

      const data = await res.json()
      if (res.ok && data.success) {
        setUsageToday(data.usage_today || 0)
      }
    }

    if (email && !isPremium) fetchUsage()
  }, [email, isPremium])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSend = async () => {
    if (!input.trim()) return
    if (!isPremium && usageToday >= 5) return

    const userMsg: Message = { role: 'user', content: input }
    const updatedMessages = [...messages, userMsg]
    setMessages(updatedMessages)
    setInput('')
    setLoading(true)

    const supabase = createClientComponentClient()
    const { data: { session } } = await supabase.auth.getSession()
    const token = session?.access_token

    if (!token) return router.push('/login')

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ messages: updatedMessages, name, goal, email })
    })

    const data = await res.json()
    const botMsg: Message = { role: 'assistant', content: data.message }

    setMessages([...updatedMessages, botMsg])
    setUsageToday(prev => prev + 1)
    setLoading(false)
  }

  const handleHabitLog = async () => {
    if (!habitInput.trim()) return

    const res = await fetch('/api/habit/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, habit_name: habitInput.trim(), completed: true })
    })

    const data = await res.json()
    if (data.success) {
      setHabitMessage(`✅ "${habitInput}" berhasil dicatat!`)
      setHabitInput('')
      setTimeout(() => setHabitMessage(''), 3000)
    }
  }

  const handleUpgrade = async (amount: number) => {
    setUpgrading(true)
    const supabase = createClientComponentClient()
    const { data: { session } } = await supabase.auth.getSession()
    const token = session?.access_token

    const res = await fetch('/api/snap-token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ email, amount, plan_type: amount === 15000 ? 'trial' : 'pro' })
    })

    const data = await res.json()
    setUpgrading(false) //
    if (data.token && typeof window !== 'undefined' && window.snap?.pay) {
      window.snap.pay(data.token, {
        onSuccess: () => {
          alert('✅ Pembayaran berhasil!')
          window.location.reload()
        },
        onPending: () => alert('⏳ Menunggu konfirmasi...'),
        onError: () => alert('❌ Pembayaran gagal.'),
        onClose: () => alert('❌ Transaksi dibatalkan.')
      })
    } else {
      alert('⚠️ Gagal memuat Midtrans Snap. Coba refresh halaman.')
    }
  }

  const handleLogout = () => {
    const supabase = createClientComponentClient()
    supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <main className="max-w-md mx-auto px-4 pt-[96px] pb-10 space-y-6">

      <div className="bg-white shadow p-4 rounded-xl space-y-2">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-lg font-semibold">Hai, {name} 👋</h2>
            <p className="text-sm text-gray-500">Tujuanmu: {goal}</p>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <a href="/dashboard" className="text-blue-600 underline">📊 Dashboard</a>
            <button onClick={handleLogout} className="text-red-600">Logout</button>
          </div>
        </div>
        {isPremium && (
          <p className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full inline-block">Premium 🚀</p>
        )}
      </div>

      {isPremium && FEATURE_REFERRAL && (
        <LifeRankCard email={email} isPremium={isPremium} />
      )}

      {isPremium && (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-xl text-sm space-y-2">
          <h3 className="font-semibold">🔮 Sudah coba <a href="/life-arena" className="underline text-blue-600">Life Arena Pro</a>?</h3>
          <p>Simulasikan keputusan besar hidupmu dengan AI reflektif yang memahami tujuan dan emosi kamu.</p>
          <a href="/life-arena" className="inline-block bg-blue-600 text-white px-4 py-1.5 rounded-lg text-xs font-semibold hover:bg-blue-700">Jelajahi Life Arena</a>
        </div>
      )}

      <div className="space-y-2 max-h-[400px] overflow-y-auto">
        {messages.length === 0 && !loading && (
          <div className="text-center text-sm text-gray-400 py-12">
            🌱 <span className="font-medium text-gray-500">Mulai cerita hidupmu hari ini</span>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} text-sm`}>
            <div className={`max-w-[80%] px-4 py-3 my-1 rounded-2xl shadow ${
              msg.role === 'user'
                ? 'bg-blue-100 text-blue-900'
                : 'bg-yellow-50 text-yellow-900 border border-yellow-300'
            }`} style={{ whiteSpace: 'pre-wrap', fontWeight: msg.role === 'user' ? 'normal' : '500' }}>
              {msg.content}
              {msg.role === 'assistant' && (
                <div className="text-[10px] text-gray-400 mt-1 italic">HidupAI</div>
              )}
            </div>
          </div>
        ))}
        
        {loading && (
          <div className="text-sm text-yellow-600 animate-pulse text-left italic transition-opacity duration-700 ease-in-out">
          {randomMessage.current}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="flex gap-2">
        <Input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ketik sesuatu..."
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          disabled={loading}
        />
        <Button onClick={handleSend} disabled={loading}>Kirim</Button>
      </div>

      {!isPremium && usageToday >= 5 && (
        <div className="text-sm text-red-500 text-center font-medium">
          ⚠️ Chat gratis kamu sudah habis hari ini. Yuk upgrade 🚀
        </div>
      )}

      {!isPremium && (
        <>
          <p className="text-xs text-center text-gray-500 mt-2">
            💬 {usageToday}/5 chat gratis digunakan hari ini
          </p>
          <div className="space-y-2 mt-4">
            <p className="text-center text-sm text-gray-500">Pilih paket untuk lanjut:</p>

            <Button
              onClick={() => handleUpgrade(15000)}
              className="w-full"
              disabled={upgrading}
            >
              {upgrading ? 'Memuat...' : '🎓 Trial 7 Hari — Rp15.000'}
            </Button>

            <Button
              onClick={() => handleUpgrade(79000)}
              variant="outline"
              className="w-full"
              disabled={upgrading}
            >
              {upgrading ? 'Memuat...' : '🚀 Premium — Rp79.000'}
            </Button>

            <p className="text-center text-xs text-gray-400">
              <a href="/pricing" className="underline hover:text-blue-600">Lihat detail manfaat →</a>
            </p>
          </div>
        </>
      )}
      
      {isPremium && (
        <div className="space-y-2 mt-6">
          <h3 className="text-sm font-semibold text-gray-700">📝 Catat Kebiasaan Hari Ini</h3>
          <div className="flex gap-2">
            <Input
              placeholder="Contoh: Olahraga pagi"
              value={habitInput}
              onChange={e => setHabitInput(e.target.value)}
            />
            <Button onClick={handleHabitLog} disabled={!habitInput.trim()}>Tandai</Button>
          </div>
          {habitMessage && <p className="text-sm text-green-600">{habitMessage}</p>}
        </div>
      )}

      <footer className="text-center text-xs text-gray-400 mt-6 space-y-1">
        <Image src="/images/logo-hidupai.png" alt="Logo" width={28} height={28} className="mx-auto" />
        <p>HidupAI™ — Powered by <strong className="text-gray-500">PABAR 🇮🇩</strong></p>
        <p><a href="/privacy" className="underline">Privasi</a> · <a href="/about" className="underline">Tentang</a></p>
      </footer>
    </main>
  )
}