'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@supabase/supabase-js'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

interface Order {
  id: string
  order_id: string
  email: string
  amount: number
  status: string
  plan_type: string
  paid_at?: string
  created_at: string
  payment_method?: string
  va_number?: string
}

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

const ADMIN_SECRET = process.env.NEXT_PUBLIC_ADMIN_SECRET!

export default function OrdersAdminPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [accessGranted, setAccessGranted] = useState(false)
  const [inputPassword, setInputPassword] = useState('')
  const [search, setSearch] = useState('')

  useEffect(() => {
    const stored = sessionStorage.getItem('admin-pass')
    if (stored === ADMIN_SECRET) setAccessGranted(true)
  }, [])

  const handleUnlock = () => {
    if (inputPassword === ADMIN_SECRET) {
      sessionStorage.setItem('admin-pass', inputPassword)
      setAccessGranted(true)
    } else {
      alert('❌ Kode rahasia salah')
    }
  }

  useEffect(() => {
    const fetchOrders = async () => {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })

      if (!error) setOrders(data || [])
      setLoading(false)
    }

    if (accessGranted) fetchOrders()
  }, [accessGranted])

  const filtered = orders.filter((o) =>
    o.email.toLowerCase().includes(search.toLowerCase()) ||
    o.order_id.toLowerCase().includes(search.toLowerCase())
  )

  function formatStatus(status: string) {
    switch (status) {
      case 'settlement':
        return <Badge variant="success">Berhasil ✅</Badge>
      case 'pending':
        return <Badge variant="pending">Menunggu ⏳</Badge>
      case 'expire':
      case 'cancel':
      case 'deny':
        return <Badge variant="destructive">Gagal ❌</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (!accessGranted) {
    return (
      <main className="max-w-sm mx-auto mt-40 text-center space-y-4">
        <h1 className="text-xl font-bold">🔐 Akses Terbatas</h1>
        <p className="text-sm text-gray-500">Masukkan kode rahasia admin</p>
        <Input
          type="password"
          value={inputPassword}
          onChange={(e) => setInputPassword(e.target.value)}
          placeholder="Kode Admin"
        />
        <Button onClick={handleUnlock}>Masuk</Button>
      </main>
    )
  }

  return (
    <main className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6">📊 Admin Panel – Semua Transaksi</h1>
      <Input
        placeholder="🔍 Cari berdasarkan email atau order ID..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-6"
      />
      {loading ? (
        <p>Memuat data transaksi...</p>
      ) : filtered.length === 0 ? (
        <p className="text-center text-gray-500">Tidak ada transaksi ditemukan.</p>
      ) : (
        <div className="grid gap-4">
          {filtered.map((order) => (
            <Card key={order.id} className="border rounded-xl shadow-sm hover:shadow-md transition">
              <CardContent className="p-4 space-y-1 text-sm">
                <div className="flex justify-between items-center mb-1">
                  <p className="font-medium text-gray-800">{order.email}</p>
                  {formatStatus(order.status)}
                </div>
                <p className="text-gray-600">Order ID: {order.order_id}</p>
                <p>Rp{order.amount.toLocaleString('id-ID')} – {order.plan_type}</p>
                {order.payment_method && <p>Metode: <b>{order.payment_method}</b></p>}
                {order.va_number && <p>VA: <span className="font-mono">{order.va_number}</span></p>}
                <p className="text-xs text-gray-500">
                  Dibuat: {new Date(order.created_at).toLocaleString('id-ID')}<br />
                  {order.paid_at && <>Dibayar: {new Date(order.paid_at).toLocaleString('id-ID')}</>}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </main>
  )
}
