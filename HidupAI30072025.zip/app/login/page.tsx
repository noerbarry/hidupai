'use client'

import { useState, Suspense } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'
import Image from 'next/image'
import RedirectIfRef from '@/components/RedirectIfRef'
import Link from 'next/link'

export default function LoginPage() {
  const supabase = createClientComponentClient()
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [agree, setAgree] = useState(false)

  const handleGoogleLogin = async () => {
    if (!agree) {
      setMessage('⚠️ Kamu harus menyetujui Kebijakan Privasi terlebih dahulu.')
      return
    }

    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${location.origin}/auth/callback`,
        queryParams: { prompt: 'select_account' },
      },
    })
  }

  const handleEmailLogin = async () => {
    if (!agree) {
      setMessage('⚠️ Kamu harus menyetujui Kebijakan Privasi terlebih dahulu.')
      return
    }

    if (!email || !email.includes('@')) {
      setMessage('⚠️ Masukkan email yang valid.')
      return
    }

    setLoading(true)
    setMessage('')

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        shouldCreateUser: true,
        emailRedirectTo: `${location.origin}/auth/callback`,
      },
    })

    setMessage(
      error ? '⚠️ Gagal mengirim link. Coba lagi.' : '📬 Link masuk dikirim. Cek email kamu!'
    )
    setLoading(false)
  }

  return (
    <main className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center items-center px-4 py-12">
      <Suspense fallback={null}>
        <RedirectIfRef />
      </Suspense>

      <div className="text-center space-y-4 mb-10">
        <Image src="/images/logo-hidupai.png" alt="Logo HidupAI" width={120} height={120} className="mx-auto" />
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
          Bayangkan Kalau <span className="text-blue-600">AI Bisa Bertumbuh</span> Bersamamu
        </h1>
        <p className="text-sm text-gray-500 max-w-md mx-auto">
          Lifeline AI yang mengerti tujuan dan emosimu. Ciptakan jejak hidup digitalmu bersama AI yang berevolusi.
        </p>
      </div>

      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg border border-gray-100 p-8 space-y-6">
        <div className="text-center space-y-3">
          <h2 className="text-xl font-semibold text-gray-800">
            Masuk ke <span className="text-blue-600 font-bold">HidupAI</span> 👋
          </h2>
          <p className="text-sm text-gray-500">Mulai perjalanan hidup digitalmu sekarang.</p>
        </div>

        <div className="space-y-4">
          <Button
            onClick={handleGoogleLogin}
            disabled={!agree}
            className="w-full text-sm bg-blue-600 text-white hover:bg-blue-700"
          >
            🔐 Masuk dengan Google
          </Button>

          <div className="text-center text-xs text-gray-400">atau gunakan email</div>

          <div className="relative">
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder=" "
              className="peer w-full px-4 pt-5 pb-2 text-sm bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            <label
              htmlFor="email"
              className="absolute left-4 top-2 text-xs text-gray-500 peer-placeholder-shown:top-3 peer-placeholder-shown:text-sm peer-placeholder-shown:text-gray-400 transition-all"
            >
              Email kamu
            </label>
          </div>

          <Button
            onClick={handleEmailLogin}
            disabled={loading || !email || !agree}
            className="w-full text-sm bg-blue-600 text-white hover:bg-blue-700"
          >
            {loading ? '⏳ Mengirim Link...' : '📫 Kirim Link Masuk ke Email'}
          </Button>

          {message && (
            <p className="text-center text-sm text-blue-600 mt-2">{message}</p>
          )}
        </div>

        <div className="text-center text-xs text-gray-500 space-y-2 pt-2">
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={agree}
              onChange={() => setAgree(!agree)}
              className="accent-blue-600"
            />
            <span>
              Saya menyetujui{' '}
              <Link
                href="/privacy"
                target="_blank"
                rel="noopener noreferrer"
                className="underline text-blue-600 hover:text-blue-800"
              >
                Kebijakan Privasi HidupAI
              </Link>
            </span>
          </label>
          <p className="text-[11px] text-gray-400">
            Belum punya akun? Kami akan buatkan otomatis saat kamu login.
          </p>
        </div>
      </div>

      <footer className="text-center text-[11px] text-gray-400 mt-10">
        HidupAI™ — Powered by <strong className="text-gray-600">PABAR 🇮🇩</strong>
      </footer>
    </main>
  )
}
