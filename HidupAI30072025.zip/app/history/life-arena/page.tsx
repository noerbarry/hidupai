'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Card, CardContent } from '@/components/ui/card'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'

interface LifeArenaLog {
  id: number
  topic: string
  decision: string
  values: string[]
  result: string
  created_at: string
}

export default function LifeArenaHistoryPage() {
  const supabase = createClientComponentClient()
  const router = useRouter()
  const [logs, setLogs] = useState<LifeArenaLog[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchLogs = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token

      if (!token) return router.push('/login')

      const userRes = await fetch('/api/check-user', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })

      const userData = await userRes.json()
      if (!userRes.ok || userData.error) {
        return router.push('/login')
      }

      const isExpired = userData.premium_until && new Date(userData.premium_until) < new Date()
      const isPremiumUser = ['premium', 'pro', 'trial'].includes(userData.plan_type) && !isExpired
      const allowFree = process.env.NEXT_PUBLIC_LIFE_ARENA_FREE === 'true'

      if (!isPremiumUser && !allowFree) {
        return router.push('/pricing')
      }

      const res = await fetch('/api/life-arena/logs', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })

      const data = await res.json()
      if (!res.ok || data.error) {
        return router.push('/login')
      }

      setLogs(data.logs || [])
      setLoading(false)
    }

    fetchLogs()
  }, [router, supabase])

  if (loading) {
    return (
      <main className="max-w-2xl mx-auto px-6 py-12 text-center text-gray-500">
        ⏳ Memuat histori Life Arena kamu...
      </main>
    )
  }

  return (
    <main className="max-w-2xl mx-auto px-6 py-12 space-y-6">
      <motion.h1
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-2xl font-bold text-blue-700 text-center"
      >
        📜 Histori Refleksi Life Arena
      </motion.h1>

      {logs.length === 0 ? (
        <p className="text-center text-gray-500 text-sm">
          Belum ada data simulasi refleksi hidup.
        </p>
      ) : (
        logs.map(log => (
          <Card key={log.id} className="shadow border border-blue-100">
            <CardContent className="space-y-2 p-4 text-sm text-gray-700">
              <p className="text-xs text-gray-400">{new Date(log.created_at).toLocaleString()}</p>
              <p><strong>Topik:</strong> {log.topic}</p>
              <p><strong>Nilai:</strong> {log.values.join(', ')}</p>
              <p className="italic text-gray-500">&quot;{log.decision}&quot;</p>
              <div className="bg-blue-50 border border-blue-100 p-3 rounded-md">
                <strong className="text-blue-700">Refleksi HidupAI:</strong>
                <p className="whitespace-pre-line mt-1">{log.result}</p>
              </div>
            </CardContent>
          </Card>
        ))
      )}

      <div className="text-center pt-6">
        <Button onClick={() => router.push('/dashboard')} className="w-full md:w-auto">
          ← Kembali ke Dashboard
        </Button>
      </div>
    </main>
  )
}
