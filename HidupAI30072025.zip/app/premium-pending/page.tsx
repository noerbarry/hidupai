export default function PremiumPending() {
    return (
      <main className="min-h-screen flex items-center justify-center text-center p-8">
        <div>
          <h1 className="text-xl font-bold text-yellow-600">⌛ Pembayaran Belum Selesai</h1>
          <p className="text-gray-600 mt-2">Kamu bisa kembali dan lanjutkan pembayaran dari email atau dashboard.</p>
        </div>
      </main>
    )
  }
  