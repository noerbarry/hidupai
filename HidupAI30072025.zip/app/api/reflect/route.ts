// File: app/api/reflect/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

type UserUpdate = {
  preferred_mode?: string
  weekly_goal?: string
}

export async function PATCH(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, preferred_mode, weekly_goal } = await req.json()

  if (!email) {
    return NextResponse.json({ error: 'Email wajib diisi' }, { status: 400 })
  }

  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
  }

  const updates: Partial<UserUpdate> = {}
  if (preferred_mode) updates.preferred_mode = preferred_mode
  if (weekly_goal) updates.weekly_goal = weekly_goal

  const { error: updateError } = await supabase
    .from('users')
    .update(updates)
    .eq('id', user.id)

  if (updateError) {
    return NextResponse.json({ error: updateError.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}

export async function GET(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { searchParams } = new URL(req.url)
  const email = searchParams.get('email')

  if (!email) {
    return NextResponse.json({ error: 'Missing email' }, { status: 400 })
  }

  const { data: user, error: userError } = await supabase
    .from('users')
    .select('preferred_mode, weekly_goal')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
  }

  return NextResponse.json({
    preferred_mode: user.preferred_mode || '',
    weekly_goal: user.weekly_goal || '',
  })
}
