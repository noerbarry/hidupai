import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'
import * as cookie from 'cookie'
import { jwtDecode } from 'jwt-decode'

const supabaseUser = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

interface DecodedToken {
  email?: string
  sub?: string
}

export async function POST(req: Request) {
  const body = await req.json()
  const { name, goal } = body
  const FEATURE_REFERRAL = process.env.FEATURE_REFERRAL === 'true'

  // ✅ Ambil cookie token Supabase
  const cookieHeader = req.headers.get('cookie') || ''
  const parsed = cookie.parse(cookieHeader)
  const token = Object.entries(parsed).find(([key]) =>
    key.includes('auth-token')
  )?.[1]

  if (!token) {
    return NextResponse.json({ error: 'Unauthorized (no token)' }, { status: 401 })
  }

  // ✅ Decode token
  let decodedEmail = ''
  let user_id = ''
  try {
    const decoded: DecodedToken = jwtDecode(token)
    decodedEmail = decoded.email || ''
    user_id = decoded.sub || ''
  } catch {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  }

  if (!decodedEmail || !user_id) {
    return NextResponse.json({ error: 'Unauthorized (no email or ID)' }, { status: 401 })
  }

  // ✅ Update metadata via Supabase Admin
  const { error: updateMetaError } = await supabaseAdmin.auth.admin.updateUserById(user_id, {
    user_metadata: { name, goal }
  })

  if (updateMetaError) {
    console.error('[Metadata Update Error]', updateMetaError)
    return NextResponse.json({ error: 'Gagal update profil' }, { status: 500 })
  }

  const generated_referral_code = FEATURE_REFERRAL
    ? `ref-${Math.random().toString(36).substring(2, 8)}`
    : null

  // ✅ Cek apakah user sudah ada
  const { data: existingUser } = await supabaseUser
    .from('users')
    .select('email')
    .eq('email', decodedEmail)
    .maybeSingle()

  if (!existingUser) {
    const { error: insertError } = await supabaseUser
      .from('users')
      .insert({
        name,
        goal,
        email: decodedEmail,
        referral_code: generated_referral_code,
        referral_points: 0,
        badge: 'Newbie',
        is_premium: false
      })

    if (insertError) {
      console.error('[Insert Error]', insertError)
      return NextResponse.json({ error: 'Gagal mendaftarkan user' }, { status: 500 })
    }
  }

  return NextResponse.json({ success: true })
}
