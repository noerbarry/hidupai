import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import crypto from 'crypto'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY!
const RESEND_API_KEY = process.env.RESEND_API_KEY

export async function POST(req: Request) {
  try {
    console.log('📩 Webhook POST diterima dari Midtrans')

    const bodyText = await req.text()
    const body = JSON.parse(bodyText)

    const order_id = /"order_id"\s*:\s*"([^"]+)"/.exec(bodyText)?.[1] || ''
    const status_code = /"status_code"\s*:\s*"([^"]+)"/.exec(bodyText)?.[1] || ''
    const gross_amount = /"gross_amount"\s*:\s*"([^"]+)"/.exec(bodyText)?.[1] || ''
    const signatureKey = req.headers.get('x-callback-signature') || ''

    const expectedSignature = crypto
      .createHash('sha512')
      .update(order_id + status_code + gross_amount + MIDTRANS_SERVER_KEY)
      .digest('hex')

    if (signatureKey !== expectedSignature) {
      console.warn(`❌ Signature mismatch for order_id: ${order_id}`)
      return NextResponse.json({ success: false, error: 'Invalid signature' }, { status: 400 })
    }

    const {
      transaction_status, fraud_status, transaction_time, customer_details,
      payment_type, va_numbers, permata_va_number, bca_va_number,
      bill_key, biller_code, store, payment_code, bank, card_type
    } = body

    let email = customer_details?.email

    await supabase.from('midtrans_webhook_logs').insert({
      order_id,
      status_code,
      transaction_status,
      payment_type,
      fraud_status,
      retry: req.headers.get('x-callback-retry') === 'true',
      raw_payload: body,
      email
    })

    const { data: existingOrder } = await supabase
      .from('orders')
      .select('status, plan_type, email')
      .eq('order_id', order_id)
      .single()

    if (!existingOrder) {
      console.error('❌ Order tidak ditemukan:', order_id)
      return NextResponse.json({ success: false, error: 'Order not found' }, { status: 404 })
    }

    if (existingOrder.status === 'settlement') {
      return NextResponse.json({ success: true, message: 'Already processed' })
    }

    const isSuccess =
      transaction_status === 'settlement' ||
      (transaction_status === 'capture' && fraud_status === 'accept')

    let paymentInfo = ''
    if (payment_type === 'bank_transfer') {
      const va = va_numbers?.[0]
      if (va) paymentInfo = `Transfer ke ${va.bank.toUpperCase()} VA ${va.va_number}`
      else if (permata_va_number) paymentInfo = `Transfer ke PERMATA VA ${permata_va_number}`
      else if (bca_va_number) paymentInfo = `Transfer ke BCA VA ${bca_va_number}`
    } else if (payment_type === 'echannel') {
      paymentInfo = `Mandiri Bill Key: ${bill_key}, Biller Code: ${biller_code}`
    } else if (payment_type === 'cstore') {
      paymentInfo = `Bayar di ${store?.toUpperCase()} dengan kode: ${payment_code}`
    } else if (['gopay', 'qris'].includes(payment_type)) {
      paymentInfo = `Pembayaran via ${payment_type.toUpperCase()}`
    } else if (payment_type === 'credit_card') {
      paymentInfo = `Kartu Kredit – ${bank?.toUpperCase()} (${card_type})`
    }

    await supabase.from('orders').update({
      status: isSuccess ? 'paid' : transaction_status,
      paid_at: isSuccess ? new Date().toISOString() : null,
      payment_info: paymentInfo,
      transaction_time: transaction_time || new Date().toISOString()
    }).eq('order_id', order_id)

    if (!isSuccess) {
      return NextResponse.json({ success: true, message: 'Waiting for payment confirmation' })
    }

    const planType = existingOrder.plan_type
    email = email || existingOrder.email

    if (!planType || !email) {
      return NextResponse.json({ success: false, error: 'Plan type or email missing' }, { status: 400 })
    }

    const now = new Date()
    const durationDays = planType === 'trial' ? 7 : planType === 'pro' ? 365 : 30
    const premiumUntil = new Date(now.getTime() + durationDays * 86400 * 1000)

    const { error: userUpdateError } = await supabase.from('users').update({
      is_premium: true,
      plan_type: planType,
      premium_until: premiumUntil.toISOString(),
      just_upgraded: true
    }).eq('email', email)

    if (userUpdateError) {
      console.error('❌ Gagal update user:', userUpdateError.message)
      return NextResponse.json({ success: false, error: 'Failed to update user' }, { status: 500 })
    }

    if (RESEND_API_KEY) {
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: 'HidupAI <noreply@hidupai.com>',
          to: [email],
          subject: `✅ Pembayaran HidupAI ${planType.toUpperCase()} Berhasil`,
          html: `
            <h2>Terima kasih telah upgrade ke HidupAI ${planType.toUpperCase()}!</h2>
            <p><strong>Nomor Invoice:</strong> ${order_id}</p>
            <p><strong>Total Pembayaran:</strong> Rp${parseInt(gross_amount).toLocaleString('id-ID')}</p>
            <p><strong>Status:</strong> ${transaction_status}</p>
            <p>Akun Anda kini aktif sebagai pengguna premium 🎉</p>
            <p>Selamat mengeksplor fitur eksklusif HidupAI 💙</p>
          `
        })
      })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('❌ Unexpected error in Midtrans callback:', err)
    return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 })
  }
}
