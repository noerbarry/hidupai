// app/api/cron/checkin/route.ts

import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET() {
  const { data: users, error } = await supabase
    .from('users')
    .select('email, name, weekly_goal, is_premium')
    .not('weekly_goal', 'is', null)

  if (error) {
    return NextResponse.json({ error: 'Gagal ambil user' }, { status: 500 })
  }

  const responses: { email: string; result: string }[] = []

  for (const user of users) {
    const prompt = `Hai ${user.name}, aku ingat kamu punya goal minggu ini: "${user.weekly_goal}" 💡

Ada hal kecil yang mau dicoba hari ini? Aku di sini buat bantu kamu refleksi atau brainstorming 💬`;

    const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        temperature: 0.8,
        messages: [{ role: 'system', content: prompt }]
      })
    })

    if (!openaiRes.ok) continue

    const data = await openaiRes.json()
    const reply = data.choices?.[0]?.message?.content?.trim() || ''

    await supabase
      .from('nudge_messages')
      .insert({ email: user.email, content: reply, type: 'checkin' })

    responses.push({ email: user.email, result: '✅ sent' })
  }

  return NextResponse.json({ result: responses })
}
