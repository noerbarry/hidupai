// File: app/api/referral/convert/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  try {
    const email = req.cookies.get('user-email')?.value

    if (!email) {
      return NextResponse.json({ success: false, message: 'User belum login.' }, { status: 401 })
    }

    const { data: user, error: fetchError } = await supabase
      .from('users')
      .select('referral_points, is_premium')
      .eq('email', email)
      .single()

    if (fetchError || !user) {
      return NextResponse.json({ success: false, message: 'User tidak ditemukan di database.' }, { status: 404 })
    }

    if (user.is_premium) {
      return NextResponse.json({ success: false, message: '✅ Kamu sudah Premium!' })
    }

    if ((user.referral_points ?? 0) < 10) {
      return NextResponse.json({
        success: false,
        message: '❌ Minimal 10 poin referral dibutuhkan untuk upgrade ke Premium.'
      })
    }

    const { error: updateError } = await supabase
      .from('users')
      .update({
        is_premium: true,
        referral_points: user.referral_points - 10,
        just_upgraded: true
      })
      .eq('email', email)

    if (updateError) {
      console.error('❌ Gagal mengupdate status Premium:', updateError.message)
      return NextResponse.json({ success: false, message: 'Gagal meng-upgrade akun.' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: '🎉 Selamat! Kamu berhasil upgrade ke Premium dengan 10 poin referral.'
    })
  } catch (err) {
    console.error('❌ Unexpected error in /referral/convert:', err)
    return NextResponse.json({ success: false, message: 'Terjadi kesalahan internal.' }, { status: 500 })
  }
}
