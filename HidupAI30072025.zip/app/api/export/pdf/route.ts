// File: ./app/api/export/pdf/route.ts

import { NextResponse } from 'next/server'
import { renderToBuffer } from '@react-pdf/renderer'
import SummaryPDF from '@/components/pdf/SummaryPDF'

export async function POST(req: Request) {
  const { name, goal, stats } = await req.json()

  try {
    const pdfBuffer = await renderToBuffer(
      SummaryPDF({ name, goal, stats })  // ✅ Panggil sebagai fungsi biasa, bukan JSX
    )

    return new Response(pdfBuffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'attachment; filename=ringkasan-hidupai.pdf'
      }
    })
  } catch (error) {
    console.error('❌ Gagal buat PDF:', error)
    return NextResponse.json({ error: 'Gagal generate PDF' }, { status: 500 })
  }
}
