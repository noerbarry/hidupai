import { withAuth } from '@/utils/withAuth'
import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  return withAuth(req, async (email, req) => {
    const { amount, plan_type } = await req.json()

    if (!amount || !plan_type) {
      return NextResponse.json({ error: 'Amount dan plan_type diperlukan.' }, { status: 400 })
    }

    // ✅ 1. Cek apakah sudah ada order pending sebelumnya
    const { data: existingOrder } = await supabase
      .from('orders')
      .select('order_id, snap_token, status')
      .eq('email', email)
      .eq('plan_type', plan_type)
      .eq('amount', amount)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (existingOrder?.snap_token) {
      // ✅ Gunakan kembali token yang ada
      return NextResponse.json({ token: existingOrder.snap_token })
    }

    // ✅ 2. Buat order baru
    const orderId = `order-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`
    const { error: insertError } = await supabase.from('orders').insert({
      order_id: orderId,
      email,
      amount,
      status: 'pending',
      plan_type
    })

    if (insertError) {
      return NextResponse.json({ error: 'Gagal menyimpan order' }, { status: 500 })
    }

    const serverKey = process.env.MIDTRANS_SERVER_KEY!
    const snapPayload = {
      transaction_details: {
        order_id: orderId,
        gross_amount: amount
      },
      customer_details: { email },
      item_details: [
        {
          id: plan_type,
          name: `Paket HidupAI - ${plan_type}`,
          price: amount,
          quantity: 1
        }
      ],
      enabled_payments: [
        'gopay', 'qris', 'bank_transfer', 'permata_va',
        'bca_va', 'echannel', 'credit_card', 'cstore'
      ],
      callbacks: {
        finish: 'https://hidupai.com/premium-success',
        unfinish: 'https://hidupai.com/premium-pending',
        error: 'https://hidupai.com/premium-error'
      }
    }

    const snapRes = await fetch('https://app.midtrans.com/snap/v1/transactions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${Buffer.from(serverKey + ':').toString('base64')}`
      },
      body: JSON.stringify(snapPayload)
    })

    if (!snapRes.ok) {
      const err = await snapRes.text()
      return NextResponse.json({ error: 'Gagal membuat transaksi Snap', detail: err }, { status: snapRes.status })
    }

    const data = await snapRes.json()

    // ✅ Update token ke order
    await supabase.from('orders').update({
      snap_token: data.token,
      snap_redirect_url: data.redirect_url
    }).eq('order_id', orderId)

    return NextResponse.json({ token: data.token })
  })
}
