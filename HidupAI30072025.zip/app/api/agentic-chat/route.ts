import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'
import { jwtDecode } from 'jwt-decode'
import { queryMemory } from '@/lib/rag/queryMemory'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

const getPrompt = (
  name: string,
  mode: string,
  goal: string,
  memory: string
): ChatMessage => {
  let content = ''

  switch (mode) {
    case 'pagi':
      content = `Sekarang pagi dan ${name} bersiap menjalani hari.

Tugasmu:
- Sambut ${name} dengan energi positif, misal: "Selamat pagi, ${name}! ☀️"
- Ajak refleksi ringan atau ajak set niat/fokus harian.
- Gaya bahasa: ringan, hangat, dan penuh semangat.
- Jangan bilang kamu AI. Kamu HidupAI™, sahabat pagi ${name}.
- Boleh beri langkah kecil yang bisa ia ambil hari ini.`
      break

    case 'mentok':
      content = `Sekarang ${name} sedang merasa mentok.

Tugasmu:
- Sambut dengan empati. Misal: "Gak apa-apa, ${name}. Kita pelan-pelan bareng 🌱"
- Tawarkan langkah kecil atau pertanyaan reflektif.
- Gaya bahasa: sabar, suportif, menenangkan.
- Jangan bilang kamu AI. Kamu HidupAI™, teman berpikir ${name}.
- Ajak ${name} kasih tahu apa yang sedang ia pikirkan.`
      break

    case 'sedih':
      content = `Sekarang ${name} sedang sedih atau lelah.

Tugasmu:
- Peluk lewat kata. Misal: "Aku di sini ya, ${name} 🤍"
- Dengarkan dulu sebelum memberi solusi.
- Gaya bahasa: lembut, reflektif, suportif.
- Jangan bilang kamu AI. Kamu HidupAI™, pendengar setia ${name}.
- Tawarkan ruang aman dan afirmasi jujur.`
      break

    case 'sukses':
      content = `Sekarang ${name} baru saja menyelesaikan sesuatu 🎉

Tugasmu:
- Rayakan keberhasilan ${name}. Misal: "KEREN banget, ${name}! 🏆"
- Tanyakan refleksi tentang prosesnya.
- Gaya bahasa: semangat, bangga, apresiatif.
- Jangan bilang kamu AI. Kamu HidupAI™, supporter pribadi ${name}.
- Ajak dia lanjutkan momentumnya.`
      break

    default:
      content = `Kamu adalah HidupAI™, sahabat hidup ${name}.

Info penting yang kamu tahu:
${memory || 'Belum ada memori panjang yang terekam.'}

Tujuan mingguan: "${goal}"

Tugasmu:
- Respons reflektif, empatik, dan kontekstual.
- Hindari kata pembuka seperti "Halo", "Baik saya bantu", atau "Saya AI".
- Sapa ${name} dengan hangat atau langsung ke dukungan.
- Boleh beri ajakan eksplorasi lebih dalam seperti: “Kalau kamu nyaman, boleh cerita lebih lanjut.”
- Gunakan gaya bahasa: proaktif, manusiawi, dan suportif.
- Boleh gunakan emoji ✨🧠💬 tapi jangan berlebihan.`
  }

  return {
    role: 'system',
    content
  }
}

export async function POST(req: Request) {
  const { messages, name, email, mode: rawMode }: {
    messages: ChatMessage[]
    name: string
    email: string
    mode?: string
  } = await req.json()

  const token = req.headers.get('Authorization')?.split(' ')[1]
  if (!token) return NextResponse.json({ message: 'Token tidak ditemukan' }, { status: 401 })

  let decodedEmail = ''
  try {
    decodedEmail = jwtDecode<{ email: string }>(token).email
  } catch {
    return NextResponse.json({ message: 'Token tidak valid' }, { status: 401 })
  }

  if (decodedEmail !== email) {
    return NextResponse.json({ message: 'Akses tidak sah 🔒' }, { status: 401 })
  }

  const { data: user, error } = await supabase
    .from('users')
    .select('is_premium, usage_today, last_used, long_term_memory, preferred_mode, weekly_goal')
    .eq('email', email)
    .single()

  if (error || !user) return NextResponse.json({ message: 'User tidak ditemukan' }, { status: 404 })

  const today = new Date().toISOString().split('T')[0]
  const usageToday = user.usage_today || 0

  if (user.last_used !== today) {
    await supabase
      .from('users')
      .update({ usage_today: 1, last_used: today })
      .eq('email', email)
  } else if (!user.is_premium && usageToday >= 5) {
    return NextResponse.json({
      message: 'Limit harian tercapai. Yuk upgrade ke Premium 🚀'
    })
  } else if (!user.is_premium) {
    await supabase
      .from('users')
      .update({ usage_today: usageToday + 1 })
      .eq('email', email)
  }

  const mode = rawMode || user.preferred_mode || ''
  const goal = user.weekly_goal || 'Belum ada tujuan mingguan.'
  const baseMemory = user.long_term_memory || ''

  const userLastMessage = messages
    .slice()
    .reverse()
    .find((msg) => msg.role === 'user')?.content || ''

  const ragChunks = await queryMemory(email, userLastMessage)
  const ragMemory = ragChunks.length > 0 ? `\n\n📚 Memori relevan:\n- ${ragChunks.join('\n- ')}` : ''
  const memory = baseMemory + ragMemory

  const systemPrompt = getPrompt(name, mode, goal, memory)

  const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'gpt-4',
      temperature: 0.75,
      messages: [systemPrompt, ...messages]
    })
  })

  if (!openaiRes.ok) {
    return NextResponse.json({ message: 'OpenAI error 😢' }, { status: 500 })
  }

  const data = await openaiRes.json()
  const responseMessage = data.choices?.[0]?.message?.content?.trim() || '...'

  if (responseMessage.length > 30) {
    const newMemory = `${baseMemory ? baseMemory + '\n\n' : ''}- ${new Date().toLocaleDateString('id-ID')}: ${responseMessage}`
    await supabase
      .from('users')
      .update({ long_term_memory: newMemory })
      .eq('email', email)
  }

  await supabase
    .from('users')
    .update({
      last_question: userLastMessage,
      last_response: responseMessage,
      last_interaction: new Date().toISOString()
    })
    .eq('email', email)

  return NextResponse.json({ message: responseMessage })
}
