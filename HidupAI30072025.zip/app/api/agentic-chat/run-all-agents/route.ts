// File: app/api/agentic-chat/run-all-agents/route.ts

import { NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'
import OpenAI from 'openai'

export const runtime = 'edge'

export async function POST(req: Request) {
  const { email } = await req.json()
  if (!email) return NextResponse.json({ error: 'Email diperlukan' }, { status: 400 })

  const supabase = createServerClient()

  try {
    // Ambil data pengguna dan preferensi
    const [{ data: goalData }, { data: memoryData }, { data: habitData }, { data: prefData }] = await Promise.all([
      supabase.from('user_goals').select('goal').eq('email', email).single(),
      supabase.from('user_memory').select('memory').eq('email', email).single(),
      supabase.from('habit_stats').select('*').eq('email', email).order('date', { ascending: false }).limit(1).single(),
      supabase.from('agentic_preferences').select('mode').eq('email', email).single()
    ])

    const goal = goalData?.goal || ''
    const memory = memoryData?.memory || ''
    const habit_stats = habitData || {}
    const preferred_mode = prefData?.mode || 'reflektif-emosional'

    const prompts = {
      memory: `Simpan informasi baru ke dalam long-term memory HidupAI. Format JSON ringkas.\nJika data baru bertentangan dengan yang lama, prioritaskan yang terbaru.\n\nContoh informasi:\n- Pengguna ingin fokus pada refleksi spiritual minggu ini\n- Target baru: olahraga pagi minimal 3x`,

      planner: `Berdasarkan data berikut:\n- Tujuan pengguna: ${goal}\n- Insight kebiasaan: (otomatis)\n- Tren: 📈\n- Rencana sebelumnya: -\n\nTulis rencana mingguan berupa habit yang realistis, bertahap, dan empatik. Format markdown.`,

      reflection: `Kamu adalah pelatih hidup (Life Coach AI) dari HidupAI. Buat refleksi mingguan seperti catatan dari seorang mentor, berdasarkan:\n\n- Tujuan Hidup: ${goal}\n- Mode Reflektif: ${preferred_mode}\n- Memori Jangka Panjang:\n${memory}\n\nTugas:\n1. Tulis catatan refleksi mendalam dan membangun kesadaran\n2. Tambahkan 2 pertanyaan reflektif untuk minggu depan\n3. Jangan menyapa atau sebut nama pengguna`,

      evaluator: `Kamu adalah Evaluator AI. Berdasarkan data habit mingguan pengguna:\n${JSON.stringify(habit_stats, null, 2)}\n\nTugas:\n1. Analisis pola peningkatan / penurunan\n2. Beri insight singkat dan actionable\n3. Hindari judgemental tone`
    }

    const agentResults: Record<string, string> = {}
    const agentNames = Object.keys(prompts)

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! })

    await Promise.all(agentNames.map(async (agent) => {
      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: 'Kamu adalah bagian dari sistem AI reflektif HidupAI yang saling bekerjasama.' },
          { role: 'user', content: prompts[agent as keyof typeof prompts] }
        ],
        stream: false
      })

      agentResults[agent] = response.choices?.[0]?.message?.content || '[Gagal mengambil respons]'

      await supabase.from('agent_outputs').insert({
        email,
        agent,
        content: agentResults[agent]
      })
    }))

    return NextResponse.json({ status: 'success', results: agentResults })

  } catch (e: unknown) {
    if (e instanceof Error) {
      return NextResponse.json({ error: e.message }, { status: 500 })
    }
    return NextResponse.json({ error: 'Gagal menjalankan agen' }, { status: 500 })
  }
}
