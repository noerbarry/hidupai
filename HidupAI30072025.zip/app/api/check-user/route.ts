import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'
import { jwtDecode } from 'jwt-decode'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: Request) {
  const authHeader = req.headers.get('Authorization')
  const token = authHeader?.split(' ')[1]

  if (!token) {
    return NextResponse.json({ error: 'Tidak ada token login' }, { status: 401 })
  }

  let decodedEmail = ''
  try {
    const decoded = jwtDecode<{ email?: string }>(token)
    if (!decoded?.email) {
      return NextResponse.json({ error: 'Email tidak ditemukan di token' }, { status: 401 })
    }
    decodedEmail = decoded.email
  } catch {
    return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 })
  }

  const { data: user, error } = await supabase
    .from('users')
    .select(`
      email, name, goal, badge, plan_type, premium_until, referral_code, last_question, last_response
    `)
    .eq('email', decodedEmail)
    .maybeSingle()

  if (error || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
  }

  const now = new Date()
  const premiumUntil = user.premium_until ? new Date(user.premium_until) : null
  const isPremium =
    ['pro', 'premium', 'trial'].includes(user.plan_type) &&
    premiumUntil &&
    now <= premiumUntil

  // ✅ Jangan auto-downgrade. Cukup log jika sudah kadaluarsa
  if (!isPremium && premiumUntil && now > premiumUntil) {
    console.warn(`🔔 Premium expired for ${user.email} on ${premiumUntil.toISOString()}`)
  }

  return NextResponse.json({
    email: user.email,
    name: user.name,
    goal: user.goal,
    is_premium: isPremium,
    badge: user.badge || 'Newbie',
    referral_code: process.env.NEXT_PUBLIC_FEATURE_REFERRAL === 'true' ? user.referral_code : null,
    last_question: user.last_question || '',
    last_response: user.last_response || ''
  })
}
