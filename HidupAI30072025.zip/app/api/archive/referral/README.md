# Archive Folder – Referral Feature (API)

Semua endpoint referral disimpan di sini sementara.
