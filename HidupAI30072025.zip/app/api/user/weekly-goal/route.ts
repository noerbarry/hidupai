// File: app/api/user/weekly-goal/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, goal } = await req.json()

  // Validasi input
  if (!email || !goal?.trim()) {
    return NextResponse.json({ error: 'Email dan goal diperlukan' }, { status: 400 })
  }

  // Update weekly_goal berdasarkan email
  const { error } = await supabase
    .from('users')
    .update({ weekly_goal: goal.trim() })
    .eq('email', email)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
