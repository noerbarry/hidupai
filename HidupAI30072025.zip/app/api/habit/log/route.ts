import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  const { email, habit_id } = await req.json()

  if (!email || !habit_id) {
    return NextResponse.json({ success: false, error: 'Email dan habit_id wajib diisi.' }, { status: 400 })
  }

  const today = new Date().toISOString().split('T')[0]

  const { data, error } = await supabase.from('habit_logs').insert([
    { email, habit_id, date: today }
  ])

  if (error) {
    console.error('❌ Gagal menyimpan log habit:', error)
    return NextResponse.json({ success: false, error: 'Gagal menyimpan log.' }, { status: 500 })
  }

  return NextResponse.json({ success: true, data })
}
