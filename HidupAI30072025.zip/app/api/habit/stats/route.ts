import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { startOfWeek, addDays, subWeeks, format } from 'date-fns'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const dayTranslation: Record<string, string> = {
  Mon: 'Senin',
  Tue: 'Selasa',
  Wed: 'Rabu',
  Thu: 'Kamis',
  Fri: 'Jumat',
  Sat: 'Sabtu',
  Sun: 'Minggu'
}

function generateInsight(counts: Record<string, number>, totalThisWeek: number, totalLastWeek: number): string {
  const entries = Object.entries(counts)
  const missed = entries.filter(([, val]) => val === 0).map(([day]) => dayTranslation[day] || day)

  let insight = ''

  if (totalThisWeek === 0) {
    insight = 'Kamu belum mencatat kebiasaan apapun minggu ini. Yuk mulai dari satu hal kecil hari ini ✨'
  } else if (missed.length >= 4) {
    insight = `Kamu sering melewatkan hari: ${missed.join(', ')}. Coba jadikan hari-hari tersebut lebih ringan atau gunakan reminder!`
  } else {
    const bestDay = entries.reduce((a, b) => (a[1] > b[1] ? a : b))[0]
    insight = `Bagus! Hari terbaikmu minggu ini adalah ${dayTranslation[bestDay] || bestDay}. Pertahankan ritmemu 🙌`
  }

  const diff = totalThisWeek - totalLastWeek
  const trend = diff === 0
    ? 'tetap stabil'
    : diff > 0
    ? `meningkat ${Math.round((diff / (totalLastWeek || 1)) * 100)}%`
    : `menurun ${Math.abs(Math.round((diff / (totalLastWeek || 1)) * 100))}%`

  return `${insight} 📊 Progres kamu ${trend} dibanding minggu lalu.`
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const email = searchParams.get('email')

    if (!email) {
      return NextResponse.json({ stats: [], insight: 'Email tidak ditemukan.' }, { status: 200 })
    }

    const today = new Date()
    const startThisWeek = startOfWeek(today, { weekStartsOn: 1 })
    const startLastWeek = subWeeks(startThisWeek, 1)
    const endLastWeek = addDays(startThisWeek, -1)

    const startThisStr = format(startThisWeek, 'yyyy-MM-dd')
    const startLastStr = format(startLastWeek, 'yyyy-MM-dd')
    const endLastStr = format(endLastWeek, 'yyyy-MM-dd')

    const { data: thisWeekData, error: errorThis } = await supabase
      .from('habit_logs')
      .select('date')
      .eq('email', email)
      .eq('completed', true)
      .gte('date', startThisStr)

    const { data: lastWeekData, error: errorLast } = await supabase
      .from('habit_logs')
      .select('date')
      .eq('email', email)
      .eq('completed', true)
      .gte('date', startLastStr)
      .lte('date', endLastStr)

    if (errorThis || errorLast) {
      console.error('❌ Gagal ambil data habit:', errorThis || errorLast)
      return NextResponse.json({ stats: [], insight: 'Gagal memuat data.' }, { status: 500 })
    }

    const counts: Record<string, number> = {}
    for (let i = 0; i < 7; i++) {
      const day = format(addDays(startThisWeek, i), 'EEE')
      counts[day] = 0
    }

    thisWeekData.forEach((entry) => {
      const day = format(new Date(entry.date), 'EEE')
      if (counts[day] !== undefined) counts[day]++
    })

    const stats = Object.entries(counts).map(([day, total]) => ({
      day: dayTranslation[day] || day,
      total
    }))

    const insight = generateInsight(counts, thisWeekData.length, lastWeekData.length)

    return NextResponse.json({ stats, insight })
  } catch (err) {
    console.error('❌ Unexpected error:', err)
    return NextResponse.json({ stats: [], insight: 'Terjadi kesalahan.' }, { status: 500 })
  }
}
