// File: app/api/memory/save/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { embedMemory } from '@/lib/rag/embedMemory'

export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email, memory } = await req.json()

  // ✅ Validasi input
  if (!email || !email.includes('@') || !memory?.trim()) {
    return NextResponse.json({ error: 'Email dan memori baru diperlukan.' }, { status: 400 })
  }

  // ✅ Cari user berdasarkan email
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan.' }, { status: 404 })
  }

  // ✅ Simpan memori ke tabel
  const { error: insertError } = await supabase
    .from('long_term_memories')
    .insert([
      {
        user_id: user.id,
        content: memory.trim(),
        tags: [],
        source: 'manual'
      }
    ])

  if (insertError) {
    return NextResponse.json({ error: insertError.message || 'Gagal menyimpan memori.' }, { status: 500 })
  }

  // ✅ Embedding vector
  try {
    const embedResult = await embedMemory(email, memory.trim())
    if (!embedResult.success) {
      return NextResponse.json({ error: 'Memori tersimpan, tapi gagal proses embedding.' }, { status: 500 })
    }
  } catch (err) {
    console.error('❌ Gagal embedMemory:', err)
    return NextResponse.json({ error: 'Terjadi kesalahan saat memproses embedding.' }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
