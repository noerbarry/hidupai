// app/layout.tsx

import './globals.css'
import { Inter } from 'next/font/google'
import Script from 'next/script'
import NavbarWrapper from '@/components/NavbarWrapper'
import Footer from '@/components/Footer'
import { Toaster } from 'react-hot-toast'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'HidupAI™ — Teman Sejiwa, Mentor Digital',
  description: 'Asisten AI yang bantu kamu capai tujuan hidup, lebih fokus, dan berkembang setiap hari.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <head>
        {/* Midtrans Snap Script */}
        <Script
          src="https://app.midtrans.com/snap/snap.js"
          data-client-key={process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY}
          strategy="beforeInteractive"
        />

        {/* SEO & OG Metadata */}
        <meta property="og:title" content="HidupAI™ – Mentor Digitalmu Setiap Hari" />
        <meta property="og:description" content="Asisten AI personal yang bantu kamu bertumbuh, mengingat tujuan, dan mendampingi perjalanan hidupmu. Powered by PABAR 🇮🇩" />
        <meta property="og:image" content="https://hidupai.com/images/og-hidupai-poster.png" />
        <meta property="og:url" content="https://hidupai.com" />
        <meta property="og:type" content="website" />

        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="HidupAI™ – Mentor Digitalmu" />
        <meta name="twitter:description" content="AI personal yang bantu kamu refleksi & bertumbuh. Bagian dari ekosistem PABAR." />
        <meta name="twitter:image" content="https://hidupai.com/images/og-hidupai-poster.png" />
      </head>

      <body className={`${inter.className} bg-gray-50 text-gray-800 min-h-screen overflow-y-auto`}>
        <NavbarWrapper />
        <main className="flex-grow px-4 pt-6 sm:pt-8 md:pt-10">{children}</main>
        <Footer />

        {/* Custom Toast with Framer Motion */}
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              background: 'transparent',
              boxShadow: 'none',
              padding: 0
            }
          }}
        />
      </body>
    </html>
  )
}
