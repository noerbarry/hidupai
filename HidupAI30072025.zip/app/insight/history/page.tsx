'use client'

import { useEffect, useState } from 'react'
import { format } from 'date-fns'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

interface InsightEntry {
  insights: string[]
  created_at: string
}

export default function InsightHistoryPage() {
  const [history, setHistory] = useState<InsightEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchHistory = async () => {
      const res = await fetch('/api/user-insight/history')
      const data = await res.json()
      setHistory(data.insights || [])
      setLoading(false)
    }
    fetchHistory()
  }, [])

  if (loading) {
    return <main className="p-6 text-center text-sm text-gray-500">⏳ Memuat riwayat insight...</main>
  }

  return (
    <main className="max-w-3xl mx-auto px-6 py-12 space-y-6">
      <h1 className="text-2xl font-bold text-blue-700">🧠 Riwayat Insight Reflektif</h1>
      <p className="text-gray-600 text-sm mb-4">Berikut adalah insight yang pernah dihasilkan untukmu setiap minggunya.</p>

      {history.length === 0 ? (
        <p className="text-sm text-gray-500 italic">Belum ada insight yang tersimpan.</p>
      ) : (
        history.map((entry, idx) => (
          <Card key={idx}>
            <CardContent className="p-4 space-y-2">
              <p className="text-sm text-gray-500">
                📅 {format(new Date(entry.created_at), 'dd MMMM yyyy')}
              </p>
              <ul className="list-disc text-sm text-gray-700 pl-5 space-y-1">
                {entry.insights.map((insight, i) => (
                  <li key={i}>{insight}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))
      )}

      <div className="pt-4">
        <Button variant="outline" onClick={() => window.history.back()}>⬅️ Kembali ke Dashboard</Button>
      </div>
    </main>
  )
}
