// File: app/success/page.tsx

'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

export default function SuccessPage() {
  const router = useRouter()
  const supabase = createClientComponentClient()
  const [planType, setPlanType] = useState<string>('')
  const [name, setName] = useState<string>('')

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token

      if (!token) return router.push('/login')

      const res = await fetch('/api/check-user', {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`
        }
      })

      const data = await res.json()
      if (!res.ok || data?.error) return router.push('/register')

      setName(data.name || '')
      setPlanType(data.plan_type || '')
    }

    fetchUser()
  }, [supabase, router])

  return (
    <div className="max-w-md mx-auto py-12 px-6 text-center">
      <Image
        src="/images/success.svg"
        alt="Success"
        width={120}
        height={120}
        className="mx-auto mb-4"
      />
      <h1 className="text-2xl font-bold text-green-600 mb-2">Pembayaran Berhasil! 🎉</h1>
      <p className="text-gray-600 mb-4">
        Selamat <span className="font-semibold">{name}</span>, akun kamu telah di-upgrade ke{' '}
        <span className="capitalize font-semibold">{planType}</span>.
      </p>
      <p className="text-sm text-gray-500 mb-6">
        Yuk mulai eksplorasi semua fitur premium HidupAI sekarang juga ✨
      </p>
      <Button onClick={() => router.push('/')}>🚀 Kembali ke Dashboard</Button>
    </div>
  )
}
