// File: app/weekly/page.tsx

'use client'

import { useEffect, useState } from 'react'
import Cookies from 'js-cookie'

export default function WeeklyInsightPage() {
  const [name, setName] = useState('')
  const [goal, setGoal] = useState('')
  const [lastQuestion, setLastQuestion] = useState('')
  const [lastResponse, setLastResponse] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const email = Cookies.get('user-email')
      if (!email) return

      const res = await fetch('/api/check-user')
      const data = await res.json()

      setName(data.name)
      setGoal(data.goal)
      setLastQuestion(data.last_question || '')
      setLastResponse(data.last_response || '')
      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return <p className="text-center mt-10 text-sm text-gray-500">⏳ Menyiapkan insight mingguan kamu...</p>
  }

  return (
    <main className="max-w-xl mx-auto px-6 py-12 space-y-6 text-gray-800">
      <h1 className="text-3xl font-bold">📆 Refleksi Mingguan</h1>

      <p>Hai <strong>{name}</strong>, ini kilas balik kamu minggu ini:</p>

      <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded shadow">
        <p className="text-sm text-gray-600">🎯 Tujuan hidup kamu:</p>
        <p className="text-lg font-semibold mt-1">{goal}</p>
      </div>

      {lastQuestion && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded shadow space-y-2">
          <p className="font-medium">💬 Pertanyaan terakhir kamu:</p>
          <p className="italic">“{lastQuestion}”</p>
          <p className="text-sm mt-2 text-yellow-800">🧠 HidupAI sempat membalas:</p>
          <p className="text-[13px]">{lastResponse}</p>
        </div>
      )}

      <div className="bg-white border border-gray-200 p-4 rounded shadow">
        <p className="font-medium mb-2">✨ Refleksi minggu ini:</p>
        <ul className="list-disc ml-5 space-y-1 text-sm text-gray-700">
          <li>Apakah kamu sudah lebih dekat dengan tujuanmu?</li>
          <li>Apa satu hal bermakna yang terjadi minggu ini?</li>
          <li>Apa yang ingin kamu perbaiki minggu depan?</li>
        </ul>
      </div>

      <p className="text-xs text-gray-400 text-center mt-10">
        HidupAI mendukungmu untuk terus bertumbuh 🌱
      </p>
    </main>
  )
}
