'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/utils/supabase'

export default function SignupPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleSignup = async () => {
    const { error } = await supabase.auth.signUp({ email, password })

    if (error) {
      setError(error.message)
    } else {
      alert('Akun berhasil dibuat. Cek email kamu untuk verifikasi.')
      router.push('/login')
    }
  }

  return (
    <main className="max-w-md mx-auto px-4 py-16">
      <h1 className="text-2xl font-bold text-center mb-6">Daftar ke HidupAI</h1>
      <div className="space-y-4">
        <input
          type="email"
          placeholder="Email"
          className="w-full border px-3 py-2 rounded-md text-sm shadow-xs"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="w-full border px-3 py-2 rounded-md text-sm shadow-xs"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <button
          onClick={handleSignup}
          className="w-full bg-blue-600 text-white text-sm py-2 rounded-md shadow hover:bg-blue-700"
        >
          Daftar
        </button>
        <p className="text-xs text-center text-gray-500">
          Sudah punya akun? <a href="/login" className="text-blue-600 underline">Login di sini</a>
        </p>
      </div>
    </main>
  )
}
