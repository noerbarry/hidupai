import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const premiumRoutes = ['/tools', '/notion', '/insight', '/template', '/history']
const maintenanceMode = process.env.MAINTENANCE_MODE === 'true'

export async function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname
  const allCookies = request.cookies.getAll()

  const hasAuthToken = allCookies.some(cookie =>
    cookie.name.includes('auth-token')
  )

  const isPublicRoute =
    pathname === '/login' ||
    pathname === '/auth/callback' ||
    pathname === '/pricing' ||
    pathname === '/success' ||
    pathname === '/maintenance' ||
    pathname === '/privacy' ||
    pathname === '/contact' ||
    pathname === '/faq' ||
    pathname === '/about' ||
    pathname === '/terms-and-conditions' ||
      pathname === '/admin' ||
    pathname === '/disclaimer' ||
    pathname === '/' ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/favicon.ico') ||
    pathname.startsWith('/images')

  // ✅ Redirect kalau belum login dan akses halaman private
  if (!hasAuthToken && !isPublicRoute) {
    return NextResponse.redirect(new URL('/login', request.url))
  }

  // ✅ Mode Maintenance — redirect semua user ke halaman maintenance (kecuali admin & /maintenance)
  if (maintenanceMode && pathname !== '/maintenance') {
    const tokenCookie = allCookies.find(cookie => cookie.name.includes('auth-token'))
    const token = tokenCookie?.value

    if (token) {
      const { data: session } = await supabase.auth.getUser(token)
      const email = session?.user?.email

      if (email) {
        const { data: user } = await supabase
          .from('users')
          .select('plan_type')
          .eq('email', email)
          .maybeSingle()

        if (user?.plan_type !== 'admin') {
          return NextResponse.redirect(new URL('/maintenance', request.url))
        }
      } else {
        return NextResponse.redirect(new URL('/maintenance', request.url))
      }
    } else {
      return NextResponse.redirect(new URL('/maintenance', request.url))
    }
  }

  // ✅ Validasi akses premium
  const isPremiumRoute = premiumRoutes.some((r) => pathname.startsWith(r))

  if (hasAuthToken && isPremiumRoute) {
    const tokenCookie = allCookies.find(cookie => cookie.name.includes('auth-token'))
    const token = tokenCookie?.value

    if (token) {
      const { data: session } = await supabase.auth.getUser(token)
      const email = session?.user?.email

      if (email) {
        const { data: user } = await supabase
          .from('users')
          .select('plan_type, premium_until')
          .eq('email', email)
          .maybeSingle()

        const today = new Date().toISOString().split('T')[0]
        const expired = user?.premium_until && new Date(user.premium_until) < new Date(today)

        if (!user || !['premium', 'pro', 'trial'].includes(user.plan_type) || expired) {
          return NextResponse.redirect(new URL('/pricing', request.url))
        }
      }
    }
  }

  return NextResponse.next()
}

// ✅ Terapkan ke semua route kecuali static dan API
export const config = {
  matcher: ['/((?!api|_next|static|privacy|favicon.ico).*)'],
}
