'use client'

import { Suspense } from 'react'
import { FriendlyErrorSection } from '@/components/FriendlyErrorSection'
import RedirectAfterLogin from '@/components/RedirectAfterLogin'

export default function AuthCallbackPage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-b from-white to-slate-100 px-4">
      <Suspense fallback={null}>
        <FriendlyErrorSection />
        <RedirectAfterLogin />
      </Suspense>
    </main>
  )
}
