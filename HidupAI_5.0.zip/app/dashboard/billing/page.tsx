'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

interface User {
  plan_type: 'free' | 'trial' | 'premium' | 'pro'
  premium_until: string | null
}

interface Order {
  order_id: string
  package: string
  amount: number
  status: string
  created_at: string
}

export default function BillingPage() {
  const supabase = createClientComponentClient()
  const [user, setUser] = useState<User | null>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchBillingData = async () => {
      try {
        const { data: sessionData } = await supabase.auth.getSession()
        const email = sessionData.session?.user.email

        if (!email) return

        const { data: userData } = await supabase
          .from('users')
          .select('plan_type, premium_until')
          .eq('email', email)
          .single()

        const { data: orderData } = await supabase
          .from('orders')
          .select('order_id, package, amount, status, created_at')
          .eq('email', email)
          .order('created_at', { ascending: false })

        if (userData) setUser(userData)
        if (orderData) setOrders(orderData)
      } catch (error) {
        console.error('❌ Gagal mengambil data billing:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchBillingData()
  }, [supabase])

  const handleDownloadInvoice = (order: Order) => {
    const invoiceHtml = `
      <h2>Invoice HidupAI</h2>
      <p>Order ID: <strong>${order.order_id}</strong></p>
      <p>Paket: ${order.package}</p>
      <p>Jumlah: Rp ${order.amount.toLocaleString('id-ID')}</p>
      <p>Status: ${order.status}</p>
      <p>Tanggal: ${new Date(order.created_at).toLocaleString('id-ID')}</p>
    `
    const newWindow = window.open('', '_blank')
    if (newWindow) {
      newWindow.document.write(invoiceHtml)
      newWindow.document.close()
      newWindow.print()
    }
  }

  if (loading) {
    return (
      <div className="text-center mt-10 text-sm text-gray-500">
        ⏳ Memuat riwayat pembayaran...
      </div>
    )
  }

  const now = new Date()
  const premiumUntil = user?.premium_until ? new Date(user.premium_until) : null
  const isExpiringSoon =
    user?.plan_type !== 'premium' &&
    premiumUntil &&
    premiumUntil.getTime() - now.getTime() < 3 * 24 * 60 * 60 * 1000 // < 3 hari

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Status Langganan</h1>

      {isExpiringSoon && premiumUntil && (
        <div className="bg-yellow-100 text-yellow-800 p-3 rounded border border-yellow-300 mb-4">
          ⚠️ Masa aktif paket kamu akan habis pada{' '}
          <strong>{premiumUntil.toLocaleDateString('id-ID')}</strong>. Jangan lupa perpanjang ya!
        </div>
      )}

      <div className="bg-white shadow rounded p-4 border">
        <p><strong>Paket:</strong> {user?.plan_type}</p>
        <p>
          <strong>Berlaku hingga:</strong>{' '}
          {premiumUntil ? premiumUntil.toLocaleDateString('id-ID') : 'Selamanya'}
        </p>
      </div>

      <h2 className="text-xl font-semibold mt-8 mb-3">Riwayat Pembayaran</h2>
      <div className="space-y-2">
        {orders.length === 0 ? (
          <p className="text-sm text-gray-500">Belum ada transaksi.</p>
        ) : (
          orders.map((order) => (
            <div
              key={order.order_id}
              className="border p-3 rounded bg-gray-50"
            >
              <p className="text-sm font-semibold">#{order.order_id}</p>
              <p>Paket: {order.package}</p>
              <p>Status: <span className="uppercase text-xs font-medium">{order.status}</span></p>
              <p>Jumlah: Rp {order.amount.toLocaleString('id-ID')}</p>
              <p className="text-xs text-gray-500">
                Tanggal: {new Date(order.created_at).toLocaleString('id-ID')}
              </p>
              <button
                onClick={() => handleDownloadInvoice(order)}
                className="text-xs text-blue-600 hover:underline mt-1"
              >
                Download Invoice
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
