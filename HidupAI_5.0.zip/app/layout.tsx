// app/layout.tsx

import './globals.css';
import { Inter } from 'next/font/google';
import Script from 'next/script';
import { Toaster } from 'react-hot-toast';
import AppShell from '@/components/AppShell'; // ⟵ pakai ini sekarang

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

export const metadata = { /* ... punyamu tadi sama persis ... */ };

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className={inter.variable}>
      <head>
        <Script
          src="https://app.midtrans.com/snap/snap.js"
          data-client-key={process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY}
          strategy="beforeInteractive"
        />
        <link rel="icon" href="/icons/hidupai-icon.png" sizes="32x32" />
        <link rel="apple-touch-icon" href="/icons/hidupai-icon.png" />
        <style>{`html { scroll-behavior: smooth; }`}</style>
      </head>

      <body
        className={`
          ${inter.className}
          bg-[#F5F7FA]
          text-[#1F2937]
          antialiased
        `}
      >
        {/* Shell yang ngatur kapan navbar/footer tampil */}
        <AppShell>{children}</AppShell>

        <Toaster
          position="top-center"
          toastOptions={{
            duration: 2500,
            style: {
              background: '#FFFFFF',
              borderRadius: '14px',
              padding: '12px 18px',
              border: '1px solid #E5E7EB',
              boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
              fontSize: '14px',
            },
          }}
        />
      </body>
    </html>
  );
}
