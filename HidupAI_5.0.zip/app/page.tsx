'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'

/* ============================
   CAROUSEL IMAGES 
============================ */
const carouselSlides = [
  { src: '/images/HidupAILifeCoach.png', alt: 'HidupAI Life Coach Slide' },
  { src: '/images/HidupAIMotivation.jpeg', alt: 'HidupAI Motivation Slide' },
  { src: '/images/HidupAImengertikamu.png', alt: 'HidupAI Mengerti Kamu' },
  { src: '/images/FiturReflektif HidupAI.png', alt: 'Fitur Reflektif HidupAI' },
]

export default function HomePage() {
  const [index, setIndex] = useState(0)
  const [checking, setChecking] = useState(true)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const supabase = createClientComponentClient()
  const router = useRouter()

  const handleNext = () =>
    setIndex((prev) => (prev + 1) % carouselSlides.length)

  const handlePrev = () =>
    setIndex((prev) => (prev - 1 + carouselSlides.length) % carouselSlides.length)

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setIsLoggedIn(false)
    setMobileMenuOpen(false)
    router.push('/login')
  }

  // 🔐 Cek status login di awal
  useEffect(() => {
    const checkLogin = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      const loggedIn = !!session?.user?.email
      setIsLoggedIn(loggedIn)
      setChecking(false)
    }

    checkLogin()
  }, [supabase])

  // 🔁 Kalau sudah login → auto ke dashboard
  useEffect(() => {
    if (!checking && isLoggedIn) {
      router.push('/dashboard')
    }
  }, [checking, isLoggedIn, router])

  if (checking) {
    return (
      <main className="min-h-screen flex items-center justify-center text-sm text-gray-500">
        ⏳ Memuat...
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-blue-50/60 to-blue-100/40 text-[#1F2937] pt-24 pb-16">
      {/* ============================
           HEADER
      ============================ */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between gap-3">
          {/* LOGO — diperbesar */}
          <Link href="/" className="flex items-center">
            <Image
              src="/images/logo-hidupai.png"
              alt="HidupAI"
              width={260}
              height={260}
              priority
              className="h-20 sm:h-24 md:h-28 w-auto"
            />
          </Link>

          {/* NAV DESKTOP */}
          <nav className="hidden md:flex gap-6 text-sm text-gray-700">
            <a href="#hero" className="hover:text-[#1A73E8]">
              Beranda
            </a>
            <Link href="/pricing" className="hover:text-[#1A73E8]">
              Harga
            </Link>
            <Link href="/about" className="hover:text-[#1A73E8]">
              Tentang
            </Link>
            <a href="#komunitas" className="hover:text-[#1A73E8]">
              Komunitas
            </a>
            <Link href="/faq" className="hover:text-[#1A73E8]">
              FAQ
            </Link>
            <Link href="/contact" className="hover:text-[#1A73E8]">
              Contact
            </Link>
            <Link
              href="/terms-and-conditions"
              className="hover:text-[#1A73E8]"
            >
              Term &amp; Conditions
            </Link>
            <Link href="/disclaimer" className="hover:text-[#1A73E8]">
              Disclaimer
            </Link>
          </nav>

          {/* AUTH + HAMBURGER CONTAINER */}
          <div className="flex items-center gap-2 ml-auto md:ml-0">
            {/* AUTH DESKTOP */}
            {isLoggedIn ? (
              <div className="hidden md:flex items-center gap-2">
                <Button
                  className="text-sm bg-[#1A73E8] hover:bg-[#1558b8] text-white"
                  onClick={() => router.push('/dashboard')}
                >
                  📊 Buka Dashboard
                </Button>
                <Button
                  variant="outline"
                  className="text-sm bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
                  onClick={handleLogout}
                >
                  🔓 Keluar
                </Button>
              </div>
            ) : (
              <Link href="/login" className="hidden md:block">
                <Button className="text-sm bg-[#1A73E8] hover:bg-[#1558b8] text-white">
                  ✨ Masuk / Daftar
                </Button>
              </Link>
            )}

            {/* HAMBURGER MOBILE */}
            <button
              type="button"
              aria-label="Buka menu navigasi"
              className="md:hidden inline-flex items-center justify-center rounded-md p-2 text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-white"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
            >
              <svg
                className="h-5 w-5"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M4 7h16M4 12h16M4 17h16"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                />
              </svg>
            </button>
          </div>
        </div>

        {/* MOBILE MENU DROPDOWN */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 bg-white">
            <div className="px-4 py-3 space-y-2 text-sm text-gray-700">
              <a
                href="#hero"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Beranda
              </a>
              <Link
                href="/pricing"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Harga
              </Link>
              <Link
                href="/about"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Tentang
              </Link>
              <a
                href="#komunitas"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Komunitas
              </a>
              <Link
                href="/faq"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                FAQ
              </Link>
              <Link
                href="/contact"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Contact
              </Link>
              <Link
                href="/terms-and-conditions"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Term &amp; Conditions
              </Link>
              <Link
                href="/disclaimer"
                className="block hover:text-[#1A73E8]"
                onClick={() => setMobileMenuOpen(false)}
              >
                Disclaimer
              </Link>

              <div className="pt-2 border-t border-gray-100 space-y-2">
                {isLoggedIn ? (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false)
                        router.push('/dashboard')
                      }}
                    >
                      🚀 Buka Dashboard
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={handleLogout}
                    >
                      🔓 Keluar
                    </Button>
                  </>
                ) : (
                  <Link
                    href="/login"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Button
                      size="sm"
                      className="w-full bg-[#1A73E8] hover:bg-[#1558b8] text-white"
                    >
                      ✨ Masuk / Daftar
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Announcement Bar */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full flex justify-center bg-[#EAF2FF] border-t border-b border-[#C7DAFF] py-2"
        >
          <p className="text-xs sm:text-sm text-[#1E3A8A] px-4 text-center font-medium">
            🌟 HidupAI adalah pendamping reflektif berbasis Agentic AI. Coba gratis
            hari ini, dan rasakan bedanya dengan AI chat biasa.
          </p>
        </motion.div>
      </header>

      {/* ============================
           CONTENT
      ============================ */}
      <div className="max-w-5xl mx-auto px-6 pt-40 text-center space-y-16">
        {/* HERO */}
        <section id="hero" className="space-y-6">
          <h1 className="text-3xl md:text-5xl font-semibold leading-snug text-[#0E3A7B]">
            Agentic AI yang <span className="text-[#1A73E8]">Memahami Hidupmu</span>,{' '}
            Bukan Sekadar Chatmu
          </h1>

          <p className="text-gray-600 max-w-xl mx-auto text-base md:text-lg leading-relaxed">
            HidupAI adalah pendamping refleksi yang tumbuh bersama tujuan, perasaan,
            dan kebiasaanmu. Ia mengingat jejak hidupmu dan membantu kamu melihat
            pola hidup — bukan hanya menjawab pertanyaan sesaat.
          </p>

          {/* YOUTUBE */}
          <div className="mt-6">
            <div className="rounded-3xl mx-auto shadow-lg border border-gray-200 overflow-hidden max-w-3xl bg-white">
              <iframe
                width="100%"
                height="360"
                className="w-full h-[260px] sm:h-[320px] md:h-[380px]"
                src="https://www.youtube.com/embed/videoseries?list=PLe2y23JJatjEbMMEFXo1P557rEayrYVlF"
                title="Playlist NARA - HidupAI"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>

          {/* CTA BUTTONS */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-6">
            <Link href="/login">
              <Button className="bg-[#1A73E8] hover:bg-[#1558b8] text-white text-sm px-6 py-3 rounded-xl shadow-md">
                ✨ Coba Gratis Sekarang
              </Button>
            </Link>
            <Link href="/pricing">
              <Button
                variant="outline"
                className="text-sm px-6 py-3 border-[#1A73E8] text-[#1A73E8] rounded-xl bg-white hover:bg-[#E8F1FF]"
              >
                💎 Lihat Paket Premium
              </Button>
            </Link>
          </div>

          {/* HOW IT WORKS */}
          <div className="mt-10 grid gap-4 md:grid-cols-3 text-left text-xs sm:text-sm">
            <div className="rounded-2xl bg-white/90 border border-gray-200 p-4">
              <p className="text-[11px] font-semibold text-blue-700 mb-1">
                LANGKAH 1
              </p>
              <h3 className="font-semibold text-gray-900 mb-1">
                Ceritakan Kondisi Hidupmu
              </h3>
              <p className="text-gray-600">
                Daftar, lalu isi refleksi singkat di onboarding. HidupAI mulai
                mengenali konteks, tujuan, dan pola yang penting buatmu.
              </p>
            </div>
            <div className="rounded-2xl bg-white/90 border border-gray-200 p-4">
              <p className="text-[11px] font-semibold text-blue-700 mb-1">
                LANGKAH 2
              </p>
              <h3 className="font-semibold text-gray-900 mb-1">
                Ngobrol dan Refleksi Rutin
              </h3>
              <p className="text-gray-600">
                Gunakan chat untuk eksplorasi pikiran &amp; emosi. HidupAI mengingat
                percakapan substansial untuk jadi dasar insight.
              </p>
            </div>
            <div className="rounded-2xl bg-white/90 border border-gray-200 p-4">
              <p className="text-[11px] font-semibold text-blue-700 mb-1">
                LANGKAH 3
              </p>
              <h3 className="font-semibold text-gray-900 mb-1">
                Lihat Pola di Dashboard
              </h3>
              <p className="text-gray-600">
                Pantau LifeRank, kebiasaan yang tercatat, dan highlight perjalananmu
                langsung dari dashboard reflektif.
              </p>
            </div>
          </div>
        </section>

        {/* FITUR */}
        <section id="fitur" className="space-y-4 text-left">
          <h2 className="text-lg md:text-xl font-semibold text-[#0E3A7B] text-center">
            Fitur HidupAI yang Sudah Bisa Kamu Gunakan
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 max-w-xl mx-auto text-center">
            Semua fitur di bawah ini sudah aktif di aplikasi dan terhubung dengan
            satu sama lain lewat mesin Agentic AI HidupAI.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
            {[
              {
                icon: '💬',
                title: 'Agentic AI Chat',
                desc: 'Ngobrol dengan AI yang mengingat tujuan dan konteks hidupmu, bukan hanya menjawab sekali lalu lupa.',
              },
              {
                icon: '🧭',
                title: 'LifeRank',
                desc: 'Ringkasan sederhana tentang ritme kebiasaan dan interaksimu dengan HidupAI, langsung di dashboard.',
              },
              {
                icon: '📝',
                title: 'Catat Kebiasaan',
                desc: 'Tandai satu kebiasaan penting per hari dari onboarding — dipakai sebagai dasar membaca konsistensi.',
              },
              {
                icon: '🧠',
                title: 'Memory Panel',
                desc: 'Panel untuk melihat highlight tentang dirimu (tujuan, tema penting) agar pendampingan makin relevan.',
              },
              {
                icon: '📊',
                title: 'Dashboard Reflektif',
                desc: 'Satu tempat untuk melihat LifeRank, kebiasaan yang tercatat, dan insight singkat perjalananmu.',
              },
              {
                icon: '🔒',
                title: 'Login & Profil Personal',
                desc: 'Semua progres disimpan berdasarkan akunmu, sehingga pengalaman tetap personal dan konsisten.',
              },
            ].map(({ icon, title, desc }, i) => (
              <div
                key={i}
                className="bg-white shadow-sm border border-gray-200 rounded-2xl p-4 text-sm hover:shadow-md hover:-translate-y-[2px] transition"
              >
                <p className="mb-1 text-base">
                  {icon} <strong>{title}</strong>
                </p>
                <p className="text-xs text-gray-600 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* COMPARISON */}
        <section className="mt-10">
          <h2 className="text-lg md:text-xl font-semibold text-[#1A73E8] mb-2 text-center">
            🧠 Apa yang Membuat HidupAI Berbeda dari AI Chat Biasa?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 text-left text-sm">
            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
              <h3 className="font-semibold text-gray-800 mb-1">
                AI Generik pada Umumnya
              </h3>
              <ul className="list-disc list-inside text-gray-600 mt-2 space-y-1">
                <li>Jawaban cepat &amp; informatif, tapi putus di percakapan itu saja.</li>
                <li>Fokus ke produktivitas teknis (tugas, dokumen, coding).</li>
                <li>Tidak menyimpan konteks emosional atau perjalanan hidupmu.</li>
              </ul>
            </div>

            <div className="bg-[#E8F1FF] p-5 rounded-2xl border border-[#C7DAFF] shadow-md">
              <h3 className="font-semibold text-[#0E3A7B] mb-3">
                ✅ HidupAI — Agentic AI yang Tumbuh Bersamamu
              </h3>
              <div className="space-y-2 text-[#1A3F7A] text-sm">
                <div className="flex items-start gap-2">
                  <span className="mt-0.5">🎯</span>
                  <p>
                    Menggunakan percakapan, kebiasaan, dan tujuanmu sebagai sinyal utama
                    untuk memberi refleksi yang lebih tepat.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="mt-0.5">📊</span>
                  <p>
                    Menghubungkan apa yang kamu ceritakan dengan LifeRank dan tampilan
                    di dashboard reflektif.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="mt-0.5">🕰️</span>
                  <p>
                    Dirancang untuk menemani perjalanan jangka panjang, bukan hanya
                    menjawab pertanyaan sekali lalu selesai.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* KOMUNITAS */}
        <section id="komunitas" className="mt-20">
          <h2 className="text-lg md:text-xl font-semibold text-[#1A73E8]">
            🌱 Komunitas Generasi AI Reflektif
          </h2>
          <p className="text-gray-600 max-w-xl mx-auto text-sm mt-2 leading-relaxed">
            HidupAI bukan sekadar tools — ini adalah ruang bertumbuh bersama orang-orang
            yang ingin hidup lebih sadar, tenang, dan terarah di era AI.
          </p>
          <Link href="#" target="_blank">
            <Button className="mt-5 bg-[#1A73E8] text-white hover:bg-[#1558b8] text-sm px-6 py-3 rounded-xl">
              💬 Join Waitlist Komunitas
            </Button>
          </Link>
        </section>

        {/* VISUAL */}
        <section className="mt-20">
          <Image
            src="/images/visual-hidupai-productivity.jpeg"
            alt="Visual HidupAI Productivity"
            width={900}
            height={800}
            className="rounded-2xl shadow-lg border border-gray-200 mx-auto"
          />
        </section>

        {/* CAROUSEL */}
        <section className="mt-20">
          <h2 className="text-xl font-semibold text-[#0E3A7B] mb-4">
            🔍 Jejak Nyata HidupAI: Motivasi, Refleksi, dan Transformasi Personal
          </h2>
          <div className="relative w-full max-w-3xl mx-auto overflow-hidden rounded-2xl shadow-lg border border-gray-200 bg-white">
            <AnimatePresence mode="wait">
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -40 }}
                transition={{ duration: 0.4 }}
              >
                <Image
                  src={carouselSlides[index].src}
                  alt={carouselSlides[index].alt}
                  width={900}
                  height={600}
                  className="w-full object-cover rounded-2xl"
                />
              </motion.div>
            </AnimatePresence>

            <div className="absolute inset-0 flex justify-between items-center px-3">
              <button
                onClick={handlePrev}
                className="text-[#1A73E8] text-xl font-bold bg-white/85 px-3 py-1 rounded-full shadow-sm hover:bg-white"
                aria-label="Sebelumnya"
              >
                ‹
              </button>
              <button
                onClick={handleNext}
                className="text-[#1A73E8] text-xl font-bold bg-white/85 px-3 py-1 rounded-full shadow-sm hover:bg-white"
                aria-label="Berikutnya"
              >
                ›
              </button>
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <Link href="/login">
              <Button className="bg-[#1A73E8] text-white text-sm px-6 py-3 rounded-xl shadow-md w-full sm:w-auto hover:bg-[#1558b8]">
                ✨ Coba HidupAI dan Temukan Versi Terbaik Dirimu
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </main>
  )
}
