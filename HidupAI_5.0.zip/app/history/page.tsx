'use client'

import { useEffect, useState, useCallback } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { useRouter } from 'next/navigation'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

interface Order {
  order_id: string
  plan_type: string
  amount: number
  status: string
  paid_at?: string
  created_at: string
  payment_method?: string
  va_number?: string
}

export default function HistoryPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClientComponentClient()
  const router = useRouter()

  const fetchOrders = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession()
    const token = session?.access_token
    const email = session?.user?.email

    if (!token || !email) return router.push('/login')

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('email', email)
      .in('status', ['settlement', 'capture']) // ✅ hanya transaksi sukses
      .order('created_at', { ascending: false })

    if (!error && data) {
      setOrders(data)
    }
    setLoading(false)
  }, [supabase, router])

  useEffect(() => {
    fetchOrders()
  }, [fetchOrders])

  return (
    <main className="max-w-2xl mx-auto py-10 px-4">
      <h1 className="text-2xl font-bold mb-6">📜 Riwayat Pembayaran</h1>
      {loading ? (
        <p className="text-sm text-gray-500">Memuat data...</p>
      ) : orders.length === 0 ? (
        <p className="text-sm text-gray-500">Belum ada transaksi yang berhasil.</p>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <Card key={order.order_id} className="border rounded-xl shadow-sm hover:shadow-md transition">
              <CardContent className="p-4 space-y-2">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm font-medium text-gray-800">Order ID: {order.order_id}</p>
                  <Badge variant="success">Berhasil ✅</Badge>
                </div>
                <p className="text-sm text-gray-700">
                  Paket: <b className="capitalize">{order.plan_type}</b>
                </p>
                <p className="text-sm text-gray-700">
                  Jumlah: <b>Rp{order.amount.toLocaleString('id-ID')}</b>
                </p>
                {order.payment_method && (
                  <p className="text-sm text-gray-700">
                    Metode: <b>{order.payment_method}</b>
                  </p>
                )}
                {order.va_number && (
                  <p className="text-sm text-gray-700">
                    Nomor VA: <span className="font-mono tracking-wide">{order.va_number}</span>
                  </p>
                )}
                {order.paid_at && (
                  <p className="text-xs text-gray-500 mt-1">
                    Dibayar: {new Date(order.paid_at).toLocaleString('id-ID')}
                  </p>
                )}

                <div className="pt-3 flex gap-2 flex-wrap text-xs">
                  <a
                    href={`/api/invoice?order_id=${order.order_id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1 bg-blue-100 border border-blue-400 text-blue-800 rounded hover:bg-blue-200 transition inline-block"
                  >
                    📄 Bukti Transaksi
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </main>
  )
}
