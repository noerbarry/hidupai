// File: app/terms-and-conditions/page.tsx
'use client';

import Link from 'next/link';

export default function TermsAndConditionsPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-blue-50/60 to-blue-100/40 text-gray-800 pt-28 pb-16">
      <div className="max-w-4xl mx-auto px-6 space-y-10">
        {/* ====== HEADER / HERO ====== */}
        <header className="space-y-6">
          {/* Breadcrumb + Chip */}
          <div className="flex items-center justify-between gap-3 text-xs sm:text-sm">
            <Link
              href="/"
              className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
            >
              ← Kembali ke Beranda
            </Link>

            <span className="inline-flex items-center rounded-full bg-blue-50 border border-blue-100 px-3 py-1 font-medium text-blue-700">
              Kebijakan Pengembalian Dana
            </span>
          </div>

          {/* Title + Intro */}
          <div className="text-center space-y-3">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
              📜 Kebijakan Pengembalian Dana HidupAI
            </h1>
            <p className="text-sm sm:text-base text-gray-600 max-w-2xl mx-auto leading-relaxed">
              HidupAI adalah layanan digital berbasis langganan. Halaman ini
              menjelaskan bagaimana kebijakan pengembalian dana (*refund policy*)
              kami berlaku untuk akses Premium/Pro yang kamu beli.
            </p>
          </div>

          {/* Ringkasan Singkat */}
          <div className="rounded-2xl bg-white border border-blue-100 shadow-sm p-4 sm:p-5 text-xs sm:text-sm text-gray-700 space-y-1.5">
            <p className="font-semibold text-slate-900">
              Ringkasnya, kebijakan kami:
            </p>
            <ul className="list-disc list-inside space-y-1">
              <li>
                Semua transaksi Premium/Pro bersifat <strong>final</strong>.
              </li>
              <li>
                Produk digital langsung aktif setelah pembayaran,{' '}
                <strong>tanpa pengembalian dana</strong>.
              </li>
              <li>
                Kalau ada kendala teknis, tim HidupAI akan membantu memulihkan
                akses, bukan refund tunai.
              </li>
            </ul>
          </div>
        </header>

        {/* ====== MAIN CONTENT ====== */}
        <section className="space-y-6 text-sm sm:text-base text-gray-700">
          {/* 1. Transaksi Final */}
          <div className="rounded-2xl bg-white border border-gray-200 shadow-sm p-5 sm:p-6 space-y-2">
            <h2 className="font-semibold text-lg text-slate-900">
              1. Transaksi Bersifat Final
            </h2>
            <p className="leading-relaxed">
              Semua transaksi yang dilakukan pada platform HidupAI bersifat{' '}
              <strong>final</strong> dan{' '}
              <strong>tidak dapat dikembalikan</strong>. Setelah pembayaran
              untuk layanan Premium atau Pro berhasil diproses, akses ke fitur
              digital akan langsung diaktifkan pada akunmu, dan tidak ada
              pengembalian dana yang diproses setelah itu.
            </p>
          </div>

          {/* 2. Produk Digital */}
          <div className="rounded-2xl bg-white border border-gray-200 shadow-sm p-5 sm:p-6 space-y-2">
            <h2 className="font-semibold text-lg text-slate-900">
              2. Produk Digital &amp; Akses Langsung
            </h2>
            <p className="leading-relaxed">
              HidupAI menyediakan <strong>produk digital</strong> yang dapat
              diakses segera setelah pembayaran berhasil. Karena sifatnya yang
              langsung aktif dan tidak dapat “dikembalikan” seperti barang
              fisik, kami <strong>tidak menyediakan pengembalian dana</strong>{' '}
              termasuk apabila:
            </p>
            <ul className="mt-2 space-y-1 list-disc list-inside">
              <li>Kamu berubah pikiran setelah melakukan pembelian.</li>
              <li>
                Kamu tidak lagi menggunakan layanan selama periode langganan.
              </li>
              <li>
                Kamu lupa membatalkan sebelum perpanjangan (jika ke depan ada
                fitur perpanjangan otomatis).
              </li>
            </ul>
          </div>

          {/* 3. Uji Coba Sebelum Membeli */}
          <div className="rounded-2xl bg-white border border-gray-200 shadow-sm p-5 sm:p-6 space-y-2">
            <h2 className="font-semibold text-lg text-slate-900">
              3. Uji Coba &amp; Eksplorasi Sebelum Membeli
            </h2>
            <p className="leading-relaxed">
              Untuk membantumu mengambil keputusan dengan lebih tenang, HidupAI
              menyediakan <strong>akses gratis</strong> dengan kuota percakapan
              harian. Gunakan fase ini untuk:
            </p>
            <ul className="mt-2 space-y-1 list-disc list-inside">
              <li>Mengenal cara kerja HidupAI dan gaya komunikasinya.</li>
              <li>
                Menguji apakah ritme refleksi dan fitur yang ada cocok dengan
                kebutuhanmu.
              </li>
              <li>
                Memastikan bahwa kamu benar-benar siap memakai versi
                Premium/Pro.
              </li>
            </ul>
            <p className="mt-2 text-xs text-gray-500">
              Dengan melakukan pembayaran, kamu menyetujui bahwa sudah
              memahami cara kerja layanan dan risiko penggunaan produk digital.
            </p>
          </div>

          {/* 4. Masalah Teknis */}
          <div className="rounded-2xl bg-white border border-gray-200 shadow-sm p-5 sm:p-6 space-y-2">
            <h2 className="font-semibold text-lg text-slate-900">
              4. Masalah Teknis &amp; Akses Fitur
            </h2>
            <p className="leading-relaxed">
              Jika kamu mengalami <strong>masalah teknis</strong> setelah
              pembayaran (misalnya fitur Premium tidak aktif, atau terjadi
              kendala akses yang jelas berasal dari sisi sistem kami), tim
              HidupAI akan:
            </p>
            <ul className="mt-2 space-y-1 list-disc list-inside">
              <li>
                Membantu memverifikasi status pembayaran dan aktivasi akun.
              </li>
              <li>Mengupayakan perbaikan teknis secepat mungkin.</li>
              <li>
                Memberikan panduan langkah demi langkah jika diperlukan.
              </li>
            </ul>
            <p className="mt-2 text-xs text-gray-500">
              Dalam kasus tertentu yang sangat spesifik dan terbatas, HidupAI
              dapat mempertimbangkan solusi alternatif non-tunai (misalnya
              perpanjangan masa akses), sesuai kebijakan internal.
            </p>
          </div>

          {/* 5. Kontak & Klarifikasi */}
          <div className="rounded-2xl bg-white border border-gray-200 shadow-sm p-5 sm:p-6 space-y-2">
            <h2 className="font-semibold text-lg text-slate-900">
              5. Pertanyaan &amp; Klarifikasi Lebih Lanjut
            </h2>
            <p className="leading-relaxed">
              Jika kamu merasa ada hal yang belum jelas terkait kebijakan
              pengembalian dana ini, atau ingin mendiskusikan situasi spesifik
              yang kamu alami, kamu dapat menghubungi tim HidupAI melalui
              halaman{' '}
              <Link href="/contact" className="text-blue-600 underline">
                Contact
              </Link>
              .
            </p>
            <p className="mt-2 text-xs text-gray-500">
              Kami menghargai setiap masukan dan akan berusaha menjaga
              keseimbangan antara kejelasan kebijakan bisnis dan rasa keadilan
              bagi pengguna.
            </p>
          </div>
        </section>

        {/* ====== FOOTER LINK ====== */}
        <div className="text-center mt-4">
          <Link
            href="/"
            className="text-sm text-blue-600 underline hover:text-blue-800"
          >
            ← Kembali ke Beranda HidupAI
          </Link>
        </div>
      </div>
    </main>
  );
}
