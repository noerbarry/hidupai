// File: app/maintenance/page.tsx

export default function MaintenancePage() {
    return (
      <div className="min-h-screen flex items-center justify-center text-center bg-yellow-50 px-6">
        <div>
          <h1 className="text-3xl font-bold text-yellow-800 mb-2">🔧 HidupAI Sedang Maintenance</h1>
          <p className="text-yellow-700 max-w-md mx-auto">
            Kami sedang melakukan peningkatan sistem untuk memberikan pengalaman terbaik bagi kamu.
            Mohon tunggu sebentar ya... 🚀
          </p>
        </div>
      </div>
    )
  }
  