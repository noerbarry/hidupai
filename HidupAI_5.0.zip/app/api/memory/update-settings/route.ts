// File: app/api/memory/update-settings/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

type UpdateSettingsBody = {
  email?: string;
  mode?: string | null;
  goal?: string | null;
};

export async function POST(req: Request) {
  try {
    // Supabase client berbasis cookies (session user)
    const supabase = createRouteHandlerClient({ cookies });

    const body = (await req.json()) as UpdateSettingsBody;
    const { email, mode = null, goal = null } = body;

    if (!email) {
      return NextResponse.json(
        { error: 'Email tidak ditemukan' },
        { status: 400 }
      );
    }

    // Cek apakah preferensi sudah ada
    const {
      data: existing,
      error: fetchError,
    } = await supabase
      .from('agentic_preferences')
      .select('email')
      .eq('email', email)
      .single();

    // PGRST116 = "No rows found" → bukan error fatal
    if (fetchError && fetchError.code !== 'PGRST116') {
      console.error('[update-settings] fetchError:', fetchError);
      return NextResponse.json(
        { error: fetchError.message },
        { status: 500 }
      );
    }

    // Susun payload update / insert
    const updates: {
      email: string;
      mode?: string | null;
      goal?: string | null;
    } = { email };

    if (mode !== null) updates.mode = mode;
    if (goal !== null) updates.goal = goal;

    let upsertError = null;

    if (existing) {
      const { error } = await supabase
        .from('agentic_preferences')
        .update(updates)
        .eq('email', email);
      upsertError = error;
    } else {
      const { error } = await supabase
        .from('agentic_preferences')
        .insert(updates);
      upsertError = error;
    }

    if (upsertError) {
      console.error('[update-settings] upsert error:', upsertError);
      return NextResponse.json(
        { error: upsertError.message },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Terjadi kesalahan internal.';
    console.error('[update-settings] unexpected error:', err);
    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
