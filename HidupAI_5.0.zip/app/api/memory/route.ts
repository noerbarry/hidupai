// File: app/api/memory/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

// Route ini hanya dipakai dari frontend yang sudah login,
// jadi kita pakai service role langsung tanpa cookies auth helper.
export const dynamic = 'force-dynamic'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const email = searchParams.get('email')

    if (!email) {
      return NextResponse.json(
        { error: '❌ Email tidak disediakan.' },
        { status: 400 }
      )
    }

    // 1) Ambil user by email
    const {
      data: user,
      error: userError,
    } = await supabase
      .from('users')
      .select('id, preferred_mode, weekly_goal')
      .eq('email', email)
      .single()

    if (userError || !user) {
      console.error('[memory] user lookup error:', userError)
      return NextResponse.json(
        { error: '❌ User tidak ditemukan.' },
        { status: 404 }
      )
    }

    // 2) Ambil memori long-term by user_id
    const {
      data: memories,
      error: memoryError,
    } = await supabase
      .from('long_term_memories')
      .select('id, content')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true })

    if (memoryError) {
      console.error('[memory] query error:', memoryError)
      return NextResponse.json(
        {
          error: '❌ Gagal mengambil memori.',
          detail: memoryError.message,
        },
        { status: 500 }
      )
    }

    // 3) Response sukses ke frontend
    return NextResponse.json(
      {
        memory: memories || [],
        mode: user.preferred_mode || '',
        goal: user.weekly_goal || '',
      },
      { status: 200 }
    )
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : 'Unknown error'

    console.error('[memory] unexpected error:', err)
    return NextResponse.json(
      {
        error: '❌ Terjadi kesalahan internal.',
        detail: message,
      },
      { status: 500 }
    )
  }
}
