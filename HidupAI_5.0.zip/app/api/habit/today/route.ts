import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const email = searchParams.get('email')

  if (!email) {
    return NextResponse.json({ success: false, error: 'Email dibutuhkan.' }, { status: 400 })
  }

  const today = new Date().toISOString().split('T')[0]

  const { data: habits, error: habitError } = await supabase
    .from('habits')
    .select('id, name')
    .eq('email', email)

  if (habitError) {
    return NextResponse.json({ success: false, error: 'Gagal mengambil habits' }, { status: 500 })
  }

  const { data: logs } = await supabase
    .from('habit_logs')
    .select('habit_id')
    .eq('email', email)
    .eq('date', today)

  const habitIdsLogged = new Set(logs?.map(log => log.habit_id))

  const result = habits.map(habit => ({
    id: habit.id,
    name: habit.name,
    logged_today: habitIdsLogged.has(habit.id)
  }))

  return NextResponse.json(result)
}
