// File: app/api/habit/log/route.ts
// FINAL — kompatibel dengan tabel habit_logs (habit_name) & tidak perlu email di body

import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

type HabitLogPayload = {
  description?: string;
  habit_name?: string;
  email?: string;
};

type SupabaseAuthUserResponse = {
  email?: string;
};

function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === 'string') return error;
  try {
    return JSON.stringify(error);
  } catch {
    return 'Unknown error';
  }
}

export async function POST(req: NextRequest) {
  try {
    const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      return NextResponse.json(
        { error: 'Konfigurasi Supabase belum lengkap.' },
        { status: 500 }
      );
    }

    // ----- Ambil body (aman dari error & tanpa any) -----
    const body = (await req.json().catch(() => null)) as HabitLogPayload | null;

    // habit_name dari frontend (di code onboarding: description = habit_name user input)
    const habitName = (
      body?.description ||
      body?.habit_name ||
      ''
    ).trim();

    // Email: boleh dikirim dari body, tapi kalau kosong akan diambil dari access token
    let email = (body?.email || '').trim();

    // Kalau email kosong, coba ambil dari Authorization Bearer token (Supabase access token)
    if (!email) {
      const authHeader =
        req.headers.get('authorization') || req.headers.get('Authorization');

      if (authHeader?.startsWith('Bearer ')) {
        const accessToken = authHeader.slice('Bearer '.length).trim();

        try {
          const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
            method: 'GET',
            headers: {
              apikey: SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${accessToken}`,
            },
          });

          if (userRes.ok) {
            const userData =
              (await userRes.json()) as SupabaseAuthUserResponse;
            email = (userData.email || '').trim();
          } else {
            const text = await userRes.text();
            console.error('[habit/log] auth user error:', text);
          }
        } catch (err: unknown) {
          console.error(
            '[habit/log] gagal ambil email dari token:',
            err
          );
        }
      }
    }

    if (!email) {
      return NextResponse.json(
        { error: 'Email tidak ditemukan (session tidak valid).' },
        { status: 401 }
      );
    }

    if (!habitName) {
      return NextResponse.json(
        { error: 'Nama kebiasaan tidak boleh kosong.' },
        { status: 400 }
      );
    }

    // ----- Insert ke habit_logs -----
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

    const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/habit_logs`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal',
      },
      body: JSON.stringify({
        date: today,
        completed: true,
        email,
        habit_name: habitName, // kolom yang benar di tabel
      }),
    });

    if (!insertRes.ok) {
      const text = await insertRes.text();
      console.error('[habit/log] insert error:', text);
      return NextResponse.json(
        { error: 'Gagal mencatat kebiasaan.' },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { success: true, message: 'Kebiasaan hari ini tercatat.' },
      { status: 200 }
    );
  } catch (err: unknown) {
    console.error('[habit/log] fatal error:', err);
    return NextResponse.json(
      {
        error: 'Terjadi kesalahan internal.',
        detail: getErrorMessage(err),
      },
      { status: 500 }
    );
  }
}
