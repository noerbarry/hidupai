import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

function getRankLabel(score: number): string {
  if (score >= 80) return 'Inspired Leader'
  if (score >= 50) return 'Life Changer'
  if (score >= 21) return 'Habit Builder'
  return 'New Seeker'
}

export async function GET(req: NextRequest) {
  const email = req.nextUrl.searchParams.get('email')
  if (!email) {
    return NextResponse.json({ success: false, message: 'Email wajib diisi.' }, { status: 400 })
  }

  // 🔍 Ambil data user
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id, goal, last_question, last_response, usage_today, referral_points')
    .eq('email', email)
    .maybeSingle()

  if (userError) {
    console.error('❌ Gagal ambil data user:', userError.message)
    return NextResponse.json({ success: false, message: 'Gagal ambil data user.' }, { status: 500 })
  }

  if (!user) {
    return NextResponse.json({ success: false, message: 'User tidak ditemukan.' }, { status: 404 })
  }

  // 📊 Ambil habit logs
  const { data: habits, error: habitError } = await supabase
    .from('habit_logs')
    .select('date')
    .eq('email', email)

  if (habitError) {
    console.error('❌ Gagal ambil habit logs:', habitError.message)
    return NextResponse.json({ success: false, message: 'Gagal ambil habit logs.' }, { status: 500 })
  }

  const habitDays = new Set(
    habits?.map(h => new Date(h.date).toDateString())
  ).size

  const hasGoal = Boolean(user.goal)

  // ✅ Revisi: gunakan last_question & last_response
  const usedChat =
    typeof user.last_question === 'string' &&
    typeof user.last_response === 'string' &&
    user.last_response.length >= 100

  const hasExported = usedChat // misalnya ekspor PDF terjadi setelah obrolan substansial
  const hasReferral = (user.referral_points || 0) >= 1

  // 🧮 Skor
  let score = 0
  if (habitDays >= 3) score += 40
  if (hasGoal) score += 10
  if (usedChat) score += 20
  if (hasExported) score += 15
  if (hasReferral) score += 15

  const rank = getRankLabel(score)

  return NextResponse.json({
    success: true,
    email,
    score,
    rank,
    habitDays,
    usedChat,
    hasGoal,
    hasExported,
    referralPoints: user.referral_points || 0
  })
}
