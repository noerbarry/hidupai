// FINAL PRODUCTION — Weekly Coaching (OpenAI + Gemini fallback)
// Lokasi: app/api/agentic-chat/weekly-coaching/route.ts

import { OpenAIStream, StreamingTextResponse } from 'ai';
import { NextResponse } from 'next/server';

export const runtime = 'edge';

/* ============================================================
 *   Tipe aman tanpa "any"
 * ========================================================== */

type LongTermMemory = unknown;

interface SupabaseUserRow {
  goal?: string | null;
  preferred_mode?: string | null;
  long_term_memory?: LongTermMemory;
  is_premium?: boolean | null;
}

interface GeminiPart {
  text?: string;
}

interface GeminiCandidate {
  content?: {
    parts?: GeminiPart[];
  };
}

interface GeminiResponse {
  candidates?: GeminiCandidate[];
}

/* ============================================================
 *  Constants
 * ========================================================== */

const MAX_MEMORY_CHARS = 4000;

/* ============================================================
 *   Helper: Ringkas memori
 * ========================================================== */

function buildMemorySnippet(rawMemory: LongTermMemory): string {
  if (!rawMemory) return 'Belum ada memori.';

  let asString = '';

  try {
    asString =
      typeof rawMemory === 'string'
        ? rawMemory
        : JSON.stringify(rawMemory, null, 2);
  } catch {
    asString = String(rawMemory);
  }

  if (asString.length <= MAX_MEMORY_CHARS) return asString;

  const tail = asString.slice(-MAX_MEMORY_CHARS);

  return (
    '[[Ringkasan memori dipotong agar muat konteks token. Hanya bagian terbaru yang digunakan.]]\n' +
    tail
  );
}

/* ============================================================
 *   Helper: Build coaching prompt
 * ========================================================== */

function buildCoachingPrompt(user: SupabaseUserRow): string {
  const memoryFormatted = buildMemorySnippet(user.long_term_memory);

  return `
Kamu adalah pelatih hidup (Life Coach AI) yang memahami pengguna secara mendalam.
Gunakan informasi berikut untuk membuat refleksi mingguan:

- Tujuan Hidup Pengguna: ${user.goal || 'Belum diisi'}
- Mode Reflektif: ${user.preferred_mode || 'default'}
- Memori Jangka Panjang Pengguna (ringkas):
${memoryFormatted}

Tugasmu:
1. Tulis refleksi mingguan yang menyentuh, seperti catatan dari seorang mentor.
2. Berikan tepat 2 pertanyaan reflektif personal untuk minggu berikutnya.
3. Jangan menyapa atau menyebut nama pengguna.
4. Jawaban maksimal sekitar 700–900 kata.

Gunakan gaya bahasa empatik, mendalam, dan penuh kesadaran.
`.trim();
}

/* ============================================================
 *   Helper: OpenAI (Streaming)
 * ========================================================== */

async function callOpenAI(
  prompt: string,
  isPremium: boolean | null
): Promise<StreamingTextResponse | null> {
  const { OPENAI_API_KEY } = process.env;

  if (!OPENAI_API_KEY) {
    console.error('[Weekly Coaching] OPENAI_API_KEY belum di-set');
    return null;
  }

  const model = isPremium ? 'gpt-4.1-mini' : 'gpt-4o-mini';

  const aiResponse = await fetch(
    'https://api.openai.com/v1/chat/completions',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        stream: true,
        messages: [
          {
            role: 'system',
            content: 'Kamu adalah Life Coach AI reflektif dari HidupAI.',
          },
          { role: 'user', content: prompt },
        ],
      }),
    }
  );

  if (!aiResponse.ok) {
    const text = await aiResponse.text();
    console.error('[Weekly Coaching] OpenAI error:', aiResponse.status, text);

    if (aiResponse.status === 400 && text.includes('context length')) {
      return null; // fallback ke Gemini
    }

    throw new Error('OpenAI API gagal');
  }

  const stream = OpenAIStream(aiResponse);
  return new StreamingTextResponse(stream);
}

/* ============================================================
 *   Helper: Gemini Fallback (non-stream → dibungkus stream)
 * ========================================================== */

async function callGemini(prompt: string): Promise<StreamingTextResponse> {
  const { GEMINI_API_KEY } = process.env;

  if (!GEMINI_API_KEY) {
    console.error('[Weekly Coaching] GEMINI_API_KEY belum di-set');
    throw new Error('Gemini API key tidak tersedia');
  }

  const model = 'gemini-1.5-flash-latest';
  const endpoint = `https://generativelanguage.googleapis.com/v1/models/${model}:generateContent?key=${GEMINI_API_KEY}`;

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [
        {
          role: 'user',
          parts: [{ text: prompt }],
        },
      ],
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    console.error('[Gemini Error]', text);
    throw new Error('Gemini API gagal');
  }

  const data = (await res.json()) as GeminiResponse;

  const text =
    data?.candidates?.[0]?.content?.parts
      ?.map((p: GeminiPart) => p.text ?? '')
      .join(' ')
      .trim() || 'Gagal menghasilkan refleksi dari Gemini.';

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(encoder.encode(text));
      controller.close();
    },
  });

  return new StreamingTextResponse(stream);
}

/* ============================================================
 *   Route Handler
 * ========================================================== */

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);

  const email =
    typeof body?.email === 'string' ? body.email : undefined;

  if (!email) {
    return NextResponse.json(
      { error: 'Email diperlukan' },
      { status: 400 }
    );
  }

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    console.error('[Weekly Coaching] Supabase env belum lengkap');
    return NextResponse.json(
      { error: 'Konfigurasi server belum lengkap.' },
      { status: 500 }
    );
  }

  try {
    /* ============================================================
     *   Ambil data user via Supabase (REST)
     * ========================================================== */

    const userRes = await fetch(
      `${SUPABASE_URL}/rest/v1/users?select=goal,preferred_mode,long_term_memory,is_premium&email=eq.${encodeURIComponent(
        email
      )}`,
      {
        headers: {
          apikey: SUPABASE_SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        },
        cache: 'no-store',
      }
    );

    if (!userRes.ok) {
      const txt = await userRes.text();
      console.error('[Weekly Coaching] Supabase user error:', txt);
      return NextResponse.json(
        { error: 'Gagal mengambil data pengguna.' },
        { status: 500 }
      );
    }

    const users = (await userRes.json()) as SupabaseUserRow[];
    const user = users[0];

    if (!user) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      );
    }

    /* ============================================================
     *   Build prompt + panggil model
     * ========================================================== */

    const prompt = buildCoachingPrompt(user);

    // 1️⃣ OpenAI
    try {
      const openAiResp = await callOpenAI(
        prompt,
        user.is_premium ?? false
      );
      if (openAiResp) return openAiResp;
    } catch (error) {
      console.error(
        '[Weekly Coaching] OpenAI gagal → fallback ke Gemini:',
        error
      );
    }

    // 2️⃣ Gemini Fallback
    const gemResp = await callGemini(prompt);
    return gemResp;
  } catch (error) {
    console.error('[Weekly Coaching Fatal Error]', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghasilkan refleksi.' },
      { status: 500 }
    );
  }
}
