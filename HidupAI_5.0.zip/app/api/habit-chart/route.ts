import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function GET() {
  const supabase = createRouteHandlerClient({ cookies })
  const {
    data: { session },
  } = await supabase.auth.getSession()

  const email = session?.user?.email
  if (!email) {
    return NextResponse.json({ stats: [] }, { status: 401 })
  }

  const { data, error } = await supabase
    .from('habit_logs')
    .select('day, total')
    .eq('user_email', email)
    .order('day', { ascending: true })

  if (error) {
    console.error('Error fetching habit stats:', error)
    return NextResponse.json({ stats: [] }, { status: 500 })
  }

  return NextResponse.json({ stats: data || [] })
}
