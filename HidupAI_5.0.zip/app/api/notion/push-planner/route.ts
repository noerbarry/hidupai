import { NextResponse } from 'next/server'

const NOTION_TOKEN = process.env.NOTION_API_KEY!
const PAGE_ID = process.env.NOTION_PAGE_ID!

export async function POST(req: Request) {
  try {
    const { planner } = await req.json()

    if (!planner) {
      console.warn('⚠️ Planner kosong dari body')
      return NextResponse.json({ success: false, error: 'Planner kosong.' }, { status: 400 })
    }

    const blocks = planner.split('\n').map((line: string) => ({
      object: 'block',
      type: 'paragraph',
      paragraph: {
        rich_text: [
          {
            type: 'text',
            text: { content: line || ' ' },
          },
        ],
      },
    }))

    console.log('📦 Siap push ke Notion...')
    console.log('🔑 TOKEN Prefix:', NOTION_TOKEN.slice(0, 10) + '...')
    console.log('🧱 Total Blocks:', blocks.length)
    console.log('📄 PAGE_ID:', PAGE_ID)

    const res = await fetch(`https://api.notion.com/v1/blocks/${PAGE_ID}/children`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({ children: blocks }),
    })

    const result = await res.json()

    if (!res.ok) {
      console.error('❌ Push gagal:', result)
      return NextResponse.json({ success: false, error: 'Gagal push ke Notion.' }, { status: 500 })
    }

    console.log('✅ Push ke Notion berhasil')
    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('❌ ERROR tak terduga:', err)
    return NextResponse.json({ success: false, error: 'Unexpected error.' }, { status: 500 })
  }
}
