// File: app/api/weekly-reflection/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

// GET: Ambil refleksi mingguan terakhir user
export async function GET(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { searchParams } = new URL(req.url)
  const email = searchParams.get('email')

  if (!email) {
    return NextResponse.json({ error: 'Email tidak disediakan' }, { status: 400 })
  }

  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
  }

  const { data: reflection, error: reflectionError } = await supabase
    .from('weekly_reflections')
    .select('content')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .single()

  if (reflectionError || !reflection) {
    return NextResponse.json({ reflection: '' }) // Tidak ada respon
  }

  return NextResponse.json({ reflection: reflection.content })
}

// POST: Buat refleksi mingguan baru dan simpan
export async function POST(req: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { email } = await req.json()

  if (!email) {
    return NextResponse.json({ error: 'Email wajib disertakan' }, { status: 400 })
  }

  // Ambil user dan preferensi
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id, preferred_mode, weekly_goal')
    .eq('email', email)
    .single()

  if (userError || !user) {
    return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })
  }

  // Ambil memori terakhir
  const { data: memories, error: memoryError } = await supabase
    .from('long_term_memories')
    .select('content')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(10)

  if (memoryError) {
    return NextResponse.json({ error: 'Gagal mengambil memori' }, { status: 500 })
  }

  const memoryText = memories?.map((m) => `- ${m.content}`).join('\n') || 'Tidak ada memori.'
  const prompt = `Buatlah refleksi mingguan yang personal berdasarkan informasi berikut:

Mode Interaksi: ${user.preferred_mode || 'tidak ditentukan'}
Target Mingguan: ${user.weekly_goal || 'belum ditetapkan'}

Kenangan/Memori Pengguna:
${memoryText}

Tuliskan refleksi yang membangun, bijak, dan mendalam namun tetap ringkas.`

  const completion = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
  })

  const result = completion.choices[0].message.content?.trim()
  if (!result) {
    return NextResponse.json({ error: 'OpenAI tidak memberikan hasil' }, { status: 500 })
  }

  // Simpan refleksi ke database
  const { error: insertError } = await supabase
    .from('weekly_reflections')
    .insert({
      user_id: user.id,
      content: result,
    })

  if (insertError) {
    return NextResponse.json({ error: insertError.message }, { status: 500 })
  }

  return NextResponse.json({ reflection: result })
}
