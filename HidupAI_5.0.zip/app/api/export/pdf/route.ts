// File: app/api/export/pdf/route.ts

import { NextResponse } from 'next/server';
import { renderToBuffer } from '@react-pdf/renderer';
import SummaryPDF from '@/components/pdf/SummaryPDF';

type ExportPdfRequestBody = {
  name: string;
  goal: string;
  // Sesuaikan dengan struktur yang dipakai SummaryPDF.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  stats: any;
};

export async function POST(req: Request) {
  try {
    const { name, goal, stats } = (await req.json()) as ExportPdfRequestBody;

    const pdfBuffer = await renderToBuffer(
      SummaryPDF({ name, goal, stats }) // dipanggil sebagai fungsi, bukan JSX
    );

    // Gunakan Uint8Array agar kompatibel dengan BodyInit
    const pdfUint8Array = new Uint8Array(pdfBuffer);

    return new Response(pdfUint8Array, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition':
          'attachment; filename=ringkasan-hidupai.pdf',
      },
    });
  } catch (error) {
    console.error('❌ Gagal buat PDF:', error);
    return NextResponse.json(
      { error: 'Gagal generate PDF' },
      { status: 500 }
    );
  }
}
