import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get('Authorization')
    const token = authHeader?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: { user } } = await supabase.auth.getUser(token)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized user' }, { status: 401 })
    }

    // Ambil histori berdasarkan email user
    const { data, error } = await supabase
      .from('life_arena_logs')
      .select('*')
      .eq('user_email', user.email)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching logs:', error)
      return NextResponse.json({ error: 'Gagal mengambil histori' }, { status: 500 })
    }

    return NextResponse.json({ success: true, logs: data })
  } catch (err: unknown) {
    console.error('🔥 Life Arena Logs Error:', err)
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 })
  }
}
