import { NextResponse } from 'next/server'

export async function GET() {
  const angka1 = Math.floor(Math.random() * 10) + 1
  const angka2 = Math.floor(Math.random() * 10) + 1
  const pertanyaan = `${angka1} + ${angka2}`
  const jawaban = String(angka1 + angka2)

  const svg = `
    <svg width="150" height="50" xmlns="http://www.w3.org/2000/svg">
      <rect width="150" height="50" fill="#ccf2ff" rx="8"/>
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
        font-family="Arial, sans-serif" font-size="20" fill="#333">
        ${pertanyaan}
      </text>
    </svg>
  `

  // ✅ Gunakan NextResponse agar bisa set cookie
  const response = new NextResponse(svg, {
    status: 200,
    headers: {
      'Content-Type': 'image/svg+xml'
    }
  })

  response.cookies.set('captcha_token', jawaban, {
    httpOnly: true,
    maxAge: 300,
    path: '/'
  })

  return response
}
