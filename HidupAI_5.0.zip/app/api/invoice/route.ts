// File: app/api/invoice/route.ts

import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { renderToBuffer } from '@react-pdf/renderer';
import { generateInvoicePDF } from '@/lib/pdf-generator';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const order_id = searchParams.get('order_id');

    if (!order_id) {
      return NextResponse.json(
        { error: 'order_id tidak ditemukan' },
        { status: 400 }
      );
    }

    const { data: order, error } = await supabase
      .from('orders')
      .select('*')
      .eq('order_id', order_id)
      .in('status', ['settlement', 'capture']) // hanya status sukses
      .single();

    if (error || !order) {
      console.error('[invoice] order lookup error:', error);
      return NextResponse.json(
        { error: 'Order tidak ditemukan' },
        { status: 404 }
      );
    }

    const invoiceDocument = generateInvoicePDF({
      orderId: order.order_id,
      email: order.email,
      packageName: order.plan_type,
      amount: order.amount,
      status: order.status,
      paidAt: order.paid_at
    });

    const pdfBuffer = await renderToBuffer(invoiceDocument);

    // ✅ Ubah Buffer ke Uint8Array supaya valid sebagai BodyInit
    const pdfUint8Array = new Uint8Array(pdfBuffer);

    return new NextResponse(pdfUint8Array, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="invoice-${order.order_id}.pdf"`
      }
    });
  } catch (err: unknown) {
    console.error('[invoice] unexpected error:', err);
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat invoice PDF.' },
      { status: 500 }
    );
  }
}
