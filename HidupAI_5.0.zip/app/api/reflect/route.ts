// File: app/api/reflect/route.ts

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

type UserUpdate = {
  preferred_mode?: string;
  weekly_goal?: string;
};

type UserIdRow = {
  id: string;
};

type UserPrefsRow = {
  preferred_mode: string | null;
  weekly_goal: string | null;
};

export async function PATCH(req: NextRequest) {
  // ✅ Next.js 15: cookies() harus di-"await" sebelum dipakai helper
  const cookieStore = await cookies();
  const supabase = createRouteHandlerClient({
    cookies: () => cookieStore,
  });

  const body = (await req.json().catch(() => null)) as
    | {
        email?: string;
        preferred_mode?: string;
        weekly_goal?: string;
      }
    | null;

  const email = body?.email ?? '';
  const preferred_mode = body?.preferred_mode;
  const weekly_goal = body?.weekly_goal;

  if (!email) {
    return NextResponse.json(
      { error: 'Email wajib diisi' },
      { status: 400 }
    );
  }

  // Ambil user.id
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .single();

  if (userError || !user) {
    return NextResponse.json(
      { error: 'User tidak ditemukan' },
      { status: 404 }
    );
  }

  const userRow = user as UserIdRow;

  const updates: Partial<UserUpdate> = {};
  if (typeof preferred_mode === 'string' && preferred_mode.length > 0) {
    updates.preferred_mode = preferred_mode;
  }
  if (typeof weekly_goal === 'string' && weekly_goal.length > 0) {
    updates.weekly_goal = weekly_goal;
  }

  // Tidak ada yang di-update → anggap sukses saja
  if (Object.keys(updates).length === 0) {
    return NextResponse.json({ success: true });
  }

  const { error: updateError } = await supabase
    .from('users')
    .update(updates)
    .eq('id', userRow.id);

  if (updateError) {
    return NextResponse.json(
      { error: updateError.message },
      { status: 500 }
    );
  }

  return NextResponse.json({ success: true });
}

export async function GET(req: NextRequest) {
  const cookieStore = await cookies();
  const supabase = createRouteHandlerClient({
    cookies: () => cookieStore,
  });

  const { searchParams } = new URL(req.url);
  const email = searchParams.get('email');

  if (!email) {
    return NextResponse.json(
      { error: 'Missing email' },
      { status: 400 }
    );
  }

  const { data: user, error: userError } = await supabase
    .from('users')
    .select('preferred_mode, weekly_goal')
    .eq('email', email)
    .single();

  if (userError || !user) {
    return NextResponse.json(
      { error: 'User tidak ditemukan' },
      { status: 404 }
    );
  }

  const prefs = user as UserPrefsRow;

  return NextResponse.json({
    preferred_mode: prefs.preferred_mode || '',
    weekly_goal: prefs.weekly_goal || '',
  });
}
