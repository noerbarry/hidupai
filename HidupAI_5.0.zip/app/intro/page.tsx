'use client'

import IntroScreen from '@/components/IntroScreen'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function IntroPage() {
  const router = useRouter()

  const handleSkip = (dontShow: boolean) => {
    if (dontShow) {
      localStorage.setItem('dontShowIntro', 'true')
    }
    localStorage.setItem('introTimestamp', Date.now().toString())
    router.push('/login')
  }

  useEffect(() => {
    const skip = localStorage.getItem('dontShowIntro')
    if (skip === 'true') {
      router.push('/login')
    }
  }, [router])

  return <IntroScreen onSkip={handleSkip} />
}
