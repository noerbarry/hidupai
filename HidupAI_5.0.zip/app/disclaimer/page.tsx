// File: app/disclaimer/page.tsx
'use client'

import Link from 'next/link'
import Image from 'next/image'

export default function DisclaimerPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-blue-50/60 to-blue-100/40 pt-28 pb-16 text-gray-800">
      <div className="max-w-4xl mx-auto px-6 space-y-12">

        {/* ====== HEADER / HERO ====== */}
        <header className="space-y-6">
          {/* Breadcrumb + Chip */}
          <div className="flex items-center justify-between gap-3 text-xs sm:text-sm">
            <Link
              href="/"
              className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
            >
              ← Kembali ke Beranda
            </Link>

            <span className="inline-flex items-center rounded-full bg-blue-50 border border-blue-100 px-3 py-1 font-medium text-blue-700">
              Disclaimer
            </span>
          </div>

          {/* Logo + Title */}
          <div className="flex flex-col items-center text-center">
            <Image
              src="/images/logo-hidupai.png"
              alt="Logo HidupAI"
              width={110}
              height={110}
              className="mb-3 drop-shadow-sm"
            />
            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 leading-tight">
              📢 Disclaimer Penggunaan HidupAI
            </h1>
            <p className="mt-3 text-sm sm:text-base text-gray-600 max-w-2xl mx-auto">
              Mohon baca halaman ini untuk memahami batasan sistem dan cara terbaik
              menggunakan HidupAI sebagai pendamping refleksi hidupmu.
            </p>
          </div>
        </header>

        {/* ====== DISCLAIMER CONTENT (Kartu-kartu) ====== */}
        <section className="space-y-6">

          {/* 1. Bukan Pengganti Profesional */}
          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm space-y-2">
            <h2 className="text-xl font-semibold text-slate-900">1. Bukan Pengganti Profesional</h2>
            <p className="text-sm text-gray-700 leading-relaxed">
              HidupAI adalah platform <strong>AI mentoring digital</strong> untuk refleksi diri,
              peningkatan kesadaran, dan pembentukan kebiasaan.
              <br />
              Namun, <strong>HidupAI bukan pengganti tenaga profesional</strong> seperti psikolog,
              psikiater, dokter, atau konselor. Untuk kondisi klinis atau darurat, mohon
              prioritaskan bantuan profesional yang berwenang.
            </p>
          </div>

          {/* 2. Keakuratan & Batasan */}
          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm space-y-2">
            <h2 className="text-xl font-semibold text-slate-900">2. Keakuratan & Batasan Informasi</h2>
            <p className="text-sm text-gray-700 leading-relaxed">
              Respon AI, insight, atau refleksi bersifat <em>sebagaimana adanya</em>.  
              Kami tidak menjamin keakuratan penuh dan <strong>ini bukan nasihat mutlak</strong>.
              Kamu tetap bertanggung jawab atas keputusan pribadi yang dibuat berdasarkan
              interaksi dengan AI.
            </p>
          </div>

          {/* 3. Konten Pengguna */}
          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm space-y-2">
            <h2 className="text-xl font-semibold text-slate-900">3. Konten yang Dibuat Pengguna</h2>
            <p className="text-sm text-gray-700 leading-relaxed">
              Segala data, jurnal, pesan, atau input yang kamu berikan merupakan tanggung jawabmu.
              HidupAI tidak bertanggung jawab atas konsekuensi dari konten yang dimasukkan atau
              hasil analisis AI terhadap konten tersebut.
            </p>
          </div>

          {/* 4. Respon AI */}
          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm space-y-2">
            <h2 className="text-xl font-semibold text-slate-900">
              4. Interaksi AI & Respon Otomatis
            </h2>
            <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
              <li>Respon dapat bersifat umum dan tidak selalu cocok untuk seluruh konteks.</li>
              <li>Beberapa respon AI mungkin dipengaruhi bias data pelatihan model.</li>
              <li>
                Tidak semua respon mencerminkan posisi resmi dari platform HidupAI atau tim
                Pabar Digital Solutions.
              </li>
            </ul>
          </div>

          {/* 5. Perubahan */}
          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm space-y-2">
            <h2 className="text-xl font-semibold text-slate-900">5. Perubahan & Pembaruan</h2>
            <p className="text-sm text-gray-700 leading-relaxed">
              Isi disclaimer ini dapat diperbarui sewaktu-waktu seiring pengembangan
              produk. Mohon lakukan pengecekan secara berkala.
            </p>
          </div>

          {/* 6. Kontak */}
          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm space-y-2">
            <h2 className="text-xl font-semibold text-slate-900">6. Kontak</h2>
            <p className="text-sm text-gray-700 leading-relaxed">
              Jika kamu memiliki pertanyaan, silakan hubungi kami melalui halaman{' '}
              <Link href="/contact" className="text-blue-600 underline hover:text-blue-800">
                Contact
              </Link>
              .
            </p>
          </div>

        </section>

        {/* BACK LINK */}
        <div className="text-center mt-10">
          <Link
            href="/"
            className="text-sm text-blue-600 underline hover:text-blue-800"
          >
            ← Kembali ke Beranda HidupAI
          </Link>
        </div>
      </div>
    </main>
  )
}
