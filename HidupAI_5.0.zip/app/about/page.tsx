// File: app/about/page.tsx
'use client';

import Image from 'next/image';
import Link from 'next/link';

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-white via-blue-50/60 to-amber-50/60 pt-28 pb-16">
      <div className="max-w-5xl mx-auto px-6 text-gray-800 space-y-14">
        {/* ====== HEADER / HERO ====== */}
        <header className="space-y-6">
          {/* Breadcrumb + Chip */}
          <div className="flex items-center justify-between gap-3 text-xs sm:text-sm">
            <Link
              href="/"
              className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
            >
              ← Kembali ke Beranda
            </Link>

            <span className="inline-flex items-center rounded-full bg-blue-50 border border-blue-100 px-3 py-1 font-medium text-blue-700">
              Tentang HidupAI
            </span>
          </div>

          {/* Logo + Title */}
          <div className="flex flex-col items-center text-center">
            <Image
              src="/images/logo-hidupai.png"
              alt="Logo HidupAI"
              width={120}
              height={120}
              className="mb-3 drop-shadow-sm"
            />
            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 leading-tight">
              AI yang Memahami Hidupmu,
              <span className="block text-blue-600">
                Bukan Sekadar Chatmu
              </span>
            </h1>
            <p className="mt-3 text-sm sm:text-base text-gray-600 max-w-2xl mx-auto">
              HidupAI adalah <strong>mentor pribadi berbasis AI</strong> yang
              membantu kamu mengenali tujuan, mengelola emosi, dan membangun
              kebiasaan bermakna. Bukan sekadar chatbot, tetapi{' '}
              <span className="font-semibold">cermin digital</span> yang tumbuh
              bersama perjalanan hidupmu.
            </p>
          </div>
        </header>

        {/* ====== VISI & MISI ====== */}
        <section className="grid gap-6 md:grid-cols-2">
          {/* Visi */}
          <div className="rounded-2xl bg-white border border-blue-100 shadow-sm p-6 space-y-2">
            <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
              <span>🎯</span> <span>Visi</span>
            </h2>
            <p className="text-sm text-gray-700 leading-relaxed">
              Menjadi <strong>AI mentor pribadi</strong> paling berdampak di
              Asia dan dunia — membantu manusia menjalani hidup yang lebih
              sadar, penuh makna, dan terarah.
            </p>
          </div>

          {/* Misi */}
          <div className="rounded-2xl bg-white border border-amber-100 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2 mb-3">
              <span>🌍</span> <span>Misi</span>
            </h2>
            <div className="space-y-2 text-sm text-gray-700">
              <div className="flex items-start gap-2">
                <span className="mt-0.5">💡</span>
                <p>Membantu manusia hidup lebih sadar, produktif, dan bertumbuh.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="mt-0.5">🤝</span>
                <p>Menyediakan ruang aman untuk refleksi & konsistensi harian.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="mt-0.5">🧠</span>
                <p>Menghubungkan teknologi dengan keseharian, bukan sekadar hype.</p>
              </div>
            </div>
          </div>
        </section>

        {/* ====== PEMBEDA HIDUPAI ====== */}
        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900">
            🔎 Apa yang Membuat HidupAI Berbeda?
          </h2>

          <div className="grid gap-5 md:grid-cols-2">
            {/* AI generik */}
            <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-gray-800 mb-2">
                AI Generik pada Umumnya
              </h3>
              <ul className="text-sm text-gray-600 space-y-1.5 list-disc list-inside">
                <li>Fokus pada jawaban cepat & informatif.</li>
                <li>Berorientasi pada produktivitas & efisiensi teknis.</li>
                <li>
                  Tidak menyimpan konteks emosional atau jejak perjalanan hidupmu.
                </li>
              </ul>
            </div>

            {/* HidupAI tumbuh bersamamu */}
            <div className="rounded-2xl bg-blue-50 border border-blue-100 p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-blue-900 mb-3">
                ✅ HidupAI — AI yang Tumbuh Bersamamu
              </h3>
              <div className="space-y-2 text-sm text-blue-900/90">
                <div className="flex items-start gap-2">
                  <span className="mt-0.5">📅</span>
                  <p>Hadir setiap hari untuk mendengarkan dan memahami tujuan hidupmu.</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="mt-0.5">📓</span>
                  <p>
                    Fitur reflektif seperti <strong>Future Letter</strong>,{' '}
                    <strong>Soul Journal</strong>, dan{' '}
                    <strong>Growth Memory</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="mt-0.5">💎</span>
                  <p>
                    Pendekatan <em>human-centered</em> yang fokus pada emosi &
                    kesadaran, bukan hanya produktivitas.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ====== EKOSISTEM PABAR ====== */}
        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900 text-center">
            Bagian dari Ekosistem PABAR
          </h2>

          <div className="rounded-2xl bg-white border border-gray-200 p-6 shadow-sm">
            <Image
              src="/images/pabar-ecosystem.jpg"
              alt="Ekosistem PABAR"
              width={1400}
              height={700}
              className="rounded-xl w-full h-auto mb-4"
            />
            <p className="text-xs sm:text-sm text-gray-600 max-w-2xl mx-auto text-center leading-relaxed">
              HidupAI merupakan bagian dari ekosistem inovasi AI buatan
              Indonesia: <strong>PABAR.ID</strong> (edukasi AI),{' '}
              <strong>Pabar Studio</strong> (konten kreator AI), dan{' '}
              <strong>PABAR.AI</strong> (produk SaaS AI global).
            </p>
          </div>
        </section>

        {/* ====== TIM & CREDITS ====== */}
        <section className="space-y-4 text-center">
          <h2 className="text-xl font-semibold text-slate-900">
            Tim &amp; Credits
          </h2>
          <p className="text-sm text-gray-600 max-w-2xl mx-auto leading-relaxed">
            HidupAI dibangun oleh kreator AI dan tim teknologi dari{' '}
            <Link
              href="https://pabar.id"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-blue-600 hover:text-blue-800 underline decoration-blue-200"
            >
              Pabar Digital Solutions
            </Link>
            . Dengan semangat kolaborasi, cinta, kehangatan, dan secangkir kopi ☕, kami
            percaya AI dapat membantu hidup menjadi lebih bermakna—selama digunakan
            dengan penuh kesadaran.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-4">
            <Link
              href="/pricing"
              className="inline-flex items-center justify-center rounded-full bg-blue-600 px-5 py-2.5 text-sm font-medium text-white shadow hover:bg-blue-700"
            >
              ✨ Lihat Cara HidupAI Mendampingimu
            </Link>
            <Link
              href="/"
              className="inline-flex items-center justify-center rounded-full border border-gray-300 px-4 py-2 text-xs sm:text-sm text-gray-700 hover:bg-gray-50"
            >
              ← Kembali ke Beranda HidupAI
            </Link>
          </div>
        </section>
      </div>
    </main>
  );
}
