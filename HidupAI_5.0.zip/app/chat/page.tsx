// File: app/chat/page.tsx
'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import ChatBox from '@/components/ChatBox'
import UpgradeCTA from '@/components/UpgradeCTA'
import PremiumModal from '@/components/PremiumModal'

interface UserData {
  plan_type: 'premium' | 'trial' | 'pro' | 'free'
  premium_until: string | null
  just_upgraded: boolean
}

interface SessionInfo {
  email: string
  name: string
  token: string
}

export default function ChatPage() {
  const supabase = createClientComponentClient()
  const [user, setUser] = useState<UserData | null>(null)
  const [sessionInfo, setSessionInfo] = useState<SessionInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      const email = session?.user?.email || ''
      const token = session?.access_token || ''

      // derive nama sederhana dari metadata / email
      const nameFromMeta =
        (session?.user?.user_metadata as { full_name?: string; name?: string } | undefined)
          ?.full_name ||
        (session?.user?.user_metadata as { name?: string } | undefined)?.name ||
        (email ? email.split('@')[0] : '')

      if (!email || !token) {
        // tidak ada session → anggap user free dan tidak bisa akses chat
        setLoading(false)
        return
      }

      setSessionInfo({
        email,
        name: nameFromMeta || 'Teman HidupAI',
        token,
      })

      const { data, error } = await supabase
        .from('users')
        .select('plan_type, premium_until, just_upgraded')
        .eq('email', email)
        .single()

      if (error || !data) {
        console.error('Gagal mengambil data user:', error)
        setLoading(false)
        return
      }

      setUser(data)

      if (data.just_upgraded) {
        setShowModal(true)
        await supabase
          .from('users')
          .update({ just_upgraded: false })
          .eq('email', email)
      }

      setLoading(false)
    }

    fetchUser()
  }, [supabase])

  if (loading) {
    return (
      <div className="text-center mt-8 text-sm text-gray-500">
        ⏳ Memuat data pengguna...
      </div>
    )
  }

  const now = new Date()
  const isExpired =
    user?.premium_until && new Date(user.premium_until) < now

  const isAllowed =
    !!sessionInfo &&
    (user?.plan_type === 'premium' ||
      (user?.plan_type === 'trial' && !isExpired) ||
      (user?.plan_type === 'pro' && !isExpired))

  return (
    <>
      {showModal && user && <PremiumModal plan={user.plan_type} />}

      {isAllowed && sessionInfo ? (
        <ChatBox
          email={sessionInfo.email}
          name={sessionInfo.name}
          token={sessionInfo.token}
        />
      ) : (
        <div className="max-w-md mx-auto mt-10">
          <UpgradeCTA plan={user?.plan_type || 'free'} />
        </div>
      )}
    </>
  )
}
