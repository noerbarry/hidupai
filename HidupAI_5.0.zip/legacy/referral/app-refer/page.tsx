'use client'

import { useEffect, useState } from 'react'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

export default function ReferPage() {
  const supabase = createClientComponentClient()
  const [referralCode, setReferralCode] = useState<string>('')
  const [referralLink, setReferralLink] = useState<string>('')
  const [copied, setCopied] = useState<boolean>(false)

  useEffect(() => {
    const fetchReferral = async () => {
      const {
        data: { user }
      } = await supabase.auth.getUser()

      if (!user?.email) return

      const { data } = await supabase
        .from('users')
        .select('referral_code')
        .eq('email', user.email)
        .single()

      if (data?.referral_code) {
        setReferralCode(data.referral_code)
        setReferralLink(`${window.location.origin}/login?ref=${data.referral_code}`)
      }
    }

    fetchReferral()
  }, [supabase])

  const handleCopy = () => {
    if (!referralLink) return
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <main className="max-w-xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <Image
          src="/images/logo-hidupai.png"
          alt="Logo HidupAI"
          width={80}
          height={80}
          className="mx-auto mb-2"
        />
        <h1 className="text-2xl font-bold">🎯 Ajak Teman, Dapatkan Reward!</h1>
        <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
          Bantu temanmu berkembang, kamu dapat poin untuk tukar hadiah 🚀
        </p>
      </div>

      <section className="bg-gray-50 dark:bg-slate-800 p-4 rounded-xl space-y-3 text-sm">
        <h2 className="font-semibold text-base">📈 Cara Kerjanya:</h2>
        <ol className="list-decimal list-inside space-y-1">
          <li>Bagikan link referral kamu ke teman</li>
          <li>Teman login & daftar ke HidupAI</li>
          <li>Teman upgrade ke Premium</li>
          <li>Kamu dapat 5 poin / teman</li>
        </ol>
      </section>

      <section className="bg-white dark:bg-slate-900 p-4 rounded-xl border dark:border-slate-700 space-y-3">
        <h2 className="font-semibold text-base">🎁 Reward Digital</h2>
        <ul className="list-disc list-inside text-sm space-y-1">
          <li>3 poin → Planner HidupAI</li>
          <li>5 poin → Upgrade Premium</li>
          <li>10 poin → Template Eksklusif</li>
        </ul>
      </section>

      {referralCode ? (
        <section className="bg-blue-50 dark:bg-slate-800 p-4 rounded-xl space-y-2">
          <h2 className="font-semibold text-base">🔗 Link Referral Kamu</h2>
          <div className="text-sm break-all text-gray-800 dark:text-white">
            {referralLink}
          </div>
          <Button onClick={handleCopy} className="mt-2">
            {copied ? '✅ Tersalin!' : '📋 Salin Link'}
          </Button>
        </section>
      ) : (
        <p className="text-center text-sm text-gray-400">
          Login dulu untuk melihat link referral kamu.
        </p>
      )}
    </main>
  )
}
