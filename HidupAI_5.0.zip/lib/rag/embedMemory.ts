// 📁 /lib/rag/embedMemory.ts
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function getEmbedding(text: string): Promise<number[]> {
  const response = await fetch('https://api.openai.com/v1/embeddings', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'text-embedding-3-small',
      input: text
    })
  })

  const json = await response.json()
  if (!response.ok || !json?.data?.[0]?.embedding) {
    console.error('❌ Gagal mendapatkan embedding:', json)
    throw new Error('Gagal mendapatkan embedding')
  }

  return json.data[0].embedding
}

/**
 * Menyimpan isi memori ke tabel long_term_memories setelah di-embed.
 * @param email - Email user yang menyimpan
 * @param content - Isi memori yang akan disimpan
 */
export async function embedMemory(
  email: string,
  content: string
): Promise<{ success: boolean; error?: Error | null }> {
  if (!email || !content) {
    return { success: false, error: new Error('Email atau konten kosong.') }
  }

  try {
    const embedding = await getEmbedding(content)

    const { error } = await supabase.from('long_term_memories').insert({
      user_email: email,
      content,
      embedding
    })

    if (error) {
      console.error('❌ Gagal menyimpan ke Supabase:', error)
      return { success: false, error: new Error(error.message) }
    }

    return { success: true, error: null }
  } catch (err) {
    console.error('❌ embedMemory gagal:', err)
    return {
      success: false,
      error: err instanceof Error ? err : new Error('Unknown error')
    }
  }
}
