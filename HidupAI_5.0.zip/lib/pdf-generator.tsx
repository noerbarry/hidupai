// TANPA 'use client'

import { Document, Page, Text, StyleSheet } from '@react-pdf/renderer'

const styles = StyleSheet.create({
  body: { padding: 40, fontFamily: 'Helvetica' },
  title: { fontSize: 24, marginBottom: 20, color: '#1e40af' },
  info: { fontSize: 12, marginBottom: 10 },
  footer: { marginTop: 40, fontSize: 10, color: '#999' }
})

export function generateInvoicePDF({
  orderId,
  email,
  packageName,
  amount,
  status,
  paidAt
}: {
  orderId: string
  email: string
  packageName: string
  amount: number
  status: string
  paidAt: string | null
}) {
  return (
    <Document>
      <Page style={styles.body}>
        <Text style={styles.title}>Invoice HidupAI</Text>
        <Text style={styles.info}>Order ID: {orderId}</Text>
        <Text style={styles.info}>Email: {email}</Text>
        <Text style={styles.info}>Paket: {packageName}</Text>
        <Text style={styles.info}>Jumlah: Rp{amount.toLocaleString('id-ID')}</Text>
        <Text style={styles.info}>Status: {status}</Text>
        <Text style={styles.info}>
          Dibayar: {paidAt ? new Date(paidAt).toLocaleString('id-ID') : '-'}
        </Text>
        <Text style={styles.footer}>
          Invoice ini dihasilkan otomatis oleh sistem HidupAI. | Powered by PABAR
        </Text>
      </Page>
    </Document>
  )
}
