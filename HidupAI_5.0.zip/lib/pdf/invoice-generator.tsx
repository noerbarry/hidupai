'use client'

import { pdf, Document, Page, Text, StyleSheet } from '@react-pdf/renderer'
import { Readable } from 'stream'

interface Order {
  order_id: string
  email: string
  plan_type: string
  amount: number
  payment_method?: string
  va_number?: string
  paid_at?: string
}

const styles = StyleSheet.create({
  page: { padding: 30, fontSize: 12 },
  title: { fontSize: 18, marginBottom: 16, fontWeight: 'bold', color: '#3b82f6' },
  label: { fontWeight: 'bold', marginTop: 4 },
  text: { marginBottom: 2 }
})

function InvoiceDocument(order: Order) {
  return (
    <Document>
      <Page style={styles.page}>
        <Text style={styles.title}>📄 Invoice HidupAI</Text>
        <Text style={styles.text}><Text style={styles.label}>Order ID:</Text> {order.order_id}</Text>
        <Text style={styles.text}><Text style={styles.label}>Email:</Text> {order.email}</Text>
        <Text style={styles.text}><Text style={styles.label}>Paket:</Text> {order.plan_type}</Text>
        <Text style={styles.text}><Text style={styles.label}>Jumlah:</Text> Rp{order.amount.toLocaleString('id-ID')}</Text>
        <Text style={styles.text}><Text style={styles.label}>Metode:</Text> {order.payment_method || '-'}</Text>
        <Text style={styles.text}><Text style={styles.label}>Nomor VA:</Text> {order.va_number || '-'}</Text>
        <Text style={styles.text}><Text style={styles.label}>Tanggal:</Text> {order.paid_at ? new Date(order.paid_at).toLocaleString('id-ID') : '-'}</Text>
        <Text style={{ marginTop: 16, fontSize: 10, color: '#888' }}>
          Invoice ini dihasilkan otomatis oleh sistem HidupAI – Powered by PABAR 🇮🇩
        </Text>
      </Page>
    </Document>
  )
}

export async function generateInvoicePDF(order: Order): Promise<Readable> {
  const buffer = await pdf(InvoiceDocument(order)).toBuffer()

  // Convert Buffer to Readable Stream
  const stream = new Readable()
  stream.push(buffer)
  stream.push(null)

  return stream
}
