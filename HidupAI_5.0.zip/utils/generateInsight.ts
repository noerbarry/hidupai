export function generateAIInsight(data: {
    habits: string[]
    journal: string
    goals: string[]
  }) {
    const insights: string[] = []
  
    if (data.habits.includes('tidak mengisi')) {
      insights.push('⚠️ Kamu belum konsisten mengisi tracker minggu ini.')
    } else {
      insights.push('✅ Konsistensi habit kamu cukup baik minggu ini.')
    }
  
    if (data.journal.includes('lelah')) {
      insights.push('🧘 Kamu sering merasa lelah. Mungkin butuh istirahat lebih teratur.')
    }
  
    if (data.goals.length > 0) {
      insights.push(`🎯 Kamu sedang fokus pada ${data.goals.length} tujuan penting.`)
    }
  
    return insights
  }
  