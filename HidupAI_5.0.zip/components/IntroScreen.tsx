'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'

interface IntroScreenProps {
  onSkip: (dontShow: boolean) => void
}

export default function IntroScreen({ onSkip }: IntroScreenProps) {
  const [show, setShow] = useState(true)

  const handleSkip = (dontShow: boolean) => {
    setShow(false)
    onSkip(dontShow)
  }

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="intro"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-gradient-to-b from-white to-slate-100 dark:from-black dark:to-slate-900 text-gray-800 dark:text-gray-100"
        >
          <div className="flex flex-col items-center space-y-6 px-6 text-center max-w-md">
            {/* Logo */}
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: 'easeOut' }}
            >
              <Image
                src="/images/logo-hidupai.png"
                alt="HidupAI Logo"
                width={120}
                height={120}
                className="mx-auto drop-shadow-xl"
              />
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.7 }}
              className="text-2xl font-bold"
            >
              Selamat Datang di <span className="text-blue-600">HidupAI</span> 👋
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.4, duration: 0.7 }}
              className="text-sm text-gray-500 dark:text-gray-400"
            >
              Teman Sejiwa &amp; Mentor Digitalmu ✨
            </motion.p>

            {/* Actions */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2, duration: 0.6 }}
              className="space-y-1"
            >
              <button
                onClick={() => handleSkip(false)}
                className="text-xs text-blue-600 hover:underline"
              >
                ⏭️ Lewati Intro
              </button>
              <button
                onClick={() => handleSkip(true)}
                className="text-[11px] text-gray-400 hover:underline"
              >
                🚫 Jangan tampilkan lagi
              </button>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
