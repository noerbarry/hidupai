'use client';

import { useChatStore } from '@/lib/store';
import { useEffect, useRef, useState } from 'react';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';

interface ChatBoxProps {
  email: string;
  name: string;
  token: string;
}

export default function ChatBox({ email, name, token }: ChatBoxProps) {
  const supabase = createClientComponentClient();

  const {
    messages,
    name: storeName,
    goal,
    mode,
    setMessages,
    appendMessage,
    setUserInfo,
    clearMessages,
  } = useChatStore();

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  // key history per user per hari
  const today = new Date().toISOString().split('T')[0];
  const storageKey = `hidupai-chat-${email}-${today}`;

  /* =========================================================
   *  RESTORE HISTORY DARI LOCALSTORAGE
   * =======================================================*/
  useEffect(() => {
    if (!email) return;

    const saved = localStorage.getItem(storageKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.messages) setMessages(parsed.messages);
        if (parsed.name || parsed.goal || parsed.mode) {
          setUserInfo(parsed.name || '', parsed.goal || '', parsed.mode || '');
        }
      } catch (e) {
        console.error('[ChatBox] gagal parse history:', e);
      }
    }
  }, [email, storageKey, setMessages, setUserInfo]);

  // Seed nama dari props kalau store belum punya
  useEffect(() => {
    if (!storeName && name) {
      setUserInfo(name, goal || '', mode || '');
    }
  }, [storeName, name, goal, mode, setUserInfo]);

  /* =========================================================
   *  SIMPAN HISTORY KE LOCALSTORAGE
   * =======================================================*/
  useEffect(() => {
    if (!email) return;

    const payload = {
      messages,
      name: storeName,
      goal,
      mode,
    };

    localStorage.setItem(storageKey, JSON.stringify(payload));
  }, [messages, storeName, goal, mode, email, storageKey]);

  /* =========================================================
   *  AUTO SCROLL
   * =======================================================*/
  useEffect(() => {
    chatRef.current?.scrollTo({
      top: chatRef.current.scrollHeight,
      behavior: 'smooth',
    });
  }, [messages, loading]);

  /* =========================================================
   *  CEK STATUS PREMIUM (UNTUK PILIH ENDPOINT)
   * =======================================================*/
  useEffect(() => {
    const fetchPremium = async () => {
      if (!email) return;

      const { data, error } = await supabase
        .from('users')
        .select('is_premium')
        .eq('email', email)
        .single();

      if (error) {
        console.error('[ChatBox] gagal cek is_premium:', error);
        setIsPremium(false);
        return;
      }

      setIsPremium(data?.is_premium || false);
    };

    fetchPremium();
  }, [email, supabase]);

  /* =========================================================
   *  MODE DETECTION (SEDIH / PAGI / MENTOK / SUKSES)
   * =======================================================*/
  const detectMode = (text: string) => {
    if (text.match(/capek|lelah|down|sedih/i)) return 'sedih';
    if (text.match(/bingung|mentok|buntu/i)) return 'mentok';
    if (text.match(/selesai|berhasil|goal/i)) return 'sukses';
    if (text.match(/pagi|semangat/i)) return 'pagi';
    return '';
  };

  /* =========================================================
   *  HANDLE SUBMIT
   * =======================================================*/
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !email) return;

    const userMessage = { role: 'user' as const, content: input };
    const detected = detectMode(input);

    // Conversations yang dikirim ke API
    const baseMessages = [...messages, userMessage];

    appendMessage(userMessage);
    setInput('');
    setLoading(true);

    const endpoint = isPremium ? '/api/agentic-chat' : '/api/chat';

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          messages: baseMessages,
          name: storeName || name,
          goal,
          email,
          mode: detected || mode,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        const fallbackMsg =
          data?.message ||
          'Maaf, HidupAI lagi kesulitan menjawab sekarang. Coba sebentar lagi ya 🌱';

        setMessages([
          ...baseMessages,
          { role: 'assistant', content: fallbackMsg },
        ]);
      } else {
        setMessages([
          ...baseMessages,
          { role: 'assistant', content: data.message as string },
        ]);
      }
    } catch (err) {
      console.error('[ChatBox] error kirim pesan:', err);
      setMessages([
        ...baseMessages,
        {
          role: 'assistant',
          content:
            'Maaf, koneksi ke server lagi bermasalah. Coba cek internet atau ulangi beberapa saat lagi ya 🌱',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    clearMessages();
    localStorage.removeItem(storageKey);
  };

  /* =========================================================
   *  UI
   * =======================================================*/
  return (
    <div className="max-w-xl mx-auto p-4">
      <div
        id="chat-scroll"
        ref={chatRef}
        className="bg-white rounded-xl border p-4 h-[400px] overflow-y-auto space-y-3 text-sm text-gray-800"
      >
        {messages.map((m, i) => (
          <div
            key={i}
            className={m.role === 'user' ? 'text-right' : 'text-left'}
          >
            <span className="inline-block px-3 py-2 rounded-lg bg-gray-100">
              {m.content}
            </span>
          </div>
        ))}

        {loading && (
          <div className="text-left text-gray-400 italic">
            ⏳ HidupAI sedang menanggapi kamu dengan hati-hati...
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Tulis pesan ke HidupAI™..."
          className="flex-1 border px-3 py-2 rounded-lg text-sm"
        />
        <button
          type="submit"
          className="bg-black text-white px-4 py-2 rounded-lg text-sm"
          disabled={loading}
        >
          Kirim
        </button>
      </form>

      <button
        onClick={handleReset}
        className="mt-4 text-xs text-red-500 underline"
      >
        Reset obrolan
      </button>
    </div>
  );
}
