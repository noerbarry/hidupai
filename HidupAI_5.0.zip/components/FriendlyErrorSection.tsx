'use client'

import { useSearchParams, useRouter } from 'next/navigation'
import { useState } from 'react'
import Image from 'next/image'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

const FRIENDLY_MESSAGES = {
  otp_expired: {
    title: '⚠️ Link Masuk Kadaluarsa',
    description: 'Link hanya berlaku singkat dan hanya bisa digunakan satu kali.',
  },
  access_denied: {
    title: '❌ Akses Ditolak',
    description: 'Login dibatalkan atau link tidak valid.',
  },
  default: {
    title: '⚠️ Kendala Saat Login',
    description: 'Terjadi kesalahan saat login. Silakan coba lagi.',
  },
} as const

export function FriendlyErrorSection() {
  const searchParams = useSearchParams()
  const errorCode = searchParams.get('error_code') as keyof typeof FRIENDLY_MESSAGES
  const errorDesc = searchParams.get('error_description')
  const router = useRouter()

  const friendlyMessage = FRIENDLY_MESSAGES[errorCode] || {
    ...FRIENDLY_MESSAGES.default,
    description: errorDesc || FRIENDLY_MESSAGES.default.description,
  }

  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const handleResend = async () => {
    if (!email.includes('@')) {
      setMessage('❌ Email tidak valid.')
      return
    }

    setMessage('⏳ Mengirim ulang link...')
    try {
      const res = await fetch('/api/send-magic-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      const result = await res.json()
      setMessage(result.success ? '✅ Magic link dikirim. Cek email!' : '❌ Gagal kirim link.')
    } catch {
      setMessage('❌ Terjadi kesalahan saat mengirim ulang.')
    }
  }

  if (!searchParams.get('error')) return null

  return (
    <div className="max-w-md w-full text-center space-y-6 p-8 bg-white rounded-xl shadow-lg border">
      <Image src="/images/logo-hidupai.png" alt="HidupAI Logo" width={100} height={100} className="mx-auto" />
      <h1 className="text-xl font-bold text-red-600">{friendlyMessage.title}</h1>
      <p className="text-sm text-gray-600">{friendlyMessage.description}</p>

      <div className="space-y-2">
        <Input
          placeholder="Masukkan email kamu"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Button onClick={handleResend} className="w-full">🔁 Kirim Ulang Link</Button>
        {message && <p className="text-sm text-blue-600">{message}</p>}
      </div>

      <Button onClick={() => router.push('/login')} variant="ghost" className="w-full text-xs text-gray-500">
        ⬅️ Kembali ke Login
      </Button>
    </div>
  )
}
