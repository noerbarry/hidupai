// File: app/dashboard/components/MemoryPanel.tsx

'use client'

import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem
} from '@/components/ui/select'

type LongTermMemory = {
  id: string
  content: string
}

type MemoryPanelProps = {
  email: string
}

export default function MemoryPanel({ email }: MemoryPanelProps) {
  const [loading, setLoading] = useState(true)
  const [memory, setMemory] = useState<LongTermMemory[]>([])
  const [goal, setGoal] = useState('')
  const [mode, setMode] = useState('')
  const [tempGoal, setTempGoal] = useState('')
  const [tempMode, setTempMode] = useState('')
  const [editingGoal, setEditingGoal] = useState(false)
  const [editingMode, setEditingMode] = useState(false)
  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [editedText, setEditedText] = useState('')
  const [newMemory, setNewMemory] = useState('')
  const [error, setError] = useState<string | null>(null)

  const fetchMemory = useCallback(async () => {
    if (!email) return
    setLoading(true)
    try {
      const res = await fetch(`/api/memory?email=${email}`)
      const data = await res.json()
      if (res.ok) {
        setMemory(Array.isArray(data.memory) ? data.memory : [])
        setGoal(data.goal || '')
        setTempGoal(data.goal || '')
        setMode(data.mode || '')
        setTempMode(data.mode || '')
      } else {
        console.error('Gagal memuat memori:', data.error)
      }
    } catch (err) {
      console.error('Error saat mengambil data memori:', err)
    } finally {
      setLoading(false)
    }
  }, [email])

  useEffect(() => {
    fetchMemory()
  }, [fetchMemory])

  const handleSaveGoal = async () => {
    const trimmed = tempGoal.trim()
    if (!trimmed) return
    const res = await fetch('/api/reflect', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, weekly_goal: trimmed })
    })
    if (res.ok) {
      setGoal(trimmed)
      setEditingGoal(false)
      await fetchMemory()
    }
  }

  const handleSaveMode = async () => {
    const res = await fetch('/api/agentic-preferences', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, mode: tempMode })
    })    
    if (res.ok) {
      setMode(tempMode)
      setEditingMode(false)
      await fetchMemory()
    }
  }

  const handleDelete = async (index: number) => {
    const res = await fetch('/api/memory/delete', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, index })
    })
    if (res.ok) {
      await fetchMemory()
    }
  }

  const handleEdit = async (index: number) => {
    const res = await fetch('/api/memory/edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, index, newText: editedText })
    })
    if (res.ok) {
      setEditingIndex(null)
      setEditedText('')
      await fetchMemory()
    }
  }

  const handleAdd = async () => {
    if (!newMemory.trim()) {
      setError('Memori tidak boleh kosong.')
      return
    }

    setError(null)

    try {
      const res = await fetch('/api/memory/new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, content: newMemory.trim() })
      })

      if (res.ok) {
        setNewMemory('')
        await fetchMemory()
      } else {
        setError('❌ Gagal menyimpan memori.')
      }
    } catch (e) {
      console.error('❌ Error saat menyimpan memori:', e)
      setError('Terjadi kesalahan saat menyimpan.')
    }
  }

  if (!email) {
    return <p className="text-sm text-red-500 italic">🚫 Email belum tersedia.</p>
  }

  if (loading) {
    return <p className="text-sm text-gray-500 italic">⏳ Memuat memori...</p>
  }

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <h2 className="text-sm font-bold text-indigo-600">🧠 Memori Jangka Panjang</h2>

        {/* Goal utama */}
        <div className="text-sm">
          <p className="text-gray-500 mb-1">🎯 Goal utama:</p>
          {editingGoal ? (
            <div className="flex gap-2 items-center">
              <Input value={tempGoal} onChange={(e) => setTempGoal(e.target.value)} className="text-sm" />
              <Button size="sm" onClick={handleSaveGoal} className="text-xs">💾 Simpan</Button>
              <Button size="sm" variant="outline" onClick={() => setEditingGoal(false)} className="text-xs">❌ Batal</Button>
            </div>
          ) : (
            <div className="flex justify-between items-center">
              <p className="text-gray-800 font-medium">{goal || 'Belum ada'}</p>
              <Button size="sm" variant="outline" onClick={() => setEditingGoal(true)} className="text-xs">✏️ Edit</Button>
            </div>
          )}
        </div>

        {/* Preferensi Mode */}
        <div className="text-sm">
          <p className="text-gray-500 mb-1">🌤️ Preferensi mode interaksi:</p>
          {editingMode ? (
            <div className="flex gap-2 items-center">
              <Select value={tempMode} onValueChange={setTempMode}>
                <SelectTrigger className="text-sm">
                  <SelectValue placeholder="Pilih mode..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="reflektif">🪞 Reflektif</SelectItem>
                  <SelectItem value="supportif">🫂 Supportif</SelectItem>
                  <SelectItem value="langsung">⚡ Langsung ke poin</SelectItem>
                  <SelectItem value="bercanda">😂 Bercanda Santai</SelectItem>
                </SelectContent>
              </Select>
              <Button size="sm" onClick={handleSaveMode} className="text-xs">💾 Simpan</Button>
              <Button size="sm" variant="outline" onClick={() => setEditingMode(false)} className="text-xs">❌ Batal</Button>
            </div>
          ) : (
            <div className="flex justify-between items-center">
              <p className="text-gray-800 font-medium">{mode || 'Tidak ditentukan'}</p>
              <Button size="sm" variant="outline" onClick={() => setEditingMode(true)} className="text-xs">✏️ Edit</Button>
            </div>
          )}
        </div>

        {/* Kenangan Penting */}
        <div className="text-sm">
          <p className="text-gray-500 mb-1">💡 Kenangan penting:</p>
          <ul className="space-y-2">
            {memory.length === 0 ? (
              <li className="text-gray-500 italic">Belum ada</li>
            ) : (
              memory.map((item, i) => (
                <li key={item.id} className="flex items-start justify-between gap-2 bg-gray-50 rounded-md px-2 py-1">
                  {editingIndex === i ? (
                    <div className="flex w-full gap-2">
                      <Input
                        value={editedText}
                        onChange={(e) => setEditedText(e.target.value)}
                        className="text-sm"
                      />
                      <Button size="sm" onClick={() => handleEdit(i)} className="text-xs">💾 Simpan</Button>
                      <Button size="sm" variant="outline" onClick={() => setEditingIndex(null)} className="text-xs">❌ Batal</Button>
                    </div>
                  ) : (
                    <div className="flex justify-between w-full items-center">
                      <span>{item.content}</span>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => { setEditingIndex(i); setEditedText(item.content) }} className="text-xs">✏️ Edit</Button>
                        <Button size="sm" variant="destructive" onClick={() => handleDelete(i)} className="text-xs">🗑 Hapus</Button>
                      </div>
                    </div>
                  )}
                </li>
              ))
            )}
          </ul>
        </div>

        {/* Tambah Memori */}
        <div className="space-y-2 pt-4 border-t mt-4">
          <h3 className="text-sm font-semibold text-indigo-600">➕ Tambah Memori Baru</h3>
          <Textarea
            rows={2}
            value={newMemory}
            onChange={(e) => setNewMemory(e.target.value)}
            placeholder="Tulis momen, refleksi, atau pelajaran yang ingin kamu simpan hari ini..."
            className="text-sm"
          />
          {error && <p className="text-red-500 text-xs italic">{error}</p>}
          <div className="text-right">
            <Button size="sm" onClick={handleAdd}>➕ Simpan Memori</Button>
          </div>
        </div>

        <div className="text-right">
          <Button size="sm" variant="outline" onClick={fetchMemory}>🔄 Segarkan Memori</Button>
        </div>
      </CardContent>
    </Card>
  )
}
