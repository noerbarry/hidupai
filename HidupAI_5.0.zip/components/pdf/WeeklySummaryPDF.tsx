// components/pdf/WeeklySummaryPDF.tsx
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  Font,
} from '@react-pdf/renderer'

// ✅ Font: Menggunakan Inter jika tersedia di folder /public/fonts
Font.register({
  family: 'Inter',
  fonts: [
    { src: '/fonts/Inter-Regular.ttf', fontWeight: 'normal' },
    { src: '/fonts/Inter-Bold.ttf', fontWeight: 'bold' },
  ],
})

const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 12,
    fontFamily: 'Inter',
    backgroundColor: '#f9fafb',
  },
  header: {
    marginBottom: 20,
    textAlign: 'center',
  },
  logo: {
    width: 50,
    height: 50,
    margin: '0 auto',
    marginBottom: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  section: {
    marginBottom: 16,
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#ffffff',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 6,
    color: '#111827',
  },
  line: {
    fontSize: 12,
    marginBottom: 4,
    color: '#374151',
  },
  footer: {
    marginTop: 30,
    fontSize: 10,
    textAlign: 'center',
    color: '#6b7280',
  },
})

interface Props {
  name: string
  goal: string
  habitStats: { day: string; total: number }[]
  insight: string
}

export function WeeklySummaryPDF({ name, goal, habitStats, insight }: Props) {
  const currentYear = new Date().getFullYear()

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          {/* eslint-disable-next-line jsx-a11y/alt-text */}
          <Image src="/images/logo-hidupai.png" style={styles.logo} />
          <Text style={styles.title}>📄 Ringkasan Mingguan HidupAI</Text>
        </View>

        {/* User Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>👤 Profil Pengguna</Text>
          <Text style={styles.line}>Nama: {name}</Text>
          <Text style={styles.line}>Tujuan Hidup: {goal}</Text>
        </View>

        {/* Habit Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Progress Kebiasaan</Text>
          {habitStats.map((h, idx) => (
            <Text key={idx} style={styles.line}>
              {h.day}: {h.total} kebiasaan
            </Text>
          ))}
        </View>

        {/* Insight */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🧠 Insight</Text>
          <Text style={styles.line}>{insight}</Text>
        </View>

        {/* Footer */}
        <Text style={styles.footer}>
          HidupAI • hidupai.com © {currentYear} | Dibuat dengan ☕ & ❤️
        </Text>
      </Page>
    </Document>
  )
}
