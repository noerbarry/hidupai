// File: app/pricing/page.tsx
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import Cookies from 'js-cookie'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

import { Button } from '@/components/ui/button'
import { toastHidupAI } from '@/components/ui/custom-toast'

interface PricingPlan {
  title: string
  price: string
  badge?: string
  tagline?: string
  features: string[]
  comingSoon?: boolean
  action: {
    label: string
    href?: string
    upgrade?: boolean
    highlight?: boolean
  }
}

const pricingPlans: PricingPlan[] = [
  {
    title: '🌱 Gratis',
    price: 'Rp0',
    tagline: 'Coba dulu tanpa komitmen. Rasakan ritme refleksi bersama HidupAI.',
    features: [
      '5 percakapan per hari dengan HidupAI',
      'Tanpa kartu kredit, cukup login',
      'Refleksi harian dasar lewat percakapan & onboarding',
      'Tombol 📝 “Catat Kebiasaan Hari Ini”',
      'Akses dasar LifeRank & Memory Panel',
    ],
    action: {
      label: 'Mulai Gratis',
      href: '/onboarding',
    },
  },
  {
    title: '🚀 Premium',
    price: 'Rp50.000 / bulan',
    badge: 'Paling populer',
    tagline: 'Agentic AI mentor pribadi yang hadir setiap hari untuk hidupmu.',
    features: [
      'Chat jauh lebih leluasa (tanpa batas harian, fair-use)',
      'Weekly Coaching otomatis: refleksi mingguan dari riwayat hidupmu',
      'Life Arena Pro untuk simulasi keputusan hidup',
      'Grafik & insight kebiasaan mingguan di dashboard',
      'Export PDF ringkasan mingguan & AI Weekly Planner',
      'Kirim planner langsung ke Notion lewat integrasi resmi',
      'Prioritas dalam pengembangan & uji coba fitur baru',
    ],
    action: {
      label: 'Upgrade ke Premium',
      upgrade: true,
      highlight: true,
    },
  },
  {
    title: '🎯 Pro (Coming Soon)',
    price: 'Rp150.000',
    badge: 'Segera hadir',
    tagline: 'Untuk mentor, kreator, atau tim yang butuh dukungan lebih dalam.',
    features: [
      'Semua fitur Premium',
      'Setelan pendampingan khusus untuk tim / komunitas',
      'Laporan & insight lanjutan untuk review berkala',
      'Pendampingan implementasi & eksperimen Agentic AI',
    ],
    comingSoon: true,
    action: {
      label: 'Diskusikan Kebutuhanmu',
      href: '/contact',
    },
  },
]

interface SnapInstance {
  pay: (
    token: string,
    options: {
      onSuccess: (result: unknown) => void
      onPending: (result: unknown) => void
      onError: (error: unknown) => void
      onClose: () => void
    }
  ) => void
}

declare global {
  interface Window {
    snap?: SnapInstance
  }
}

export default function PricingPage() {
  const router = useRouter()
  const supabase = createClientComponentClient()

  const [email, setEmail] = useState('')
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [upgradeError, setUpgradeError] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const init = async () => {
      let userEmail = Cookies.get('user-email')

      if (!userEmail) {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        userEmail = session?.user?.email || ''
        if (userEmail) {
          Cookies.set('user-email', userEmail)
          setIsLoggedIn(true)
        }
      } else {
        setIsLoggedIn(true)
      }

      setEmail(userEmail || '')
    }

    // Preload Midtrans Snap.js
    const script = document.createElement('script')
    script.src = 'https://app.midtrans.com/snap/snap.js'
    script.setAttribute(
      'data-client-key',
      process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY || ''
    )
    script.async = true
    document.body.appendChild(script)

    init()
  }, [supabase])

  const handleUpgrade = async () => {
    if (loading) return
    setLoading(true)
    setUpgradeError('')

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      const token = session?.access_token
      const userEmail = session?.user?.email || email

      if (!token || !userEmail) {
        setUpgradeError(
          '⚠️ Silakan login terlebih dahulu sebelum melakukan upgrade.'
        )
        router.push('/login')
        return
      }

      const res = await fetch('/api/snap-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          email: userEmail,
          amount: 50000,
          plan_type: 'premium',
        }),
      })

      const data: { token?: string; error?: string } = await res.json()

      if (typeof window !== 'undefined' && data?.token && window.snap) {
        window.snap.pay(data.token, {
          onSuccess: () => {
            toastHidupAI.success(
              '🎉 Pembayaran sukses! Selamat bergabung dengan Premium.'
            )
            router.push('/dashboard')
          },
          onPending: () => {
            toastHidupAI.neutral(
              '⌛ Pembayaran belum selesai, masih menunggu.'
            )
          },
          onError: () => {
            toastHidupAI.error('❌ Pembayaran gagal. Coba lagi ya.')
          },
          onClose: () => {
            toastHidupAI.neutral(
              '⚠️ Transaksi ditutup. Kamu bisa mencoba lagi kapan saja.'
            )
          },
        })
      } else {
        toastHidupAI.error(data?.error || '❌ Gagal memproses pembayaran.')
      }
    } catch (err) {
      console.error('[Pricing] Error saat proses upgrade:', err)
      toastHidupAI.error('Terjadi kesalahan internal. Coba beberapa saat lagi.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-blue-50/60 to-blue-100/40 pt-28 pb-16">
      <div className="max-w-5xl mx-auto px-6 space-y-12 text-gray-800">
        {/* HERO SECTION */}
        <section className="text-center space-y-4">
          <p className="inline-flex items-center rounded-full bg-blue-50 border border-blue-100 px-3 py-1 text-[11px] font-medium text-blue-700">
            🧠 Agentic AI Mentor · HidupAI
          </p>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 leading-snug">
            Pilih Rencana HidupAI
            <span className="block text-blue-600">
              yang Selaras dengan Perjalananmu
            </span>
          </h1>
          <p className="text-sm sm:text-base text-gray-600 max-w-2xl mx-auto">
            Mulai dari versi gratis untuk eksplorasi, hingga Premium yang
            mengaktifkan seluruh kemampuan Agentic AI — memori, kebiasaan, dan
            refleksi mingguan yang terhubung ke dashboard hidupmu.
          </p>
        </section>

        {/* PRICING GRID */}
        <section className="grid gap-6 md:grid-cols-3">
          {pricingPlans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl border p-6 shadow-sm bg-white transition-all hover:shadow-lg hover:-translate-y-[2px] ${
                plan.action.highlight
                  ? 'border-blue-300 ring-2 ring-blue-200'
                  : 'border-gray-200'
              }`}
            >
              {plan.badge && (
                <span className="absolute -top-3 left-4 rounded-full bg-blue-600 px-3 py-1 text-[11px] font-semibold text-white shadow-sm">
                  {plan.badge}
                </span>
              )}

              <h3 className="mt-1 text-lg font-semibold text-slate-900">
                {plan.title}
              </h3>
              <p className="text-xs text-gray-500 mt-1">{plan.tagline}</p>

              <p className="mt-4 text-2xl font-extrabold text-slate-900">
                {plan.price}
              </p>

              <ul className="mt-4 space-y-2 text-sm text-gray-700">
                {plan.features.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-[2px]">✅</span>
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>

              {/* Action Button */}
              <div className="mt-6">
                {plan.action.upgrade ? (
                  isLoggedIn ? (
                    <>
                      <Button
                        className="w-full text-sm"
                        onClick={handleUpgrade}
                        disabled={loading}
                      >
                        {loading ? '⏳ Memproses...' : plan.action.label}
                      </Button>
                      {upgradeError && (
                        <p className="mt-2 text-xs text-red-600 text-center">
                          {upgradeError}
                        </p>
                      )}
                    </>
                  ) : (
                    <>
                      <Link href="/login">
                        <Button className="w-full text-sm" variant="outline">
                          Login untuk Upgrade
                        </Button>
                      </Link>
                      {upgradeError && (
                        <p className="mt-2 text-xs text-red-600 text-center">
                          {upgradeError}
                        </p>
                      )}
                    </>
                  )
                ) : plan.action.href?.startsWith('/') ? (
                  <Link href={plan.action.href}>
                    <Button
                      className="w-full text-sm"
                      variant={plan.action.highlight ? 'default' : 'outline'}
                    >
                      {plan.action.label}
                    </Button>
                  </Link>
                ) : (
                  <a href={plan.action.href}>
                    <Button className="w-full text-sm" variant="outline">
                      {plan.action.label}
                    </Button>
                  </a>
                )}

                {plan.comingSoon && (
                  <p className="mt-2 text-[11px] text-gray-400 text-center">
                    Paket ini masih dalam pengembangan. Detail bisa berubah
                    saat rilis resmi.
                  </p>
                )}
              </div>
            </div>
          ))}
        </section>

        {/* WHY HIDUPAI SECTION */}
        <section className="mt-4 text-center space-y-2">
          <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">
            Kenapa HidupAI?
          </h2>
          <div className="text-xs sm:text-sm text-gray-600 space-y-1">
            <p>🤖 AI yang paham kamu secara personal.</p>
            <p>🎯 Fokus ke tujuan hidup, bukan sekadar tanya-jawab.</p>
            <p>🔒 Aman, tanpa harus berbagi seluruh riwayat percakapan.</p>
            <p>☕ Dibangun dari Indonesia, dengan cinta &amp; kopi.</p>
          </div>
          <div className="mt-3">
            <Link
              href="/contact"
              className="text-xs sm:text-sm text-blue-600 underline hover:text-blue-800"
            >
              Diskusikan kebutuhanmu →
            </Link>
          </div>
        </section>

        {/* NOTES */}
        <section className="text-center text-xs sm:text-sm text-gray-500 space-y-1 mt-6">
          <p>
            Semua pembayaran diproses melalui Midtrans Snap yang aman. Akses
            Premium akan aktif otomatis setelah pembayaran berhasil.
          </p>
          <p>
            Kamu selalu bisa mulai dari paket Gratis, lalu upgrade kapan saja
            tanpa kehilangan riwayat percakapan atau kebiasaan yang sudah
            tercatat.
          </p>
          <p className="mt-3">
            <Link href="/dashboard" className="underline hover:text-blue-600">
              ← Kembali ke Dashboard / Chat
            </Link>
          </p>
        </section>
      </div>
    </main>
  )
}
