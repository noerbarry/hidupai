'use client'

import { useEffect } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

export default function RedirectAfterLogin() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const supabase = createClientComponentClient()

  useEffect(() => {
    const check = async () => {
      if (searchParams.get('error')) return

      const { data: { session }, error: sessionError } = await supabase.auth.getSession()
      const token = session?.access_token

      if (!token || sessionError) {
        router.replace('/login')
        return
      }

      try {
        const res = await fetch('/api/check-user', {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`
          }
        })

        const data: { email?: string } = await res.json()

        if (res.ok && data?.email) {
          router.replace('/dashboard')
        } else {
          router.replace('/register')
        }
      } catch {
        router.replace('/register')
      }
    }

    check()
  }, [searchParams, supabase, router])

  return null
}
