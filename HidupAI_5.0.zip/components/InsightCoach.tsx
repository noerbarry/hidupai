'use client'

import { useEffect, useState } from 'react'

export default function InsightCoach() {
  const [coachText, setCoachText] = useState<string>('')

  useEffect(() => {
    const fetchInsights = async () => {
      const res = await fetch('/api/user-insight')
      const data = await res.json()

      if (data.insights && data.insights.length > 0) {
        const focus = data.insights[0].toLowerCase().replace('✨ ', '')
        setCoachText(
          `💬 Berdasarkan aktivitasmu minggu ini, kamu menunjukkan fokus pada ${focus}. Pertahankan ritmemu dan evaluasi setiap refleksi harian.`
        )
      }
    }

    fetchInsights()
  }, [])

  return (
    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 text-sm text-blue-800 dark:text-blue-100 rounded-2xl p-5 shadow space-y-3">
      <h2 className="text-base font-semibold">🧭 AI Coach Insight Mingguan</h2>
      <p className="text-sm text-blue-700 dark:text-blue-200">
        Refleksi dari AI berdasarkan datamu minggu ini:
      </p>
      <p className="italic">{coachText || '⏳ Sedang menganalisis datamu...'}</p>
    </div>
  )
}
